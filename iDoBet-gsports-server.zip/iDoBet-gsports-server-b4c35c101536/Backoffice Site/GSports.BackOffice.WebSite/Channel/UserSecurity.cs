﻿using GSports.BackOffice.WebSite.BL;
using GSports.Model.Consts.Security;

namespace GSports.BackOffice.WebSite.Channel
{
    public class UserSecurity
    {
        public static string GetUserToken()
        {
            //if (context != null && context.Items.Contains("testToken"))
            //    return context.Items["testToken"].ToString();
            //else
            //if (GSports.BackOffice.WebSite.Controllers.BaseController.TestToken.IsNotNullOrEmpty())
            //    return GSports.BackOffice.WebSite.Controllers.BaseController.TestToken;
            //else
                return SessionManager.CurrentUser.Token;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="activity">GSports.Common.CodeAttribute.Activity</param>
        /// <param name="permissionLevel"></param>
        /// <returns></returns>
        public static bool IsAllowed(string activity, ePermissionsLevel permissionLevel)
        {
            bool isAuthorized = false;
            var matrix = SessionManager.CurrentUser.User.PermissionMatrix;
            if (matrix != null && matrix.ContainsKey(activity))
            {
                isAuthorized = matrix[activity] >= permissionLevel;
            }
            else
                isAuthorized = false;

            return isAuthorized;
        }

        public static bool IsAllowed(eRole role)
        {
            return SessionManager.CurrentUser.User.IsInRole(role);
        }
    }
}