﻿using GSports.BackOffice.WebSite.BL;
using GSports.BackOffice.WebSite.Models.Security;
using GSports.Model.Consts.BackOffice;
using GSports.Model.Entities;
using GSports.Model.Entities.LocalSystem;
using GSports.Model.Filter;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace GSports.BackOffice.WebSite.Channel
{
    public class AlertServiceChannel
    {
        public static List<Alert> GetAlerts(AlertFilter filter)
        {
            return OutChannel.ExecuteAction<List<Alert>>(new object[] { filter }, BOConsts.GET_ALERTS);
        }

        public static List<Notification> GetNotifications(NotificationFilter filter)
        {
            return OutChannel.ExecuteAction<List<Notification>>(new object[] { filter }, BOConsts.GET_NOTIFICATIONS);
        }

        public static List<AlertNotificationSetting> GetAlertNotificationsSettings()
        {
            return OutChannel.ExecuteAction<List<AlertNotificationSetting>>(new object[] { }, BOConsts.GET_ALERT_NOTIFICATIONS_SETTINGS);
        }

        public static bool ModifyNotificationSettings(AlertNotificationSetting setting)
        {
            return OutChannel.ExecuteAction<bool>(new object[] { setting }, BOConsts.MODIFY_NOTIFICATION_SETTINGS);
        }

        public static bool UpdateAlert(Alert alert)
        {
            var desc = string.Format("Updared alert ID: {0}", alert.Id);
            var moreInfo = JsonConvert.SerializeObject(new { Alert = alert });

            return OutChannel.ExecuteAction<bool>(new object[] { alert, SessionManager.CurrentUser.ID }, BOConsts.UPDATE_ALERT, new LogData(desc, Model.Consts.Security.ePermissionsLevel.Update, moreInfo));
        }
    }
}