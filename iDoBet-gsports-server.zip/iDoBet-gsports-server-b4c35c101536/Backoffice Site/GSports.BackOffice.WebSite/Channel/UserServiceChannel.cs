﻿using GSports.BackOffice.WebSite.Channel;
using GSports.BackOffice.WebSite.Models.Security;
using GSports.Model.BackOffice.CustomResults;
using GSports.Model.Consts.BackOffice;
using GSports.Model.Consts.Security;
using GSports.Model.Entities;
using GSports.Model.Entities.Shifts;
using GSports.Model.Entities.User;
using GSports.Model.Filter;
using GSports.Model.Requests.Authentication;
using GSports.Model.Security;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace GSports.Channel
{
    public class UserServiceChannel
    {
        static public bool SavePermissions(int? userId, int? roleId, List<Activity> activities,bool isReset)
        {
            var desc = string.Format("Updted permissions to " + (userId.HasValue ? "user id:{0}" : "role id:{1}"), userId, roleId);
            var moreInfo = JsonConvert.SerializeObject(activities);
            return OutChannel.ExecuteAction<bool>(new object[] { userId, roleId, activities, isReset }, BOConsts.SAVE_PERMISSIONS,new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        static public List<Activity> GetActivities(int? userId, int? roleId)
        {
            return OutChannel.ExecuteAction<List<Activity>>(new object[] { userId, roleId }, BOConsts.GET_ACTIVITIES);
        }

        //static public List<UserEntity> GetUsers(int? userId, List<int> branchIds)
        //{
        //    return OutChannel.ExecuteAction<List<UserEntity>>(new object[] { userId, branchIds }, BOConsts.GET_USERS);
        //}

        //static public List<UserEntity> GetUsersData(int userId)
        //{
        //    return OutChannel.ExecuteAction<List<UserEntity>>(new object[] { userId }, BOConsts.GET_USERS_DATA);
        //}
        static public String RefreshUserInfo()
        {
            var res = OutChannel.ExecuteAction<String>(new object[] { }, BOConsts.REFRESH_USER_INFO);
            return res;
        }
        static public List<SystemUser> GetUsers(UserFilter filter)
        {
            if (filter == null) filter = new UserFilter();
            var res = OutChannel.ExecuteAction<List<SystemUser>>(new object[] { filter }, BOConsts.GET_USERS);
            return res;
        }
     
        static public int CreateUser(OperatorUser user, string password)
        {
            var desc = string.Format("Created new user named {0} {1}", user.FirstName, user.LastName);
            var moreInfo = JsonConvert.SerializeObject(user);
            return OutChannel.ExecuteAction<int>(new object[] { user, password }, BOConsts.CREATE_USER,new LogData(desc, ePermissionsLevel.Create, moreInfo));
        }
        static public object StartUserShift(int userId, long shiftId, double creditLimit)
        {
            var desc = string.Format("Shift opened for {0} ", userId);
            //var moreInfo = JsonConvert.SerializeObject(user);
            return OutChannel.ExecuteAction<object>(new object[] { userId, shiftId, creditLimit }, BOConsts.START_USER_SHIFT/*, new LogData(desc, ePermissionsLevel.Create, moreInfo)*/);
        }
        static public object StopUserShift(int userId, long shiftId)
        {
            var desc = string.Format("Shift Closed for {0} ", userId);
            //var moreInfo = JsonConvert.SerializeObject(user);
            return OutChannel.ExecuteAction<object>(new object[] { userId, shiftId}, BOConsts.STOP_USER_SHIFT/*, new LogData(desc, ePermissionsLevel.Create, moreInfo)*/);
        }

        static public object StopShift(long shiftId)
        {
            var desc = string.Format("Shift Closed for {0} ", shiftId);
            //var moreInfo = JsonConvert.SerializeObject(user);
            return OutChannel.ExecuteAction<object>(new object[] { shiftId }, BOConsts.STOP_SHIFT/*, new LogData(desc, ePermissionsLevel.Create, moreInfo)*/);
        }
        static public bool UpdateUser(UserEntity user)
        {
            var desc = string.Format("Updated user details for {0} {1} user id: {2}", user.FirstName, user.LastName, user.Id);
            var moreInfo = JsonConvert.SerializeObject(user);
            return OutChannel.ExecuteAction<bool>(new object[] { user }, BOConsts.UPDATE_USER, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        static public ChangePasswordResult ChangeUserPassword(ChangePasswordRequest req)
        {
            var desc = string.Format("Changed password for user id:{0}", req.UserId);
            var moreInfo = JsonConvert.SerializeObject(req);
            return OutChannel.ExecuteAction<ChangePasswordResult>(new object[] { req }, BOConsts.CHANGE_USER_PASSWORD, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        static public List<Access> GetUserAccess(int userId, DateTime? fromDate, DateTime? toDate)
        {
            return OutChannel.ExecuteAction<List<Access>>(new object[] { userId,fromDate,toDate  }, BOConsts.GET_USER_ACCESS);
        }

        static public bool Allow (int userId, string activity, ePermissionsLevel permissionLevel)
        {
            return OutChannel.ExecuteAction<bool>(new object[] { userId, activity, permissionLevel }, BOConsts.ALLOW);
        }

        static public OperatorUser LogInUser(string userName, string password, string ip)
        {
            var desc = string.Format("User name: {0} tried to login from ip: {1}", userName, ip);
            var moreInfo = JsonConvert.SerializeObject(new {UserName = userName, Ip = ip });
            return OutChannel.ExecuteAction<OperatorUser>(new object[] { userName, password, ip }, BOConsts.LOGIN_USER, new LogData(desc, ePermissionsLevel.Read, moreInfo));
        }

        static public void LogoutUser(string token, eLogoutType logoutType)
        {
            OutChannel.ExecuteAction<object>(new object[] { token, logoutType }, BOConsts.LOGOUT_USER);
        }

        //static public UserEntity GetUserByToken(string token)
        //{
        //    return OutChannel.ExecuteAction<UserEntity>(new object[] { token }, BOConsts.GET_USER_BY_TOKEN);
        //}

        static public Dictionary<string, ePermissionsLevel> GetUserActivityMatrix(int userId)
        {
            return OutChannel.ExecuteAction<Dictionary<string, ePermissionsLevel>>(new object[] { userId }, BOConsts.GET_USER_ACTIVITY_MATRIX);
        }

        static public bool IsUserNameAvailabile(string userName)
        {
            return OutChannel.ExecuteAction<bool>(new object[] { userName }, BOConsts.IS_USER_NAME_AVAILABILE);
        }

        static public List<Entity<long>> GetUsersAutoComplete(string userName, int userId)
        {
            return OutChannel.ExecuteAction<List<Entity<long>>>(new object[] { userName, userId }, BOConsts.GET_USERS_AUTOCOMPLETE);
        }

        static public List<ShiftEntity> GetShifts(ShiftFilter filter)
        {
            return OutChannel.ExecuteAction<List<ShiftEntity>>(new object[] { filter }, BOConsts.GET_SHIFTS);
        }
    }
}
