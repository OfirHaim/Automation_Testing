﻿using GSports.BackOffice.WebSite.BL;
using GSports.BackOffice.WebSite.Models.Security;
using GSports.Common;
using GSports.Model.Consts;
using GSports.Model.Consts.BackOffice;
using GSports.Model.Consts.Security;
using GSports.Model.Entities.Event;
using GSports.Model.Filter;
using GSports.Model.Requests.Cache;
using GSports.Model.Requests.Event;
using GSports.Model.Responses.Cache;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GSports.BackOffice.WebSite.Channel
{
    public class EventServiceChannel
    {
        static public List<SportGame> GetAvailableEvents(EventFilter filter, bool loadBetTypes, List<long> betTypeIds)
        {
            List<SportGame> retVal =null;
            byte[][] events = OutChannel.ExecuteAction<byte[][]>(new object[] { filter, loadBetTypes, betTypeIds }, BOConsts.GET_AVAILABLE_EVENTS);
            if (events != null)
                retVal =  CompressedBinaryConverter.ToObject<List<SportGame>, SportGame>(events);
            return retVal;       
        }

        static public List<SportGame> GetEvents(EventFilter filter, bool loadBetTypes, List<long> BetTypeIds = null)
        {
            List<SportGame> retVal = null;
            byte[][] events = OutChannel.ExecuteAction<byte[][]>(new object[] { filter, loadBetTypes, BetTypeIds }, BOConsts.GET_EVENTS);
            if (events != null)
                retVal = CompressedBinaryConverter.ToObject<List<SportGame>, SportGame>(events);
            return retVal;            
        }

        static public bool UpdateEventProps(eDBUpdateMode mode, List<UpdateEventData> data, string description = null)
        {
            var desc = string.IsNullOrEmpty(description) ? string.Format("Updated event properties in mode {0}", mode.ToString()) : description;
            var moreInfo = JsonConvert.SerializeObject(data);

            return OutChannel.ExecuteAction<bool>(new object[] { mode, data }, BOConsts.UPDATE_EVENT_DATA, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }
        static public bool ManualCalcWonOdds(eDBUpdateMode mode, List<long> evemtIds, bool revertCalcWonOdd = false, string description = null)
        {
            var desc = string.IsNullOrEmpty(description) ? string.Format("Calc Manuel won odds in mode {0}", mode.ToString()) : description;
            var moreInfo = JsonConvert.SerializeObject(evemtIds);

            return OutChannel.ExecuteAction<bool>(new object[] { mode, evemtIds, revertCalcWonOdd }, BOConsts.MANUAL_CALC_WON_ODDS, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        static public Dictionary<int, CacheEventData> GetEventData(List<EventDataStruct> list)
        {
            return OutChannel.ExecuteAction<Dictionary<int, CacheEventData>>(new object[] { list }, BOConsts.GET_EVENT_DATA);
        }

        static public Dictionary<int, eEventLiveStatus> BookEvents(List<BookEvent> events)
        {
            var desc = string.Format("Booked {0} events", events == null ? 0 : events.Count);
            var moreInfo = JsonConvert.SerializeObject(events);

            return OutChannel.ExecuteAction<Dictionary<int, eEventLiveStatus>>(new object[] { events }, BOConsts.BOOK_EVENTS, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        static public Dictionary<int, eEventLiveStatus> CheckLiveEventsStatus(Dictionary<long, long> providerKeys)
        {
            return OutChannel.ExecuteAction<Dictionary<int, eEventLiveStatus>>(new object[] { providerKeys }, BOConsts.CHECK_LIVE_EVENTS_STATUS);
        }

        static public List<EventLog> GetEventLog(long eventId)
        {
            var res = OutChannel.ExecuteAction<List<EventLog>>(new object[] { eventId }, BOConsts.GET_EVENT_LOG);
            //change all datetime from utc to user's local time
            try
            {
                if (res != null && res.Any() && SessionManager.CurrentUser.User.GetTimeZone() != null)
                { 
                    res.ForEach(x => {
                        var dateCount = x.LogInfo.Count(t => t == '~');
                        for (int i = 0; i < dateCount; i++)
                        {
                            var startIndex = x.LogInfo.IndexOf('~', x.LogInfo.IndexOf('~') + i) +1 ;
                            var utcDateString = x.LogInfo.Substring(startIndex, x.LogInfo.IndexOf('^', x.LogInfo.IndexOf('^') + i) - startIndex);
                            var myDate = TimeZoneInfo.ConvertTimeFromUtc(DateTime.Parse(utcDateString), SessionManager.CurrentUser.User.GetTimeZone());
                            x.LogInfo = x.LogInfo.Replace(utcDateString, myDate.ToString(Helper.DateHelper.MAIN_FORMAT));
                        }
                        x.LogInfo =  x.LogInfo.Replace("~", "");
                        x.LogInfo =  x.LogInfo.Replace("^", "");
                    });
                }
            }
            catch(Exception ex)
            {
                GLogger.Logger.WriteLog(ex);
            }
            return res;
        }

        static public bool InsertEventLog(EventLog log)
        {
            return OutChannel.ExecuteAction<bool>(new object[] { log }, BOConsts.INSERT_EVENT_LOG);
        }



        //static public bool SettleEvent(List<long> eventIds)
        //{
        //    var desc = string.Format("Settled {0} events", eventIds == null ? 0 : eventIds.Count);
        //    var moreInfo = JsonConvert.SerializeObject(eventIds);

        //    return OutChannel.ExecuteAction<bool>(new object[] { eventIds }, BOConsts.SETTLE_EVENT, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        //}


    }
}