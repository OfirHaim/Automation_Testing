﻿using GSports.GLogger;
using GSports.BackOffice.WebSite.BL;
using GSports.BackOffice.WebSite.Models.Security;
using GSports.Channel;
using GSports.Common;
using GSports.Model.Consts;
using GSports.Model.Consts.BackOffice;
using GSports.Model.Consts.Security;
using GSports.Model.Entities;
using GSports.Model.Entities.User;
using GSports.Model.Requests.BackOffice;
using GSports.Contracts;
using System;
using System.Threading.Tasks;
using System.Web;
using System.Web.Script.Serialization;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using GSports.BackOffice.WebSite.Controllers;

namespace GSports.BackOffice.WebSite.Channel
{
    public static class OutChannel
    {
        public static T ExecuteAction<T>(object[] prms, string method, LogData log = null) 
        {
            object retVal = null;

            try
            {
                var request = new BackOfficeRequest();
                request.Parameters = prms;
                request.Method = method;
                request.UserToken = UserSecurity.GetUserToken();
                using (var factory = new GSportsChannelFactory<IBackOfficeService>(ServiceConsts.BACK_OFFICE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    var startTime = DateTime.UtcNow;
                    var response = service.ExecuteAction(request);
                    retVal = response.ReturnValue;
                    string str = (string)response.UserInfo;
                    if(str.Substring(str.Length - 2, 1).Equals(","))
                    {
                       str =  str.Remove(str.Length - 2, 1);
                    }
                    JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                    var  o = json_serializer.DeserializeObject(str);
                    foreach (var item in (Dictionary<string, object>)o)
                    {
                        try
                        {
                            switch (item.Key)
                        {
                                             
                            case "holding":
                                    {
                                        double holding;
                                        if (double.TryParse(item.Value.ToString(), out holding))
                                            SessionManager.CurrentUser.User.Holding = holding;
                                    }
                            break;
                            case "balance":
                                    {
                                        double balance ;
                                        if (double.TryParse(item.Value.ToString(), out balance))
                                            SessionManager.CurrentUser.User.Balance = balance;
                                    }
                            break;
                            case "creditLimit":
                                    {
                                        int creditLimit;
                                        if (int.TryParse(item.Value.ToString(), out creditLimit))
                                            SessionManager.CurrentUser.User.TempCreditLimit = creditLimit;
                                    }
                            break;

                            }
                        }
                        catch (Exception ex)
                        {
                        }
                    }

                    var endTime = DateTime.UtcNow;

                    if (log != null)
                    {
                        var ip = SessionManager.CurrentUser == null ? string.Empty : SessionManager.CurrentUser.IpAddress;
                        var user = SessionManager.CurrentUser.ID.HasValue ? new BasicUser() { Id = SessionManager.CurrentUser.ID.Value } : null;
                        WriteToAuditLog(log.Description, log.Action, startTime, endTime, request.Method, response.IsSuccessfull(), user, ip, log.MoreInfo);
                    }

                    if (!response.IsSuccessfull())
                    {
                        if (response.Result.ErrorCode == eErrorCode.UserTokenInvalid)
                        {
                            HttpContext.Current.Items["AjaxPermissionDenied"] = true;
                            Logger.WriteLog(eLogLevel.Debug, string.Format("User id: {0} was denied access because of invalid token", SessionManager.CurrentUser.ID ?? -1));
                        }
                    }
                }
            }

            catch (Exception ex)
            {

               Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }


            if (retVal == null && typeof(T).IsValueType)
                return default(T);
            else
                return (T)retVal;
        }

        private static void WriteToAuditLog(string desc, ePermissionsLevel? action, DateTime startTime, DateTime endTime, string method, bool isSuccessfull, BasicUser user, string ip, string moreInfo)
        {
            try
            {
                Task.Run(() =>
                {
                    try
                    {
                        var newLog = new AuditLog()
                        {
                            User = user,
                            StartTime = startTime,
                            EndTime = endTime,
                            IsSuccessfull = isSuccessfull,
                            Action = action,
                            Name = method,
                            Resource = Model.Consts.eResource.BackOffice,
                            Ip = ip,
                            Description = desc,
                            MoreInfo = moreInfo
                        };
                        var logRequest = new BackOfficeRequest()
                        {
                            Method = BOConsts.WRITE_TO_AUDIT_LOG,
                            UserToken = null,
                            Parameters = new object[] { newLog }
                        };
                        using (var factory = new GSportsChannelFactory<IBackOfficeService>(ServiceConsts.BACK_OFFICE_SERVICE))
                        {
                            var service = factory.CreateChannel();
                            var newId = (long)service.ExecuteAction(logRequest).ReturnValue;
                            if (newId <= 0)
                                Logger.WriteLog(eLogLevel.Warn, "wtiting to audit log failed");
                        }
                    }
                    catch (Exception ex)
                    {
                        Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                    }
                });
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
        }
    }
}
