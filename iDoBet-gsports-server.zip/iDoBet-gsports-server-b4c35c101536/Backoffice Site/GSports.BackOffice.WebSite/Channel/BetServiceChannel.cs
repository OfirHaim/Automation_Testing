﻿using GSports.BackOffice.WebSite.BL;
using GSports.BackOffice.WebSite.Channel;
using GSports.BackOffice.WebSite.Models.Security;
using GSports.Model.Consts;
using GSports.Model.Consts.BackOffice;
using GSports.Model.Consts.Security;
using GSports.Model.Entities;
using GSports.Model.Entities.Reports;
using GSports.Model.Filter;
using GSports.Model.Requests.OddsArchive;
using GSports.Model.Requests.Order;
using GSports.Model.Responses.Event;
using GSports.Model.Responses.Order;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace GSports.Channel
{
    public class BetServiceChannel
    {
        static public GetCouponEventsResponse GetCouponEvents(int CouponId, bool loadCouponEvents, bool loadBetTypes, List<long> betTypeIds)
        {
            return OutChannel.ExecuteAction<GetCouponEventsResponse>(new object[] { CouponId, loadCouponEvents, loadBetTypes, betTypeIds }, BOConsts.GET_COUPON_EVENTS);
        }

        static public MemoryStream ExportCoupon(List<int> couponId, List<long> excelIds, string language)
        {
            return OutChannel.ExecuteAction<MemoryStream>(new object[] { couponId, excelIds, language }, BOConsts.EXPORT_COUPON);
        }

        static public List<Coupon> GetCoupons(int? couponId, bool? isActive, int? top = null)
        {            
            return OutChannel.ExecuteAction<List<Coupon>>(new object[] { couponId, isActive, top }, BOConsts.GET_COUPONS);
        }
       
        static public SaveCouponResponse SaveCoupon(Coupon coupon, List<CouponEvent> events)
        {
            var desc = string.Format("Updated coupon Name: {0} ({1}) {2}", coupon.Name, coupon.IsActive ? "Activated" : "Deactivated", events == null ? "" : "and " + events.Count + "events");
            var moreInfo = JsonConvert.SerializeObject(new { Coupon = coupon, Events = events == null ? null : from e in events select new { e.EventId, e.EventNumber } });
            coupon.UserId = SessionManager.CurrentUser.ID.Value;

            var retVal = OutChannel.ExecuteAction<SaveCouponResponse>(new object[] { coupon, events }, BOConsts.SAVE_COUPON, new LogData(desc, ePermissionsLevel.Update, moreInfo));
            //raise event for display highlights
            //if(retVal.IsSuccessfull())
            //    PushChannel.PublishMessage(new PushServerMessage() { Channel = Channels.SYSTEM_CHANNEL, MessageJson = JsonConvert.SerializeObject(new PushNotification(eNotificationType.CouponChanged)) });

            return retVal;
        }

        public static GetBetOrderResponse GetOrders(OrderFilter filter)
        {
            return OutChannel.ExecuteAction<GetBetOrderResponse>(new object[] { filter }, BOConsts.GET_ORDERS);
        }

        public static GetOrdersDataResponse GetOrderData(GetOrdersDataRequest req)
        {
            return OutChannel.ExecuteAction<GetOrdersDataResponse>(new object[] { req }, BOConsts.GET_ORDER_DATA);
        }

        public static eErrorCode UpdateOrder(UpdateOrderRequest req)
        {
            var desc = string.Format("Updated order Name: {0} ", req.Order.Name);
            var moreInfo = JsonConvert.SerializeObject(req);

            return OutChannel.ExecuteAction<eErrorCode>(new object[] { req }, BOConsts.UPDATE_ORDER, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        public static eErrorCode RevertOrderChnages(RevertOrderRequest req)
        {
            var desc = string.Format("Reverted order id: {0} ", req.OrderId);
            var moreInfo = JsonConvert.SerializeObject(req);

            return OutChannel.ExecuteAction<eErrorCode>(new object[] { req }, BOConsts.REVERT_ORDER_CHNAGES, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        public static eErrorCode ReversePayment(ReversePaymentRequest req)
        {
            var desc = string.Format("Reverted Payment for order id: {0} ", req.OrderId);
            var moreInfo = JsonConvert.SerializeObject(req);

            return OutChannel.ExecuteAction<eErrorCode>(new object[] { req }, BOConsts.REVERSE_PAYMENT, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        public static eErrorCode CancelUndoCancelOrder(OrderEntity order)
        {
            var desc = string.Format("Canceled order Name: {0} ", order.Name);
            var moreInfo = JsonConvert.SerializeObject(order);

            return OutChannel.ExecuteAction<eErrorCode>(new object[] { order }, BOConsts.CANCEL_UNDO_CANCEL_ORDER, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        public static bool UpdateOrderBet(OrderBet bet, string desc, bool isRevert)
        {
            var moreInfo = JsonConvert.SerializeObject(bet);

            return OutChannel.ExecuteAction<bool>(new object[] { bet, isRevert }, BOConsts.UPDATE_ORDER_BET, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }
              
        public static string CreateNewOrder(double amount, Dictionary<long, OddEntity> Odds)
        {
            var desc = string.Format("Created new order. Amount: {0} with {1} odds ", amount, Odds == null ? 0 : Odds.Count);
            var moreInfo = JsonConvert.SerializeObject(new { Amount = amount, Odds = Odds });

            return OutChannel.ExecuteAction<string>(new object[] { amount, Odds }, BOConsts.CREATE_NEW_ORDER, new LogData(desc, ePermissionsLevel.Create, moreInfo));          
            
        }
      
        static public List<BranchReportSummary> GetBranchReportSummary(BranchReportSummaryFilter filter)
        {
            return OutChannel.ExecuteAction<List<BranchReportSummary>>(new object[] { filter }, BOConsts.GET_BRANCH_REPORT_SUMMARY);
        }
        static public List<TotalTaxReport> GetTotalTaxReport(TotalTaxReportFilter filter)
        {
            return OutChannel.ExecuteAction<List<TotalTaxReport>>(new object[] { filter }, BOConsts.GET_TOTAL_TAX_REPORT);
        }
        static public List<OnlineSummaryReport> GetOnlineSummaryReport(OnlineSummaryReportFilter filter)
        {
            return OutChannel.ExecuteAction<List<OnlineSummaryReport>>(new object[] { filter }, BOConsts.GET_ONLINE_SUMMARY_REPORT);
        }
        static public List<AccountReportSummary> GetAccountReportSummary(AccountReportSummaryFilter filter)
        {
            return OutChannel.ExecuteAction<List<AccountReportSummary>>(new object[] { filter }, BOConsts.GET_ACCOUNT_REPORT_SUMMARY);
        }
        static public List<BranchBalanceReport> GetBranchBalanceReport()
        {
            return OutChannel.ExecuteAction<List<BranchBalanceReport>>(new object[] { }, BOConsts.GET_BRANCH_BALANCE_REPORT);
        }

        static public List<ArchivedOdd> GetArchivedOdds(List<GetOddsRequestFilter> req)
        {
            return OutChannel.ExecuteAction<List<ArchivedOdd>>(new object[] { req }, BOConsts.GET_ARCHIVED_ODDS);
        }
    }
}