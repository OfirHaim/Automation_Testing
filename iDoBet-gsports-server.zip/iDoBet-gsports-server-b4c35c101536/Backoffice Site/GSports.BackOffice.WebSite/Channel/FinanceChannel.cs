﻿using GSports.BackOffice.WebSite.Models.Security;
using GSports.Model.Consts;
using GSports.Model.Consts.BackOffice;
using GSports.Model.Consts.Security;
using GSports.Model.Entities.Finance;
using GSports.Model.Entities.User;
using GSports.Model.Filter;
using GSports.Model.Requests.Finance;
using GSports.Model.Responses.Finance;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace GSports.BackOffice.WebSite.Channel
{
    public class FinanceChannel
    {
        static public CreditLimit GetCreditLimit(int? userId, int? branchId)
        {
            return OutChannel.ExecuteAction<CreditLimit>(new object[] { userId, branchId }, BOConsts.GET_CREDITLIMIT);
        }

        static public int SetCreditLimit(CreditLimit limit)
        {
            var desc = string.Format("Set credit limit to user id: {0}", limit.User.Id);
            var moreInfo = JsonConvert.SerializeObject(limit);

            return OutChannel.ExecuteAction<int>(new object[] { limit }, BOConsts.SET_CREDITLIMIT, new LogData(desc, ePermissionsLevel.Create, moreInfo));
        }

        static public bool DeleteCreditLimit(int id)
        {
            var desc = string.Format("Deleted credit limit id: {0}", id);
            var moreInfo = JsonConvert.SerializeObject(id);

            return OutChannel.ExecuteAction<bool>(new object[] { id }, BOConsts.DELETE_CREDIT_LIMIT, new LogData(desc, ePermissionsLevel.Delete, moreInfo));
        }

        static public InsertTransferResponse InsertTransfer(Transfer t)
        {
            var desc = string.Format("Inserted new transfer from acoount id: {0} to account id: {1} of amount {2}", t.FromAccount.Id, t.ToAccount.Id, t.RequestAmount);
            var moreInfo = JsonConvert.SerializeObject(t);

            return OutChannel.ExecuteAction<InsertTransferResponse>(new object[] { t }, BOConsts.INSERT_TRANSFER, new LogData(desc, ePermissionsLevel.Create, moreInfo));
        }

        static public List<Transfer> GetTransfers(TransferFilter filter)
        {
            return OutChannel.ExecuteAction<List<Transfer>>(new object[] { filter }, BOConsts.GET_TRANSFERS);
        }
        static public InsertDepositResponse InsertDeposit(InsertDepositRequest request)
        {
            var desc = string.Format("Inserted new Deposit from token id: {0} to user id: {1} of amount {2}",request.UserToken, request.ToUserId, request.Amount);
            var moreInfo = JsonConvert.SerializeObject(request);

            return OutChannel.ExecuteAction<InsertDepositResponse>(new object[] { request }, BOConsts.INSERT_DEPOSIT, new LogData(desc, ePermissionsLevel.Create, moreInfo));
        }

        static public InsertWithdrawResponse InsertWithdrawl(InsertWithdrawRequest request)
        {
            var moreInfo = JsonConvert.SerializeObject(request);

            return OutChannel.ExecuteAction<InsertWithdrawResponse>(new object[] { request }, BOConsts.INSERT_WITHDRAWL, null);
        }
        static public bool UpdateTransfer(long transferId, string responseTypeCodeAttr, double? responseAmount, string responseComment)
        {
            var desc = string.Format("Updated transfer id: {0}, response amount {1}", transferId, responseAmount);
            var moreInfo = JsonConvert.SerializeObject(new { transferId = transferId, responseTypeCodeAttr = responseTypeCodeAttr, responseAmount = responseAmount, responseComment = responseComment });

            return OutChannel.ExecuteAction<bool>(new object[] { transferId, responseTypeCodeAttr, responseAmount, responseComment }, BOConsts.UPDATE_TRANSFER, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        static public List<Account> GetAccounts(int? userId, long? accountId)
        {
            return OutChannel.ExecuteAction<List<Account>>(new object[] { userId, accountId }, BOConsts.GET_ACCOUNTS);
        }

        static public List<Transaction> GetTransactions(TransactionFilter filter)
        {
            return OutChannel.ExecuteAction<List<Transaction>>(new object[] { filter }, BOConsts.GET_TRANSACTIONS);
        }

        static public List<BasicUser> GetTransferContacts(int userId)
        {
            return OutChannel.ExecuteAction<List<BasicUser>>(new object[] { userId }, BOConsts.GET_TRANSFER_CONTACTS);
        }
    }
}