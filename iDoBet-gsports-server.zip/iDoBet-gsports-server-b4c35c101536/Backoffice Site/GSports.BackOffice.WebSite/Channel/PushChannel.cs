﻿//using GSports.Common;
//using System;
//using System.Web;

//namespace GSports.BackOffice.WebSite.Channel
//{
//    public class PushChannel
//    {
//        public static void ConnectToPushServer()
//        {
//            try
//            {
//                var token = HttpContext.Current.Application["systemToken"].ToString();
//                if (token.IsNotNullOrEmpty())
//                {
//                    PushSeverClient.Instance.Connected += Instance_Connected;
//                    PushSeverClient.Instance.MessageReceived += Instance_MessageReceived;
//                    PushSeverClient.Instance.Connect(new PushServerCredentials { Token = token });                    

//                    //if (pushClientReady == null)
//                    //    pushClientReady = new ManualResetEvent(false);
//                }
//            }
//            catch (Exception ex)
//            {
//                GLogger.Logger.WriteLog(GLogger.eLogLevel.Fatal, "Backoffice coudn't connect to push server", ex);
//                //TODO alert
//            }
//        }

//        static void Instance_MessageReceived(PushServerMessage obj)
//        {
//            switch(obj.Channel)
//            {
//                case Channels.USER_CHANNEL:
                    
//                    break;
//            }
//        }

//        static void Instance_SystemMessageReceived(Service.Push.Model.Client.PushServerSystemMessage message)
//        {
//            //switch (message.Type)
//            //{
//            //    //in case received connection failure let the service know that the push reconnection 
//            //    case Service.Push.Model.Client.ePushSystemMessageType.ConnectFailure:
//            //        pushClientReady.Reset();
//            //        break;

//            //    //if connection is successful let the service know reconnection sequence has been ended 
//            //    case Service.Push.Model.Client.ePushSystemMessageType.ConnectSuccess:
//            //        if (!PushSeverClient.Instance.SubscribedChannel.Contains(GSports.Service.Push.Common.Consts.Channels.SYSTEM_CHANNEL))
//            //        {
//            //            PushSeverClient.Instance.SubscribeChannel(GSports.Service.Push.Common.Consts.Channels.SYSTEM_CHANNEL, true, true);
//            //        }
//            //        break;

//            //    //if subscribed successfully to event channel release all waiting threads 
//            //    case Service.Push.Model.Client.ePushSystemMessageType.SubscribeSuccess:
//            //        if (PushSeverClient.Instance.SubscribedChannel.Contains(GSports.Service.Push.Common.Consts.Channels.SYSTEM_CHANNEL))
//            //        {
//            //            pushClientReady.Set();
//            //            // Check Q  and publish
//            //        }
//            //        break;

//            //    //if couldn't subscribe to event channel let service know that push service is not ready
//            //    case Service.Push.Model.Client.ePushSystemMessageType.SubscribeFailure:
//            //        if (!PushSeverClient.Instance.SubscribedChannel.Contains(GSports.Service.Push.Common.Consts.Channels.SYSTEM_CHANNEL))
//            //        {
//            //            pushClientReady.Reset();
//            //        }
//            //        break;

//            //    default:
//            //        break;
//            //}
//        }

//        public static void PublishMessage(PushServerMessage msg)
//        {
//             PushSeverClient.Instance.Pusblish(msg);           
//        }

//        private static void Instance_Connected()
//        {
//            PushSeverClient.Instance.SubscribeChannel(Channels.SYSTEM_CHANNEL);
//            PushSeverClient.Instance.SubscribeChannel(Channels.USER_CHANNEL);
//            PushSeverClient.Instance.SubscribeChannel(Channels.EVENTS_CHANNEL);
//        }
        
//    }
//}