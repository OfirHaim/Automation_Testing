﻿using GSports.BackOffice.WebSite.Channel;
using GSports.BackOffice.WebSite.Models.Security;
using GSports.Model.BackOffice.CustomResults;
using GSports.Model.Consts;
using GSports.Model.Consts.BackOffice;
using GSports.Model.Consts.Security;
using GSports.Model.Entities;
using GSports.Model.Filter;
using GSports.Model.Requests.Configuration;
using GSports.Model.Requests.Metadata;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace GSports.Channel
{
    public class BetMetadataChannel
    {
        static public List<BaseEntity> GetItems(MetadataType type, long? parentId, BaseFilter filter)
        {
            return OutChannel.ExecuteAction<List<BaseEntity>>(new object[] { type, parentId, filter }, BOConsts.GET_ITEMS);
        }

        static public bool UpdateItems(List<BaseEntity> list, BaseEntity parentItem = null)
        {
            var desc = string.Format("Updated {0} items of type {1} ", (list != null && list.Any() ? list.Count : 0), (list != null && list.Any() ? list.FirstOrDefault().GetType().Name : "null"));
            var moreInfo = JsonConvert.SerializeObject(new {List = list, ParentItem = parentItem});

            return OutChannel.ExecuteAction<bool>(new object[] { list, parentItem }, BOConsts.UPDATE_ITEMS, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        static public UpdateItemsResult UpdateItemsWithResult(List<BaseEntity> list)
        {
            var desc = string.Format("Updated {0} items of type {1} ", (list != null && list.Any() ? list.Count : 0), (list != null && list.Any() ? list.FirstOrDefault().GetType().Name : "null"));
            var moreInfo = JsonConvert.SerializeObject(list);

            return OutChannel.ExecuteAction<UpdateItemsResult>(new object[] { list }, BOConsts.UPDATE_ITEMS_WITH_RESULT, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        static public bool DeleteItem(BaseEntity item)
        {
            var desc = string.Format("Deleted item of type {0}, Name: {1} ", item.GetType().Name, item.Name);
            var moreInfo = JsonConvert.SerializeObject(item);

            return OutChannel.ExecuteAction<bool>(new object[] { item }, BOConsts.DELETE_ITEM);
        }

        static public long CreateItem(BaseEntity item, IEnumerable<BaseEntity> childItems)
        {
            var desc = string.Format("Created new parent item of type {0}, Name: {1}" + (childItems != null && childItems.Any() ? " plus {2} child items of type {3}" : ""), item.GetType().Name, item != null ? item.Name : "null", (childItems != null && childItems.Any() ? childItems.Count() : 0), childItems == null ? null : childItems.FirstOrDefault().GetType());
            var moreInfo = JsonConvert.SerializeObject(new { Item = item, ChildItems = childItems });

            return OutChannel.ExecuteAction<long>(new object[] { item, childItems }, BOConsts.CREATE_ITEM, new LogData(desc, ePermissionsLevel.Create, moreInfo));
        }

        static public Dictionary<eConfigurationCode, string> GetConfigurationCode(SystemConfigurationRequest request)
        {
            return OutChannel.ExecuteAction<Dictionary<eConfigurationCode, string>>(new object[] { request }, BOConsts.GET_CONFIGURATIONCODE);
        }

        #region Limitations

        static public List<Limitation> GetLimitations(LimitationFilter filter)
        {
            return OutChannel.ExecuteAction<List<Limitation>>(new object[] { filter }, BOConsts.GET_LIMITATIONS);
        }

        static public bool SaveLimitation(List<Limitation> limitations)
        {
            var desc = "Updated limitation";
            var moreInfo = JsonConvert.SerializeObject(limitations);

            return OutChannel.ExecuteAction<bool>(new object[] { limitations }, BOConsts.SAVE_LIMITATIONS, new LogData(desc, ePermissionsLevel.Update, moreInfo));
        }

        //static public int CreateLimitation(Limitation limitation)
        //{
        //    var desc = "Created new limitation";
        //    var moreInfo = JsonConvert.SerializeObject(limitation);

        //    return OutChannel.ExecuteAction<int>(new object[] { limitation }, BOConsts.CREATE_LIMITATION, new LogData(desc, ePermissionsLevel.Create, moreInfo));
        //}

        //static public bool DeleteLimitation(int id)
        //{
        //    var desc = string.Format("Deleted limitation ID: {0} ", id);
        //    var moreInfo = JsonConvert.SerializeObject(id);

        //    return OutChannel.ExecuteAction<bool>(new object[] { id }, BOConsts.DELETE_LIMITATION, new LogData(desc, ePermissionsLevel.Delete, moreInfo));
        //}

        #endregion

    }
}