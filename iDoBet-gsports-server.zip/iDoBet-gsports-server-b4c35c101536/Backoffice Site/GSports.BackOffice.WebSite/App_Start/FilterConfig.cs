﻿using GSports.BackOffice.WebSite.BL;
using System.Web.Mvc;

namespace GSports.BackOffice.WebSite
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new MyHandleErrorAttribute());
            filters.Add(new AuthorizeUserAttribute());
        }
    }
}