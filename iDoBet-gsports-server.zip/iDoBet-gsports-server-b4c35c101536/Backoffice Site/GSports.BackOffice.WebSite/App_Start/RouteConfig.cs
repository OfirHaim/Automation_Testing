﻿using System.Web.Mvc;
using System.Web.Routing;

namespace GSports.BackOffice.WebSite
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            //routes.MapRoute(
            //    name: "coupon",
            //    url: "coupon",
            //    defaults: new { controller = "Public", action = "Coupon", id = 0 }
            //);
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Account", action = "Login", id = 0 }
            );
        }
    }
}