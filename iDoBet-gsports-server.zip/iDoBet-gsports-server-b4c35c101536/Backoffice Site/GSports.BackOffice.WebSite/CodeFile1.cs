﻿//.Model(m =>
// {
//     m.Id(p => p.Id);
//     m.Field(p => p.Name).Editable(false);
//     m.Field(p => p.SportType).Editable(true);
//     m.Field(p => p.ProviderId).Editable(false);
//})

                //.Columns(columns =>
                //{
                //    //columns.AutoGenerate(true);
                //    columns.Bound(p => p.Id).ClientTemplate("#= Id #" +
                //         "<input type='hidden' name='MyLines[#= index(data)#].Id' value='#= Id #' />");
                //    columns.Bound(p => p.Name).ClientTemplate("#= Name #" +
                //         "<input type='hidden' name='MyLines[#= index(data)#].Name' value='#= Name #' />");
                //    columns.Bound(p => p.SportType).ClientTemplate("#= SportType #" +
                //         "<input type='hidden' name='MyLines[#= index(data)#].SportType' value='#= SportType #' />");
                //    columns.Bound(p => p.ProviderId).ClientTemplate("#= ProviderId #" +
                //         "<input type='hidden' name='MyLines[#= index(data)#].ProviderId' value='#= ProviderId #' />");
                //})

//    $.ajax("/api/Translate/TranslateWord", {
//        type: "POST",
//        contentType: 'application/json; charset=utf-8',
//        data: JSON.stringify({ DiffuclityLevel: diffuclty })
//    }).success(function (data) {
//        $("#word").text(data.OriginalWord);
//        $("#translated").text("");

//        $.each(data.Translations, function (index, value) {
//            $("#translated").append(value + ", ");
//        });
//    });

///api/GSports/regenerateCode
///

//<div id="dialog">
//    <a id="lnkSelectAll">Select All</a> <a id="lnkDeselectAll">Deselect All</a>
//    <br /><br />
//            @(Html.Kendo().Grid<GSports.BackOffice.WebSite.Models.SportGameClient>()
//                .Name("GridDialog")
//                .AutoBind(false)
//                .Columns(columns =>
//                {
//                    columns.Template(@<text></text>).ClientTemplate(
//                    "<label><input type='checkbox' id='chkboxSelected#= dialogIndex(data)#' onchange='markCheckbox(#= dialogIndex(data)#)' /></label>"
//                    ).Width(50);
//                    columns.Bound(p => p.Time).ClientTemplate("#= Time #" +
//                    "<input type='hidden' name='Events[#= dialogIndex(data)#].Time' value='#= Time #' />"
//                  ).Width(250);
//                    columns.Bound(p => p.SportType.Name).ClientTemplate("#= SportType.Name #" +
//                    "<input type='hidden' name='Events[#= dialogIndex(data)#].SportType.Name' value='#= SportType.Name #' />"
//                  ).Title("SportType");
//                    columns.Bound(p => p.Country.Name).ClientTemplate("#= Country.Name #" +
//                    "<input type='hidden' name='Events[#= dialogIndex(data)#].Country.Name' value='#= Country.Name #' />"
//                  ).Title("Country");
//                    columns.Bound(p => p.League.Name).ClientTemplate("#= League.Name #" +
//                    "<input type='hidden' name='Events[#= dialogIndex(data)#].League.Name' value='#= League.Name #' />"
//                  ).Title("League");
//                    columns.Bound(p => p.Home).ClientTemplate("#= Home #" +
//                    "<input type='hidden' name='Events[#= dialogIndex(data)#].Home' value='#= Home #' />"
//                  );
//                    columns.Bound(p => p.Away).ClientTemplate("#= Away #" +
//                    "<input type='hidden' name='Events[#= dialogIndex(data)#].Away' value='#= Away #' />"
//                  );
//                    columns.Bound(p => p.Status).ClientTemplate("#= Status #" +
//                    "<input type='hidden' name='Events[#= dialogIndex(data)#].Status' value='#= Status #' />"
//                  );
//                    columns.Bound(p => p.Booked).ClientTemplate("#= Booked #" +
//                    "<input type='hidden' name='Events[#= dialogIndex(data)#].Booked' value='#= Booked #' />"
//                  );
//                })
//                        .Pageable(x => x.Enabled(false))
//                        .Sortable()
//                        .Scrollable(scr => scr.Height(700))
//                        .Filterable(GSports.BackOffice.WebSite.Helper.KendoSetup.filter)
//                        .DataSource(dataSource => dataSource
//                        .Ajax()
//                        .Events(events => events.Change("onChange"))
//                        .Events(events => events.Sync("onSync"))
//                        .Batch(true)
//                        .ServerOperation(false)
//                .Model(x =>
//                {
//                    x.Id(p => p.ID);
//                })
//                .Update(update => update.Action("UpdateSportGameDialog", "Data"))
//                .Read(read => read.Action("ReadSportGameDialog", "Data").Data("dates"))
//                ))
//    <div id="selected"></div>
//    <input type="button" value="Import" id="btnCloseImport" />

//    <label class="float-right">Games chosen: <span data-bind="text: counter"></span> / <span data-bind="text: total"></span></label>
//</div>

/*
@{
    ViewBag.Title = "Client Order";
}

@(Html.Kendo().Grid<GSports.BackOffice.WebSite.Models.ClientObjects.OrderEntityClient>()
        .Name("Grid")
        .HtmlAttributes(new { style = "height:100%; min-height:600px;" }) 
        .Columns(columns =>
        {
          columns.Bound(list => list.Id).Width(5).Hidden().HtmlAttributes(new {OrderId = "#=Id #" });
          columns.Bound(list => list.OrderNumber).Width(5);
          columns.Bound(list => list.CreateTime).Width(20);
          columns.Bound(list => list.Branch).Width(20);
          columns.Bound(list => list.Employee).Width(20);
          columns.Bound(list => list.Kiosk).Width(20);
          columns.Bound(list => list.Barcode).Width(20);
          columns.Bound(list => list.Amount).Width(20);
          columns.Bound(list => list.AmountToWin).Width(20);
          columns.Bound(list => list.WinStatus).Width(20);
          })
        .Sortable()
        .Pageable(pager => pager.PageSizes(new int[] {10, 25, 50}))      
        .Filterable(GSports.BackOffice.WebSite.Helper.KendoSetup.filter)
        .Scrollable(x => x.Enabled(false))
        .Sortable()
        .ClientDetailTemplateId("RowsTemplate")
        .Events(x => x.DetailExpand("grid_detailExpand"))
        .DataSource(dataSource => dataSource
            .Ajax()
            .Batch(true)
            .PageSize(25)
            .ServerOperation(false)
            .Model(model => { model.Id(p => p.Id); })
            .Read(read => read.Action("ReadOrders", "Data"))
            
        )
)

<script id="RowsTemplate">
    @(Html.Kendo().TabStrip()
            .Name("tabStrip_#=Id#")            
            .SelectedIndex(0)            
            .Animation(animation => animation.Open(open => open.Fade(FadeDirection.In)))
            .Items(items =>
            {
                items.Add().Text("Details").Content(  
                  @<text>
                    @(Html.Kendo().Grid<GSports.BackOffice.WebSite.Models.ClientObjects.OrderBetClient>()
                   .Name("Grid_#=Id#")
                   .Columns(columns =>
                   {
                       columns.Bound(list => list.Id).ClientGroupHeaderTemplate("&nbsp").ClientGroupFooterTemplate("");
                       columns.Bound(list => list.Date);
                       columns.Bound(list => list.Leauge);
                       columns.Bound(list => list.Game);
                       columns.Bound(list => list.BetType);
                       columns.Bound(list => list.Ratio);
                       columns.Bound(list => list.WinStatus);
                   })
                   .DataSource(dataSource => dataSource
                       .Ajax()
                       .Read(read => read.Action("HierarchyBinding_OrdersBets", "Data", new { betId = "#=Id#" }))
                       .ServerOperation(false)
                       .Model(model => { model.Id(p => p.Id); })
                       .Group(x => x.Add(y => y.Id))
                   )
                   .Sortable()
                   .ToClientTemplate())
    </text> 
                );
                items.Add().Text("Contact Information").Content(
                    "<div>" +
                        "<ul>" +
                            "<li><label>Country:</label></li>" +
                            "<li><label>City:</label></li>" +
                            "<li><label>Address:</label></li>" +
                            "<li><label>Home Phone:</label></li>" +
                        "</ul>" +
                    "</div>"
                );                
            })
            .Items(items =>
            {
                items.Add().Text("Previous Orders").Content(  
                  @<text>
                     @(Html.Kendo().Grid<GSports.BackOffice.WebSite.Models.ClientObjects.OrderBetClient>()
                   .Name("PRGrid_#=Id#")
                   .Columns(columns =>
                   {
                       columns.Bound(list => list.Id);
                       columns.Bound(list => list.Date);
                       columns.Bound(list => list.Leauge);
                       columns.Bound(list => list.Game);
                       columns.Bound(list => list.BetType);
                       columns.Bound(list => list.Ratio);
                       columns.Bound(list => list.WinStatus);
                   })
                   .DataSource(dataSource => dataSource
                       .Ajax()
                       .Read(read => read.Action("HierarchyBinding_OrdersBets", "Data", new { betId = "#=Id#" }))
                       .ServerOperation(false)
                       .Model(model => { model.Id(p => p.Id); })
                       .Group(x => x.Add(y => y.Id))
                   )
                   .Sortable()
                   .ToClientTemplate())
                    </text> 
                );
             })
            .ToClientTemplate())
</script>

<script>
    $(function () {
        //var grid = $("#Grid").data("kendoGrid");
        //debugger
        // $('div[id^="Grid_"]').on(

        //$("#Grid").kendoGrid({
        //    detailExpand: function (e) {
        //        alert("jnjn");
        //    }
        //});
    });



    //var footers;

    //function dodo(d)
    //{
    //    if (d.GridProps != null) {
    //        if (d.GridProps.length == 1)
    //            return "Bets Count: " + d.GridProps[0].NoOfBets + ", Amount: " + d.GridProps[0].Amount;
    //        if (d.GridProps.length > 1) {   
    //            footers = d;
    //        }
    //        footers = d;
    //    }
    //    else
    //        return "";
    //}

    //$("body").on("DOMNodeInserted", 'div[id^="Grid_"]', function () {
    //    alert("fdsvff");
    //    //$(this).children()[1].innerHTML = "test test";
    //    debugger
    //    //alert("khbsda");
    //});

    function grid_detailExpand(e)
    {
        var row = e.masterRow;
        var orderId = row[0].children[1].innerHTML;
        alert(orderId);
        debugger
    }
  
</script>

@*<script id="BetsTemplate">
                    @(Html.Kendo().Grid<GSports.BackOffice.WebSite.Models.ClientObjects.OrderRowEntityClient>()
                 .Name("Grid_#=Id#")
                 .Columns(columns =>
                 {
                     columns.Bound(list => list.BetsCount);
                     columns.Bound(list => list.Amount);
                     columns.Bound(list => list.WinStatus);
                     columns.Bound(list => list.AmountToWin);
                     columns.Bound(list => list.TotalRatio);
                 })
                 .DataSource(dataSource => dataSource
                     .Ajax()
                     .Read(read => read.Action("HierarchyBinding_OrdersRows", "Data", new { orderId = "#=Id#" }))
                     .ServerOperation(false)             
                     .Model(model => { model.Id(p => p.Id); })
                 )
                 .Sortable()
                  //.ClientDetailTemplateId("BetsTemplate")
                 .ToClientTemplate())
</script>*@


        function maxSelections(option, checked, ddl)
        {
            // Get selected options.
            var selectedOptions = $(ddl + 'option:selected');

            if (selectedOptions.length >= 10) {
                // Disable all other checkboxes.
                var nonSelectedOptions = $(ddl +'option').filter(function () {
                    return !$(this).is(':selected');
                });

                var dropdown = $(ddl).siblings('.multiselect-container');
                nonSelectedOptions.each(function () {
                    var input = $('input[value="' + $(this).val() + '"]');
                    input.prop('disabled', true);
                    input.parent('li').addClass('disabled');
                });
            }
            else {
                // Enable all checkboxes.
                var dropdown = $(ddl).siblings('.multiselect-container');
                $(ddl + 'option').each(function () {
                    var input = $('input[value="' + $(this).val() + '"]');
                    input.prop('disabled', false);
                    input.parent('li').addClass('disabled');
                });
            }
        }

 * 
 * <script id="poRowsTemplate">

    @*    @(Html.Kendo().TabStrip()
            .Name("poTabStrip_#=Id#")
            .SelectedIndex(0)
            .Animation(animation => animation.Open(open => open.Fade(FadeDirection.In)))
            .Items(items =>
            {
                items.Add().Text("Order Rows").Content("");
            })
            .ToClientTemplate()
     )*@

</script>

<script>

    //function poGrid_detailExpand(e) {
    //    var pRow = e.masterRow;
    //    var pOrderId = pRow[0].children[1].innerHTML;

    //    var pRowsData = $.grep(e.sender._data, function (item) {
    //        return item.Id == pOrderId;
    //    });
    //    pRowsData = pRowsData[0].Rows;
    //    $("#poOrderNo_" + pOrderId).empty();
    //    pRowsData.forEach(function (pRow) {

    //        $("#poOrderNo_" + pOrderId).append("<div class='rowGroup' id='pOrder_" + pOrderId + "pRow_" + pRow.Id + "'></div>");
    //        $("#pOrder_" + pOrderId + "pRow_" + pRow.Id).append("<div id='pGridForRow_" + pRow.Id + "'></div>");
    //        $("#pOrder_" + pOrderId + "pRow_" + pRow.Id).append("<div style='margin-top:7px;'>Total Selection: <strong>" + pRow.BetsCount + "</strong>, Amount: <strong><mark>" + pRow.Amount + "</mark></strong>, Amount To Win: <strong><mark>" + pRow.AmountToWin + "</strong></mark>, Win Status: <strong>" + pRow.WinStatus + "</strong>, Total Ratio: <strong>" + pRow.TotalRatio + "</strong></div>");

    //        $("#pOrder_" + pOrderId + "pRow_" + pRow.Id + " #pGridForRow_" + pRow.Id).kendoGrid({
    //            dataSource: {
    //                data: pRow.Bets,
    //            },
    //            scrollable: true,
    //            sortable: true,
    //            columns: [
    //                { field: "Date", title: "Date", width: "130px" },
    //                { field: "Leauge", title: "Leauge", width: "130px" },
    //                { field: "Game", title: "Game", width: "130px" },
    //                { field: "BetType", title: "BetType", width: "130px" },
    //                { field: "Ratio", title: "Ratio", width: "130px" },
    //                { field: "WinStatus", title: "WinStatus", width: "130px" }
    //            ]
    //        });
    //    });
    //}

</script>



*/