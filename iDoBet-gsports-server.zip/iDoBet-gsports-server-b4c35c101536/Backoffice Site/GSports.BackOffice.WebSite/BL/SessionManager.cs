﻿using GSports.BackOffice.WebSite.Models.Security;
using GSports.Model.Entities.User;
using System.Web;
using System.Web.Security;

namespace GSports.BackOffice.WebSite.BL
{
    public class SessionManager
    {
        public static CurrentUser CurrentUser
        {
            get
            {
                CurrentUser retVal = null;
                try
                {
                    var user = HttpContext.Current.Session["CurrentUser"];
                    if (user != null)
                        retVal = (CurrentUser)user;
                    else
                    {
                        retVal = new CurrentUser(null, null);
                        FormsAuthentication.SignOut();
                        //FormsAuthentication.RedirectToLoginPage(); ruins allowAnnonyms
                    }
                }
                catch
                {
                    retVal = new CurrentUser(null, null);
                }
                return retVal;
            }
        }

        public static bool HasUpdate()
        {
            bool retVal = false;

            if (HttpContext.Current.Session["HasUpdate"] is bool)
                retVal = true;
            
            return retVal;
        }

        public static void AddUser(OperatorUser user, string ip)
        {
            HttpContext.Current.Session["CurrentUser"] = new CurrentUser(user, ip);
            NemiTon.Instance.Users[user.Id] = new UserNotification();
        }

        public static void UpdateUser(OperatorUser user)
        {
            HttpContext.Current.Session["CurrentUser"] = new CurrentUser(user, CurrentUser.IpAddress);
        }
    }
}