﻿//using GSports.Channel;
//using GSports.Common;
//using GSports.Model.Entities;
//using GSports.Model.Entities.Event;
//using GSports.Model.Entities.Excel;
//using GSports.Model.Filter;
//using GSports.Model.Requests.Metadata;
//using NPOI.HSSF.Record;
//using NPOI.HSSF.UserModel;
//using NPOI.SS.UserModel;
//using NPOI.SS.Util;
//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Web;
//using System.Xml;

//namespace GSports.BackOffice.WebSite.BL
//{
//    public class ExcelExport
//    {
//        public static MemoryStream Export(int excelSettingId, List<SportGame> events)
//        {
//            if (events == null || events.Count == 0 || excelSettingId <= 0)
//                return null;

//            #region Local Vars

//            const string BET_KEY = "{0}_{1}";
//            var _dynamicCell = new Dictionary<string, Dictionary<string, int>>();
//            var _headerDic = new Dictionary<int, string>();
//            var _formatDic = new Dictionary<string, int>();
//            var _betTypesPos = new List<int>();
//            var _twiceColSize = new List<int>();

//            #endregion

//            #region Loads data from DB

//            ExcelSettings excelSetting = (ExcelSettings)BetMetadataChannel.GetItems(MetadataType.ExcelSettings, null, new ExcelSettingsFilter() { Ids = new List<long>() { excelSettingId } }).FirstOrDefault();
//            var sortedExcelBetTypes = excelSetting.ExcelBetTypes.OrderBy(x => x.Order).ToList();

//            var ids = new List<long>();
//            foreach (var item in sortedExcelBetTypes)
//            {
//                ids.Add(item.BetType.Id);
//            }

//            var betTypesTemplate = BetMetadataChannel.GetItems(MetadataType.BetType, null, new BetTypeFilter() { Ids = ids }).ConvertAll(x => (BetType)x);
            
//            var excelBetTypes = new List<BetType>();
//            foreach (var item in sortedExcelBetTypes)
//            {
//                var bt = (BetType)betTypesTemplate.FirstOrDefault(x => x.Id == item.BetType.Id);
//                excelBetTypes.Add(new BetType() { Id = bt.Id, Name = bt.Name, ShortName = bt.ShortName, Line = item.Line, Odds = bt.Odds });
//            }

//            events = events.OrderBy(x => x.GameNumber).ToList();

//            #endregion       
  
//            #region Load xml settings
//            var doc = new XmlDocument();
//            doc.Load(HttpContext.Current.Server.MapPath("~/ExcelConfig.xml"));

//            var headerFontSize = Convert.ToInt16(doc.GetElementsByTagName("StaticHeaders")[0].Attributes["fontSize"].Value);
//            var dynamicHeaderFontsize = doc.GetElementsByTagName("DynamicHeader")[0].Attributes["fontSize"].Value;
//            var rowHeight = Convert.ToInt16(doc.GetElementsByTagName("Rows")[0].Attributes["Height"].Value);
//            var rowWidth = Convert.ToInt16(doc.GetElementsByTagName("Rows")[0].Attributes["Width"].Value);
//            var headerLogoFontSize = Convert.ToInt16(doc.GetElementsByTagName("Header")[0].Attributes["fontSize"].Value);
//            var rowFontSize = Convert.ToInt16(doc.GetElementsByTagName("Rows")[0].Attributes["fontSize"].Value);
//            var StaticHeaders = doc.GetElementsByTagName("StaticHeader");

//            #endregion

//            #region calculate number of columns

//            int numberOfCols = 0;
//            foreach (BetType item in excelBetTypes)
//            {
//                numberOfCols += item.Odds.Count;
//            }
//            numberOfCols += StaticHeaders.Count;
//            #endregion

//            #region Styling

//            //Create new Excel workbook
//            var workbook = new HSSFWorkbook();

//            //Create new Excel sheet
//            var sheet = new HSSFSheet(workbook);

//            //Styling
//            IFont generalFont = workbook.CreateFont();
//            generalFont.FontName = "Bookman Old Style";
//            generalFont.FontHeightInPoints = rowFontSize;

//            sheet.DefaultRowHeightInPoints = rowHeight;
//            sheet.DefaultColumnWidth = rowWidth;

//            var style = workbook.CreateCellStyle();
//            style.SetFont(generalFont);

//            style.Alignment = HorizontalAlignment.Center;
//            style.VerticalAlignment = VerticalAlignment.Top;

//            style.BorderBottom = BorderStyle.Thin;
//            style.BorderLeft = BorderStyle.Thin;
//            style.BorderRight = BorderStyle.Thin;
//            style.BorderTop = BorderStyle.Thin;

//            IFont headerFont = workbook.CreateFont();
//            headerFont.FontHeightInPoints = headerFontSize;
//            headerFont.Boldweight = (short)FontBoldWeight.Bold;

//            for (int i = 0; i < numberOfCols; i++)
//            {
//                sheet.SetDefaultColumnStyle(i, style);
//            }

//            //Set header and footer
//            sheet.Header.Center = excelSetting.HeaderText == "" ? "" : "&B &" + headerLogoFontSize + " &\"Bookman Old Style\"" + excelSetting.HeaderText + "\n &" + headerLogoFontSize * 0.75 + " &\"Bookman Old Style\"" + events.FirstOrDefault().EventDate.ToString("dddd, dd MMMM, yyyy") + "\n";
//            sheet.Footer.Center = "&B &26 &\"Bookman Old Style\"" + excelSetting.FooterText + "\n &B &20 Page " + HeaderFooter.Page + " of " + HeaderFooter.NumPages;

//            //Sets borders for header
//            int counter = 0;
//            foreach (var item in StaticHeaders)
//            {
//                sheet.AddMergedRegion(new CellRangeAddress(0, 2, counter, counter));
//                counter++;
//            }

//            #endregion

//            #region Inserts Static Headers

//            //Create a header row
//            var headerRow = sheet.CreateRow(0);

//            int cellNumber = 0;
//            foreach (var item in StaticHeaders.OfType<XmlNode>())
//            {
//                string prop = string.Empty;
//                //set the width of the columns
//                sheet.SetColumnWidth(cellNumber, Convert.ToInt32(item.Attributes["Width"].Value) * 256);
//                //Set the column names in the header row
//                var cell = headerRow.CreateCell(cellNumber);

//                cell.SetCellValue(item.InnerText);
//                cell.RichStringCellValue.ApplyFont(headerFont);

//                prop = item.Attributes["Property"].Value;
//                _formatDic[item.Attributes["Property"].Value] = Convert.ToInt16(item.Attributes["MaxLength"].Value); //TODO
//                _headerDic.Add(cellNumber, prop);
//                cellNumber++;
//            }

//            #endregion

//            #region Inserts BetType Headers

//            //saves the column 
//            int dynamicStartCol = cellNumber;

//            foreach (BetType bt in excelBetTypes)
//            {
//                var cell = headerRow.CreateCell(cellNumber);
//                cell.SetCellValue((string.IsNullOrEmpty(bt.ShortName) ? bt.Name : bt.ShortName) + (bt.Line == null ? "" : "(" + bt.Line + ")"));
//                cell.RichStringCellValue.ApplyFont(headerFont);

//                sheet.AddMergedRegion(new CellRangeAddress(0, 0, cellNumber, cellNumber + bt.Odds.Count - 1));
//                _betTypesPos.Add(cellNumber);
//                cellNumber += bt.Odds.Count;
//            }

//            var oddsShortCutRow = sheet.CreateRow(1);
//            var oddsShortNameRow = sheet.CreateRow(2);

//            foreach (BetType bt in excelBetTypes)
//            {
//                var oddDictionary = new Dictionary<string, int>();

//                var sortedOdds = sortedExcelBetTypes.Where(x => x.BetType.Id == bt.Id).FirstOrDefault().OddsOrder.Split(',').ToList();
//                var betsOrderedByExcelSetting = bt.Odds.OrderBy(x => sortedOdds.IndexOf(x.Name)).ToList();

//                foreach (var odd in betsOrderedByExcelSetting)
//                {
//                    var cell = oddsShortCutRow.CreateCell(dynamicStartCol);
//                    string formatResult  = null;
//                    if(odd.Shortcut.TryFormat(out formatResult,bt.Line))
//                        cell.SetCellValue(formatResult);
//                    else
//                        cell.SetCellValue(odd.Shortcut??"");


//                    cell.RichStringCellValue.ApplyFont(headerFont);

//                    cell = oddsShortNameRow.CreateCell(dynamicStartCol);
//                    cell.SetCellValue(odd.ShortName.IsNotNullOrEmpty() ? odd.ShortName : odd.Name);
//                    cell.RichStringCellValue.ApplyFont(headerFont);

//                    oddDictionary.Add(odd.Name, dynamicStartCol);
//                    dynamicStartCol++;
//                }
//                var key = string.Format(BET_KEY, bt.Id.ToString(), bt.Line);
//                _dynamicCell.Add(key, oddDictionary);
//            } 
//            #endregion

//            #region Inserts events to grid

//            int rowCounter = 3;
//            var currentDay = events.FirstOrDefault().EventDate.Day;

//            foreach (var e in events)
//            {
//                var currentRow = sheet.CreateRow(rowCounter);

//                //checking for setting margin for new day
//                #region Breaks a new line for a new day if neccessery 
//                if (e.EventDate.Day > currentDay)
//                {
//                    //set margin 
//                    sheet.AddMergedRegion(new CellRangeAddress(rowCounter, rowCounter, 0, numberOfCols - 1));
//                    //write new date in cell (bold)
//                    var cell = currentRow.CreateCell(0);
//                    cell.SetCellValue(e.EventDate.ToString("dddd, dd MMMM, yyyy"));
//                    cell.RichStringCellValue.ApplyFont(headerFont);
//                    //currentRow.HeightInPoints = 50;
//                    //up the current row by 1
//                    currentDay = e.EventDate.Day;
//                    currentRow = sheet.CreateRow(++rowCounter);
//                } 
//                #endregion

//                string text = string.Empty;
                
//                #region Sets Event's metadata
//                foreach (var props in _headerDic)
//                {
//                    foreach (var item in props.Value.Split(','))
//                    {
//                        var val = e.GetPropertyInfo(item);
//                        if (val==null)
//                            continue;
//                        else
//                        {
//                            if (val is DateTime)
//                                text = ((DateTime)val).ToString("HH:mm");
//                            else
//                            {
//                                text = val.ToString();
//                                if (text.Length > _formatDic[props.Value])
//                                    text = text.Substring(0, _formatDic[props.Value]) + "..";
//                            }
//                            break;
//                        }
//                    }
                    

//                    //foreach (var item in prop.Value)
//                    //{
//                    //    if (item.Key.ToString().Substring(0, 1) == "%")
//                    //    {
//                    //        var val = e.GetType().GetProperty(item.Value);
//                    //        text = val.GetValue(e).ToString();
//                    //        if (text.Length > _formatDic[item.Key])
//                    //            text = text.Substring(0, _formatDic[item.Key]) + "..";
//                    //        if (val.GetValue(e) is DateTime)
//                    //            text = ((DateTime)val.GetValue(e)).ToString("HH:mm");
//                    //    }
//                    //    else
//                    //    {
//                    //        var val = e.GetType().GetProperty(item.Key).GetValue(e);
//                    //        text = val.GetType().GetProperty(item.Value).GetValue(val).ToString();
//                    //        if (text.Length > _formatDic[item.Key])
//                    //            text = text.Substring(0, _formatDic[item.Key]) + "..";
//                    //    }
//                    //}

//                    currentRow.CreateCell(props.Key).SetCellValue(text);
//                } 
//                #endregion

//                #region Sets Event's Odds 
//                foreach (var item in _dynamicCell)
//                {
//                    var betId = item.Key.Split('_')[0];
//                    var betLine = item.Key.Split('_')[1];
//                    var betType = e.BetTypes.SingleOrDefault(bt => bt.Id.ToString() == betId);

//                    if (betType != null && betType.Odds.Count > 0)
//                    {
//                        foreach (var cell in item.Value)
//                        {
//                            switch  (betType.Id)
//                            {
//                                //Handicap
//                                case 3131 :
//                                {
//                                    var sortedOdds = Model.Helper.SortOddsByClosestPrice(betType).FirstOrDefault();

//                                    var odd = sortedOdds.Odds.Where(o => o.Name.ToLower().Trim() == cell.Key.ToLower().Trim()).SingleOrDefault();
//                                    var homeFor = string.Empty;
//                                    var awayFor = string.Empty;
//                                    if(odd.Line!=null)
//                                    {
//                                         string[] oddLines =  odd.Line.Split(':');
//                                        if(oddLines.Count() == 2)
//                                        {
//                                            if (oddLines[0]!="0")
//                                                homeFor = " (+" + oddLines[0] + ")";
//                                            if (oddLines[1] != "0")
//                                                awayFor = " (+" + oddLines[1] + ")";
//                                        }
//                                    }                                    
//                                    if (odd != null)
//                                    {
//                                        var cellData = odd.CurrentPrice.ToString();
//                                        // home
//                                        if(odd.Name =="1" && !string.IsNullOrEmpty(homeFor))
//                                            cellData += homeFor;
//                                        //Away
//                                        else if(odd.Name =="2" && !string.IsNullOrEmpty(awayFor))
//                                            cellData += awayFor;
//                                        currentRow.CreateCell(cell.Value).SetCellValue(cellData);
//                                    }

//                                    _twiceColSize.Add(cell.Value);

//                                    break;

//                                }
//                                default :
//                                {
//                                    var odd = betType.Odds.Where(o => o.Name.ToLower().Trim() == cell.Key.ToLower().Trim() && (o.Line == null || o.Line == betLine)).SingleOrDefault();
//                                    if (odd != null)
//                                    {
//                                        currentRow.CreateCell(cell.Value).SetCellValue(odd.CurrentPrice.ToString());
//                                    }
//                                    break;
//                                }
//                            }
                           
//                        }
//                    }
//                } 
//                #endregion

//                rowCounter++;
//            }

//            #endregion

//            #region Styling adjustment & Page Setup

//            //adds the sheet to workbook;
//            sheet.Workbook.Add(sheet);

//            //setting bold borders
//            sheet.SetBorderBottomOfRegion(new CellRangeAddress(0, 2, 0, numberOfCols - 1), BorderStyle.Thick, IndexedColors.Black.Index);
//            sheet.SetBorderTopOfRegion(new CellRangeAddress(0, rowCounter - 1, 0, dynamicStartCol-1), BorderStyle.Thick, IndexedColors.Black.Index);
//            sheet.SetBorderBottomOfRegion(new CellRangeAddress(0, rowCounter - 1, 0, dynamicStartCol-1), BorderStyle.Thick, IndexedColors.Black.Index);
//            sheet.SetBorderRightOfRegion(new CellRangeAddress(0, rowCounter - 1, 0, dynamicStartCol-1), BorderStyle.Thick, IndexedColors.Black.Index);
//            sheet.SetBorderLeftOfRegion(new CellRangeAddress(0, rowCounter - 1, 0, dynamicStartCol-1), BorderStyle.Thick, IndexedColors.Black.Index);

//            for (int i = 1; i <= StaticHeaders.Count; i++)
//            {
//                sheet.SetBorderLeftOfRegion(new CellRangeAddress(0, rowCounter - 1, i, i+1), BorderStyle.Thick, IndexedColors.Black.Index);
//            }
//            foreach (var item in _betTypesPos)
//            {
//                sheet.SetBorderLeftOfRegion(new CellRangeAddress(0, rowCounter - 1, item, item + 1), BorderStyle.Thick, IndexedColors.Black.Index);
//            }

//            foreach (var item in _twiceColSize)
//            {
//                sheet.SetColumnWidth(item, rowWidth * 256 * 2);
//            }

//            //freeze the header row so it is not scrolled
//            sheet.CreateFreezePane(0, 3, 0, numberOfCols);

//            //Page Setup
//            workbook.SetPrintArea(0, 0, dynamicStartCol, 0, rowCounter - 1);

//            //repeat betType info every page
//            sheet.RepeatingRows = new CellRangeAddress(0, 2, 0, 1);           

//            sheet.SetMargin(MarginType.LeftMargin, 0);
//            sheet.SetMargin(MarginType.RightMargin, 0);
//            sheet.SetMargin(MarginType.HeaderMargin, 0);
//            sheet.SetMargin(MarginType.FooterMargin, 0);
//            sheet.SetMargin(MarginType.TopMargin, excelSetting.HeaderText == "" ? 0 : 1.2);

//            var ps = new PrintSetupRecord();
//            ps.Landscape = true;
//            ps.PaperSize = 9;
//            ps.FitWidth = 1;
//            ps.FitHeight = 100;
            
//            sheet.FitToPage = true;
//            sheet.PrintSetup.FitWidth = ps.FitWidth;
//            sheet.PrintSetup.FitHeight = ps.FitHeight;
//            sheet.HorizontallyCenter = true;
//            sheet.DisplayGridlines = false;
//            sheet.PrintSetup.Landscape = ps.Landscape;
//            sheet.PrintSetup.PaperSize = ps.PaperSize;

//            #endregion

//            #region Output

//            //Write the workbook to a memory stream
//            MemoryStream output = new MemoryStream();
//            workbook.Write(output);

//            return output;

//            #endregion
//        }
//    }
//}