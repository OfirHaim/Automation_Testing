﻿using System;
using System.Web.Mvc;

namespace GSports.BackOffice.WebSite.BL
{
    public class MyHandleErrorAttribute : HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
            var errorCode = DateTime.Now.ToString("ddMMyyHHmmsss");
            var isAjax = filterContext.HttpContext.Request.Headers["X-Requested-With"] == "XMLHttpRequest";
            if (isAjax)
            {
                filterContext.Result = new JsonResult()
                {
                    Data = string.Format("Sorry, An error occurred while processing your request.\nError Code: {0}\n Error Exception: {1}", errorCode, filterContext.Exception),
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
                filterContext.HttpContext.Response.StatusCode = 501;
                filterContext.ExceptionHandled = true;
                filterContext.HttpContext.Response.Clear();
            }
            else
            {
                //base.OnException(filterContext);

                filterContext.Controller.TempData.Add("errorCode", errorCode);
                filterContext.Controller.TempData.Add("expMsg", filterContext.Exception.Message);
                var controllerName = (string)filterContext.RouteData.Values["controller"];
                var actionName = (string)filterContext.RouteData.Values["action"];
                var model = new HandleErrorInfo(filterContext.Exception, controllerName, actionName);
                filterContext.Result = new ViewResult
                {
                    ViewName = View,
                    MasterName = Master,
                    ViewData = new ViewDataDictionary<HandleErrorInfo>(model),
                    TempData = filterContext.Controller.TempData
                };
            }

            var logMsg = string.Format("ErrorCode: {0}, isAjax:{1}, Controller: {2}, Action: {3}", errorCode, isAjax, filterContext.RouteData.Values["controller"], filterContext.RouteData.Values["action"]);
            GLogger.Logger.WriteLog(GLogger.eLogLevel.Error, logMsg, filterContext.Exception);
        }
    }
}