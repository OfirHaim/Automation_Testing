﻿using GSports.Common.RecieptHelper;
using GSports.BackOffice.WebSite.Channel;
using GSports.BackOffice.WebSite.Helper;
using GSports.BackOffice.WebSite.Models;
using GSports.BackOffice.WebSite.Models.ClientObjects;
using GSports.BackOffice.WebSite.Resources;
using GSports.Common;
using GSports.Model.Consts;
using GSports.Model.Consts.Notifications;
using GSports.Model.Consts.Security;
using GSports.Model.Entities;
using GSports.Model.Entities.Event;
using GSports.Model.Entities.LocalSystem;
using GSports.Model.Entities.Order;
using GSports.Model.Entities.User;
using GSports.Model.Security;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using GSports.Model.Entities.Reports;
using GSports.Model.Entities.Finance;
using GSports.Model.Entities.Event.VirtualGames;

namespace GSports.BackOffice.WebSite.BL
{
    public class ClientObjects
    {
        static string Winner = EnumResourceTranslator.Translate<eWinStatus>(eWinStatus.Winner).ToString();
        static string Loser = EnumResourceTranslator.Translate<eWinStatus>(eWinStatus.Loser).ToString();
        static string MoneyBack = EnumResourceTranslator.Translate<eWinStatus>(eWinStatus.MoneyBack).ToString();
        static string Pending = EnumResourceTranslator.Translate<eWinStatus>(eWinStatus.Pending).ToString();
        static string Unknown = EnumResourceTranslator.Translate<eWinStatus>(eWinStatus.Unknown).ToString();

        public static List<ReportAgentAccount> GetAccountReportSummary(List<AccountReportSummary> list)
        {
            var retVal = new List<ReportAgentAccount>();

            foreach (var item in list)
            {
                ReportAgentAccount client = new ReportAgentAccount();
                
                client.Id = item.User.Id;
                client.FirstName = item.User.FirstName;
                client.LastName = item.User.LastName;
                client.UserName = item.User.UserName;
                if (item.Branch != null)
                {
                    client.BranchId = item.Branch.Id;
                    client.BranchName = item.Branch.Name;
                }
                client.Sales = item.Sales;
                client.CountSales = item.CountSales;
                client.CountPayouts = item.CountPayout;
                client.Payouts = item.Payout;
                client.NetCash = item.NetCash;
                client.Tax = item.Tax;
                client.Bonus = item.BonusCash;
                client.ReportDate = item.ReportDate;
                client.Comission = item.Commission;
                retVal.Add(client);
            }

            return retVal;
        }
        public static List<SportGameClient> GetClientsGames(List<SportGame> list, List<CouponEvent> couponEvents)
        {
            List<SportGameClient> retVal = null;
            if (list != null)
            {
                retVal = new List<SportGameClient>();


                foreach (var item in list)
                {
                    List<ScreenViewModel> screens = new List<ScreenViewModel>();

                    var couponEvent = couponEvents?.FirstOrDefault(x => x.EventId == item.Id);
                    if (couponEvent?.Screens != null)
                            couponEvent.Screens.ForEach(x => screens.Add(new ScreenViewModel() { Id = x.Id, Name = x.Name }));                        

                    string oneXTwoText = string.Empty;
                    if (item.BetTypes != null && item.BetTypes.Any())
                    {
                        var bt = item.BetTypes.First();
                        if (bt.Odds != null && bt.Odds.Any())
                        {
                            bt.Odds.OrderBy(x => x.Order).ToList().ForEach(x =>
                            {
                                //oneXTwoText += string.Format("<b>{0}</b>: {1,-8:n2}", x.ToString().Trim(), x.CurrentPrice);
                                oneXTwoText += string.Format("{0,-8:n2}", x.CurrentPrice);
                            });
                        }
                    }

                    retVal.Add(new SportGameClient()
                    {
                        FinishTime = item is VirtualGame ? ((VirtualGame)item).FinishTime : (DateTime?)null,
                        ID = item.Id,
                        Stadium= item is VirtualSoccer ? ((VirtualSoccer)item).Stadium : null,
                        Distance = item is VirtualRace ? ((VirtualRace)item).Distance : null,
                        ProviderKey = item.ProviderKey,
                        GameNumber = item.GameNumber,
                        Time = item.EventDate,
                        UtcTime = item.EventDate.ToString(),
                        SportType = new SportTypeClient() { Id = item.SportType.Id, Name = (item.SportType.Order.HasValue ? item.SportType.Order : 0) + "^" + item.SportType.Name , Order = item.SportType.Order},
                        Country = new CountryClient() { Id = item.Country.Id, Name = string.IsNullOrEmpty(item.Country.ShortName) ? item.Country.Name : item.Country.ShortName,Order = item.Country.Order },
                        League = new LeagueClient() { Id = item.League.Id, Name = string.IsNullOrEmpty(item.League.ShortName) ? item.League.Name : item.League.ShortName , Order = item.League.Order},
                        Home = item.HomeTeam !=null ? new TeamClient() { Id = item.HomeTeam.Id, Name = string.IsNullOrEmpty(item.HomeTeam.ShortName) ? item.HomeTeam.Name : item.HomeTeam.ShortName }:null,
                        Away = item.HomeTeam != null ? new TeamClient() { Id = item.AwayTeam.Id, Name = string.IsNullOrEmpty(item.AwayTeam.ShortName) ? item.AwayTeam.Name : item.AwayTeam.ShortName }:null,
                        Status = item.EventStatus.ToString(),
                        Booked = item.IsBooked,
                        BookCoverage = item.LiveProps == null ? "" : EnumResourceTranslator.Translate<eCoveredFrom>(item.LiveProps.CoveredFrom),
                        WithOdds = item.LiveBetTypeCount > 0 || item.PrematchBetTypeCount > 0,
                        NoOfBetTypes = item.PrematchBetTypeCount + item.LiveBetTypeCount,
                        HasAlert = item.OpenAlertTime != null,
                        LastAlertTime = item.OpenAlertTime != null ? DateHelper.GetDateFormat(item.OpenAlertTime) : null,
                        Liveable = item.AllowLive.HasValue ? item.AllowLive.Value : false,
                        NeutralGrounds = item.NeutralGrounds,
                        TVChannels = item.TvChannels == null ? null : "TV Channels: " + string.Join(", ", item.TvChannels),
                        GeneralInfo = item.GeneralInformation == null ? null : "General info: " + string.Join(", ", item.GeneralInformation),
                        Screens = screens,
                        IsActive = item.EventStatus == eEventStatus.Live || item.EventStatus == eEventStatus.Prematch,
                        oneXtwo = oneXTwoText,
                        ExistsInCoupon = item.CurrentCouponId > 0,
                        IsTopEvent = (couponEvent == null ? false : couponEvent.IsTopEvent)
                    });
                }
            }
            return retVal;
        }

        public static List<CouponClient> GetClientsCoupons(List<Coupon> list)
        {
            List<CouponClient> retVal = null;

            if (list != null)
            {
                retVal = new List<CouponClient>();

                foreach (var item in list)
                {
                    retVal.Add(new CouponClient()
                    {
                        ID = item.Id,
                        CouponName = item.Name,
                        CreateDate = item.CreateDate,
                        FromDate = item.FromDate,
                        ToDate = item.ToDate,
                        MatchCount = item.MatchCount,
                        AutoUpdate = item.TimeToUpdate > 0 ? true : false,
                        TimeToUpdate = item.TimeToUpdate ?? 0,
                        IsActive = item.IsActive
                    });
                }
            }

            return retVal;
        }

        public static OrderEntityClient GetOrderEntityClient(OrderEntity order)
        {
            OrderEntityClient retVal = null;

            if (order != null)
            {
                retVal = new OrderEntityClient()
                {
                    Id = order.Id,
                    OrderNumber = order.OrderNumber,
                    ExternalId = order.ExternalId,
                    TransactionId = order.TransactionId,
                    CreateTime = order.CreateTime.ToString(Helper.DateHelper.MAIN_FORMAT),
                    ExpiryDate = order.ExpiryDate.ToString(Helper.DateHelper.MAIN_FORMAT),
                    Branch = order.Branch.Name,
                    BranchId= order.Branch.Id,
                    Employee = order.Employee.FirstName + " " + order.Employee.LastName,
                    EmployeeId= order.Employee.Id,
                    Kiosk = order.Terminal.Name,
                    Barcode = order.Barcode,
                    Amount = order.Amount.ToCommaString(),
                    MaxPayout = order.MaxPayout.ToCommaString(),
                    WinStatus = EnumResourceTranslator.Translate<eWinStatus>(order.WinStatus).ToString(),
                    Rows = GetOrderRowEntityClient(order.OrderRows),
                    //CancelButtonText = order.Status == eOrderStatus.Cancelled ? "Undo Cancel" : (order.Status == eOrderStatus.Sold ? "Cancel Order" : ""),
                    OrderStatus = order.Status,
                    CancelTime = order.CancelTime.HasValue ? order.CancelTime.Value.ToString(Helper.DateHelper.MAIN_FORMAT) : null,
                    CanceledBy = order.CanceledBy == null ? "-" : order.CanceledBy.FirstName + " " + order.CanceledBy.LastName,
                    CancellationCategory = order.CancelReasonType == null ? "-" : order.CancelReasonType.Name,
                    CancellationReason = order.CancellationReason == null ? "-" : order.CancellationReason,
                    PaidTime = order.CheckoutTime.HasValue ? order.CheckoutTime.Value.ToString(Helper.DateHelper.MAIN_FORMAT) : null,
                    PaidBy = order.CheckedoutBy == null ? "-" : order.CheckedoutBy.FirstName + " " + order.CheckedoutBy.LastName,
                    PaidById = order.CheckedoutBy == null ? "-" : order.CheckedoutBy.Id.ToString() ,
                    ShowLock = order.Status == eOrderStatus.Sold,
                    ShowUnlock = order.LockedUntil.HasValue ? (order.LockedUntil.Value >= DateTime.Now) : false,
                    LockedUntil = DateHelper.GetDateFormat(order.LockedUntil.HasValue ? (DateTime?)order.LockedUntil.Value.AddYears(-Convert.ToInt32(ConfigurationManager.AppSettings["LockLengthYears"])) : null),
                    ActualPayout = order.ActualPayout.ToCommaString(),
                    TotalSelections = order.TotlaSelection,
                    TotalLines = order.TotlaLines,
                    OrderProd = order.OrderProd.ToString(),
                    LockedReason = order.LockedReason,
                    LockedBy = order.LockedBy == null ? "-" : (order.LockedBy.FirstName + " " + order.LockedBy.LastName),
                    PaidBranch = order.CheckedoutBranch == null ? " " : order.CheckedoutBranch.Name,
                    PaidTerminal = order.CheckedoutTerminal == null ? " " : order.CheckedoutTerminal.Name,
                    ParentId = order.ParentId,
                    SoldTime = order.SoldTime.HasValue ? order.SoldTime.Value.ToString(Helper.DateHelper.MAIN_FORMAT) : " -",
                    SettledTime = order.SettledTime.HasValue ? order.SettledTime.Value.ToString(Helper.DateHelper.MAIN_FORMAT) : " -",
                    OrderWinStatus = string.Format("{0} - {1}", EnumResourceTranslator.Translate<eOrderStatus>(order.Status), EnumResourceTranslator.Translate<eWinStatus>(order.WinStatus)),
                    Currency = order.OrderCurrency == null ? "" : order.OrderCurrency.Name,
                    Commission = order.TotalCommission.HasValue ? order.TotalCommission.Value.ToCommaString() : "0",
                    IsEditAllowed = (!SessionManager.CurrentUser.User.Branches.Any() || SessionManager.CurrentUser.User.Branches.Any(x => x.Id == order.Branch.Id)) && !order.CheckoutTime.HasValue && UserSecurity.IsAllowed(CodeAttribute.Activity.ClientOrder, ePermissionsLevel.Update)
                };
            }

            return retVal;
        }
   
        public static List<MiniOrderEntityClient> GetMiniOrderEntityClient(List<OrderEntity> list)
        {
            List<MiniOrderEntityClient> retVal = new List<MiniOrderEntityClient>();

            if (list.IsNotNullAndAny())
            {
                retVal = new List<MiniOrderEntityClient>();
                var printSiteUrl = ConfigurationManager.AppSettings["PrintSiteURL"];
                var userToken = UserSecurity.GetUserToken();

                foreach (var item in list)
                {
                    retVal.Add(new MiniOrderEntityClient()
                    {

                        Id = item.Id,
                        ExternalId = item.ExternalId,
                        OrderNumber = item.OrderNumber,
                        CreateTime = item.CreateTime,
                        Branch = item.Branch.Name,
                        Employee = item.Employee.FirstName + " " + item.Employee.LastName,
                        Kiosk = item.Terminal.Name,
                        Amount = item.Amount,
                        MaxPayout = item.MaxPayout,
                        Status = string.Format("{0} {1} {2}", (item.CancelTime.HasValue ? "Canceled" : EnumResourceTranslator.Translate<eWinStatus>(item.WinStatus)), (item.CheckoutTime.HasValue ? " Paid" : (!item.CheckoutTime.HasValue && item.IsPayout ? " Not Paid" : "")), item.CancelUserRole),
                        WinStatus = EnumResourceTranslator.Translate<eWinStatus>(item.WinStatus).ToLower(),
                        ActualPayout = item.ActualPayout,
                        Bonus = item.TotalBonus ?? 0,
                        TotalSelections = item.TotlaSelection,
                        TotalLines = item.TotlaLines,
                        OrderProd = item.OrderProd.ToString(),
                        IsLocked = item.LockedUntil.HasValue,
                        IsCanceled = item.CancelTime.HasValue,
                        CancellReason= item.CancellationReason,
                        CancelledCategory = item.CancelReasonType==null ? "": item.CancelReasonType.Name,
                        Currency = item.OrderCurrency == null ? "" : item.OrderCurrency.Name,
                        Commission = item.TotalCommission ?? 0,
                        RecieptUrl = string.Format("{0}?q={1}", printSiteUrl, PrintService.GetOrderKey(userToken, item.RequestGuid, false, 280)),
                        IsPayout = item.IsPayout
                    });
                }
            }

            return retVal;
        }

        private static List<OrderRowEntityClient> GetOrderRowEntityClient(List<OrderRowEntity> list)
        {
            List<OrderRowEntityClient> retVal = null;

            if (list != null)
            {
                retVal = new List<OrderRowEntityClient>();
                foreach (var item in list)
                {
                    retVal.Add(new OrderRowEntityClient()
                    {
                        Amount = item.Amount.ToCommaString(),
                        MaxPayout = item.MaxPayout.HasValue ? item.MaxPayout.Value.ToCommaString() : "0",
                        Payout = item.Payout.HasValue ? item.Payout.Value.ToCommaString() : "0",
                        BetsCount = item.Bets.Count,
                        Id = item.Id,
                        TotalRatio = item.TotalRatio.HasValue ? item.TotalRatio.Value.ToString("F") : "0",
                        WinStatus = EnumResourceTranslator.Translate<eWinStatus>(item.WinStatus).ToString(),
                        Bets = GetOrderBetClient(item.Bets),
                        Bonus = item.BonusAmount.HasValue ? item.BonusAmount.Value.ToCommaString() : "0",
                        BonusType = item.BonusType == null ? "-" : item.BonusType.Name,
                        Commision = item.CommissionAmount.HasValue ? item.CommissionAmount.Value.ToCommaString() : "-",
                        CommissionType = item.CommissionType == null ? "-" : item.CommissionType.CommissionsType.ToString()
                    });
                }
            }
            return retVal.OrderBy(x => x.Bets.First().Id).ToList();
        }

        private static List<OrderBetClient> GetOrderBetClient(List<OrderBet> list)
        {
            var retVal = new List<OrderBetClient>();

            if (list != null)
            {
                foreach (var item in list)
                {
                    string scoreTxt = string.Empty;
                    if (item.Event.Scores.IsNotNullAndAny())
                        item.Event.Scores.ToList().ForEach(x => scoreTxt += x.Value == null ? string.Empty : string.Format("{0}: {1}-{2} ", x.Key.ToEnumString(), x.Value.HomeScore, x.Value.AwayScore));
                    retVal.Add(new OrderBetClient()
                    {
                        Id = item.Id,
                        GameNumber = item.Event.GameNumber,
                        SportType = item.Event.SportType.Name,
                        Leauge = item.Event.League.ToString(),
                        BetTypeId = item.Event.BetTypes[0].Id,
                        BetType = item.Odd.Line == null ? item.Event.BetTypes[0].ToString() : (item.Event.BetTypes[0].ToString() + " (" + item.Odd.Line + ")"),
                        GameId = item.Event.Id,
                        Game = string.Format("{0} - {1}", item.Event.HomeTeam, item.Event.AwayTeam),
                        Score = scoreTxt,
                        OddId = item.Odd.Id,
                        Odd = item.Odd.ToString(),
                        Ratio = buildBetRatio(item),
                        WinStatus = new WinStatus() { Id = (int)item.Odd.WinStatus, WinStatusName = EnumResourceTranslator.Translate<eWinStatus>(item.Odd.WinStatus).ToString() },
                        Date = item.Event.EventDate.ToString(Helper.DateHelper.MAIN_FORMAT),
                        UpdatedManuallyBy = item.UpdatedManuallyBy == null ? null : string.Format("{0} {1}", item.UpdatedManuallyBy.FirstName, item.UpdatedManuallyBy.LastName),
                        IsBanker = item.IsBanker
                    });
                }
            }
            return retVal.OrderBy(x => x.Id).ToList();
        }

        private static string buildBetRatio(OrderBet item)
        {
            string retVal = string.Empty;
            var currentPrice = item.Odd.CurrentPrice.ToString("F");
            switch (item.Odd.WinStatus)
            {
                case eWinStatus.MoneyBack:
                    retVal = "1.00 (" + currentPrice + ")";
                    break;
                case eWinStatus.HalfWin:
                    retVal = OrderCalculator.Round((decimal)0.5 * item.Odd.CurrentPrice).ToString("F") + " (" + currentPrice + ")";
                    break;
                case eWinStatus.HalfLose:
                    retVal = "0.5 (" + currentPrice + ")";
                    break;
                default:
                    retVal = item.OriginalPrice != item.Odd.CurrentPrice ? string.Format("{0} ({1})", item.OriginalPrice.ToString("F"), currentPrice) : currentPrice;
                    break;
            }
            return retVal;
        }

        public static List<ActivityClient> GetClientActivities(List<Activity> list)
        {
            var retVal = new List<ActivityClient>();

            foreach (var item in list)
            {
                retVal.Add(new ActivityClient()
                {
                    Id = item.Id,
                    Activity = item.Name,
                    ActivityType = item.ActivityType.Name,
                    CanRead = item.PermissionsLevel >= ePermissionsLevel.Read,
                    CanWrite = item.PermissionsLevel >= ePermissionsLevel.Create,
                    CanUpdate = item.PermissionsLevel >= ePermissionsLevel.Update,
                    CanDelete = item.PermissionsLevel >= ePermissionsLevel.Delete,
                    PermissionLevel = item.PermissionsLevel
                });
            }

            return retVal;
        }
        public static List<TransferClient> GetClientTransfers(List<Transfer> list)
        {
            var retVal = new List<TransferClient>();

            foreach (var item in list)
            {
                TransferClient client = new TransferClient();
                client.Id = item.Id;
                client.RequestTime = item.RequestTime;
                client.ResponseTypeName = item.ResponseType.Name;
                if (item.ResponsedBy != null)
                    client.ResponsedByName = item.ResponsedBy.FirstName + " " + item.ResponsedBy.LastName + " (" + item.ResponsedBy.Id + ")";
                else
                    client.ResponsedByName = "";
                if (item.ToAccount != null)
                    client.ToAccountName = item.ToAccount.User.FirstName + " " + item.ToAccount.User.LastName + " (" + item.ToAccount.User.Id + ")";
                else
                    client.ResponsedByName = "";
                client.RequestByName= item.RequestBy.FirstName + " " + item.RequestBy.LastName + " (" + item.RequestBy.Id + ")";

                client.RequestAmount = item.RequestAmount;
                client.Code = item.Code;
                client.CancelTime = item.CancelTime;
                client.ResponseTime = item.ResponseTime;
                retVal.Add(client);
            }

            return retVal;
        }
        public static List<UserEntityClient> GetClientUsers(List<OperatorUser> list)
        {
            var retVal = new List<UserEntityClient>();

            foreach (var item in list)
            {
                UserEntityClient client = new UserEntityClient();
                client.Id = item.Id;
                client.UserName = item.UserName;
                client.FirstName = item.FirstName;
                client.LastName = item.LastName;
                client.FullName = item.FirstName + " " + item.LastName;
                client.LastAccess = item.LastAccess;             
                client.Phone = item.Phone;
                client.SkypeName = item.SkypeName;
                client.Security = item.Security;
                client.Email = item.Email;
                client.Address = item.Address;
                client.Roles = item.Roles;
                client.Branches = item.Branches;
                client.MaxBet = item.MaxBet;
                client.MinBet = item.MinBet;
                client.MaxPayout = item.MaxPayout;
                client.CurrentShift = item.CurrentShift; // added 
                client.CreditLimit = item.CreditLimit;
                client.ClientRoles = string.Join(", ", item.Roles.ConvertAll(x => (string)x.Name));
                client.ClientBranches = string.Join(", ", item.Branches.ConvertAll(x => (string)x.Name));
                client.Enabled = item.Enabled;
                client.Currency = item.Currency;
                client.TempCreditLimit = item.TempCreditLimit;
                client.ClientCreditLimit = string.Format(CurrencyHelper.FULL_CURRENCY_FORMAT, item.CreditLimit) + (item.TempCreditLimit.HasValue ? " (" + string.Format(CurrencyHelper.FULL_CURRENCY_FORMAT, item.TempCreditLimit.Value) + ")" : "");
                client.Balance = item.ActualBalance;
                client.ClientBalance = string.Format(CurrencyHelper.FULL_CURRENCY_FORMAT, item.ActualBalance) + (item.Holding.HasValue && item.Holding.Value > 0 ? string.Format(" ({0:" + CurrencyHelper.CURRENCY_FORMAT + "})", item.Holding.Value) : "");
                                                                  
                retVal.Add(client);
            }

            return retVal;
        }
        public static List<OnlineSummaryReportClient> GetOnlineSummaryClient(List<OnlineSummaryReport> list)
        {
            var retVal = new List<OnlineSummaryReportClient>();

            foreach (var item in list)
            {
                OnlineSummaryReportClient client = new OnlineSummaryReportClient();
                client.Id = item.User.Id;
                 client.Joined = item.Joined;
                client.FirstName = item.User.FirstName;
                client.LastName = item.User.LastName;
                client.UserName=item.User.UserName; 
                client.Balance = item.Balance;
                client.Deposits = item.Deposits;
                client.DepositsCount = item.DepositsCount;
                client.TotalBonus = item.TotalBonus;
                client.Withrawls = item.Withrawls;
                client.WithdrawlsCount = item.WithdrawlsCount;
                client.CashFlow = item.CashFlow;
                client.TotalStakes = item.TotalStakes;
                client.TotalStakesCount = item.TotalStakesCount;
                client.Pending = item.Pending;
                client.PendingCount = item.PendingCount;
                client.Winnings = item.Winnings;
                client.WinningsCount = item.WinningsCount;
                client.Profit = item.Profit;
                retVal.Add(client);
            }

            return retVal;
        }
        public static List<AgentClient> GetAgentUsers(List<OperatorUser> list)
        {
            var retVal = new List<AgentClient>();

            foreach (var item in list)
            {
                AgentClient client = new AgentClient();
                client.Id = item.Id;
                if(item.LastAccess!=null)
                client.LastKeepAlive = item.LastAccess.LoginTerminal!=null ? item.LastAccess.LoginTerminal.LastKeepAlive: null;
                client.LastOrderId = item.LastOrderId != null ? item.LastOrderId:null ;
                client.LastOrderTime = item.LastOrderTime !=null ? item.LastOrderTime: null;
                client.AccountId = item.AccountId != null ? (int)item.AccountId : 0;
                client.FirstName = item.FirstName;
                client.Currency = item.Currency;
                client.Commission = item.Commission == null ? 0 : (double)item.Commission;
                if (item.Branches.Count>0)
                client.BranchId= item.Branches[0].Id;
                client.LastName = item.LastName;  
                client.UserName = item.UserName;
                if(item.CurrentShift != null)
                client.ShiftId =  (int)item.CurrentShift.ShiftId;
                client.IsAgent = item.Roles.Any(x => x.Id == 3);
                client.MoneyCollected = 0;
                client.MoneySent = 0;
                if (item.ActualCreditLimit > 0){

                    client.AmountUsedInPercent = string.Format("{0:p0}", (item.Balance) / (item.ActualCreditLimit));
                }else
                {
                    client.AmountUsedInPercent = "-1";
                }
                if (item.Transfers.Count > 0 /*&& client.IsAgent*/)
                {
                    foreach(var transfer in item.Transfers)
                    {
                        
                        if (transfer.RequestType.CodeAttribute == CodeAttribute.TransferRequestType.CollectCash)
                        {
                            client.PendingCollect++;
                            client.MoneyCollected += transfer.RequestAmount;
                        }
                        else
                        {
                            if (transfer.RequestType.CodeAttribute == CodeAttribute.TransferRequestType.CashTransfer ||
                                transfer.RequestType.CodeAttribute == CodeAttribute.TransferRequestType.Commission ||
                                transfer.RequestType.CodeAttribute == CodeAttribute.TransferRequestType.Expenses)
                            {
                                client.PendingSend++;
                                client.MoneySent+= transfer.RequestAmount;
                            }
                            
                        }
                    }
                }
                client.ShiftOpen = item.CurrentShift != null ? item.CurrentShift.IsOpen : false ;
               
           
                if (item.LastAccess != null && item.LastAccess.LoginTime!=null && item.LastAccess.LogoutTime == null)
                    client.connect = true;
                else
                client.connect = false;
                client.LastAccess = (item.LastAccess != null) ? item.LastAccess.LoginTime: (DateTime?)null;
               
                client.CreditLimit = item.ActualCreditLimit;
                client.Balance = item.Balance!=null ? (double)item.Balance : 0;

        retVal.Add(client);
            }

            return retVal;
        }
        public static List<UserEntityOnlineClient> GetOnlineClientUsers(List<ClientUser> list)
        {
            var retVal = new List<UserEntityOnlineClient>();

            foreach (var item in list)
            {
                UserEntityOnlineClient client = new UserEntityOnlineClient();
                client.Id = item.Id;
                client.UserName = item.UserName;
                client.Currency = item.Currency;
                client.FirstName = item.FirstName;
                client.LastName = item.LastName;
                client.FullName = item.FirstName + " " + item.LastName;
                client.LastAccess = item.LastAccess;                             
                client.AcceptNewsletter = item.AcceptNewsletter;
                client.ConfirmationEmailTime = item.ConfirmationEmailTime;
                client.ClientRoles = string.Join(", ", item.Roles.ConvertAll(x => (string)x.Name));
                client.ClientBranches = string.Join(", ", item.Branches.ConvertAll(x => (string)x.Name));
                if (item.ConfirmationEmailTime != null)
                    client.isApproved = true;
                else
                    client.isApproved = false;
                    client.Enabled = item.Enabled;
                client.Phone = item.Phone;
                client.SkypeName = item.SkypeName;
                client.Security = item.Security;
                client.Email = item.Email;
                client.Address = item.Address;
                client.Roles = item.Roles;
                client.Branches = item.Branches;
                client.MaxBet = item.MaxBet;
                client.MinBet = item.MinBet;
                client.MaxPayout = item.MaxPayout;
                //client.CreditLimit = onlineUser.CreditLimit;                
                client.Enabled = item.Enabled;
                //client.TempCreditLimit = onlineUser.TempCreditLimit;
                //client.ClientCreditLimit = string.Format(CurrencyHelper.FULL_CURRENCY_FORMAT, onlineUser.CreditLimit) + (onlineUser.TempCreditLimit.HasValue ? " (" + string.Format(CurrencyHelper.FULL_CURRENCY_FORMAT, onlineUser.TempCreditLimit.Value) + ")" : "");
                client.Balance = item.ActualBalance;
                client.ClientBalance = string.Format(CurrencyHelper.FULL_CURRENCY_FORMAT, item.ActualBalance) + (item.Holding.HasValue && item.Holding.Value > 0 ? string.Format(" ({0:" + CurrencyHelper.CURRENCY_FORMAT + "})", item.Holding.Value) : "");                                   
                retVal.Add(client);
            }

            return retVal;
        }

        public static List<AccessClient> GetClientsAccess(List<Access> list)
        {
            List<AccessClient> retVal = null;
            if (list != null)
            {
                retVal = new List<AccessClient>();

                foreach (var i in list)
                {

                    retVal.Add(new AccessClient()
                    {
                        LoginBranch = i.LoginBranch,
                        LoginFrom = i.LoginFrom,
                        LoginIp = i.LoginIp,
                        LoginTerminal = i.LoginTerminal,
                        LoginTime = i.LoginTime,
                        LogoutTime = i.LogoutTime,
                        LogoutType = i.LogoutType,
                        Token = i.Token,
                        UserID = i.UserID,
                    });
                    if (i.LogoutTime.HasValue)
                    {
                        var span = i.LogoutTime.Value.Subtract(i.LoginTime);
                        if (Convert.ToInt16(span.ToString("%d")) > 0)
                            retVal.Last().TotalTime = span.ToString(@"d\.hh\:mm\:ss");
                        else
                            retVal.Last().TotalTime = span.ToString(@"hh\:mm\:ss");
                    }
                }
            }
            return retVal;
        }

        public static List<NotificationClient> GetClientNotifications(List<Notification> list)
        {
            if (list == null || !list.Any())
                return null;

            var retVal = new List<NotificationClient>();
            foreach (var item in list)
            {
                retVal.Add(new NotificationClient()
                {
                    Id = item.Id,
                    From = item.SendFrom,
                    Attempts = item.AttemptsCount,
                    CreateTime = item.CreateTime,
                    LastUpdate = item.LastUpdate,
                    DeliveredTime = item.DeliveredTime,
                    ExecuteAt = item.ExecuteAt,
                    Message = item.Message,
                    Recipients = item.Recipients,
                    Title = item.Title,
                    Status = EnumResourceTranslator.Translate<eMessageStatus>(item.Status),
                    Type = EnumResourceTranslator.Translate<eNotificationAlertType>(item.NotificationType)
                });
            }


            return retVal;
        }

        public static List<BannerClient> GetClientBanners(List<Banner> list)
        {
            if (!list.IsNotNullAndAny())
                return null;

            var retVal = new List<BannerClient>();

            foreach (var item in list)
            {
                retVal.Add(new BannerClient()
                {
                    Id = item.Id,
                    LineOne = item.Body.IsNotNullOrEmpty() ? (item.Body.Contains(Environment.NewLine) ? item.Body.Substring(0, item.Body.IndexOf(Environment.NewLine)) : item.Body) : "",
                    LineTwo = item.Body.IsNotNullOrEmpty() && item.Body.Contains(Environment.NewLine) ? item.Body.Substring(item.Body.IndexOf(Environment.NewLine), item.Body.Length - item.Body.IndexOf(Environment.NewLine)) : "",
                    FlashFile = item.FlashFile,
                    Headline = item.Headline,
                    IsActive = item.IsActive
                });
            }

            return retVal;
        }

        public static List<OddEntityClient> GetClientOdds(List<OddEntity> list)
        {
            List<OddEntityClient> retVal = new List<OddEntityClient>();

            foreach (var item in list)
            {
                retVal.Add(new OddEntityClient()
                {
                    Id = Convert.ToInt32(item.Id),
                    Name = item.Name,
                    ShortName = item.ShortName,
                    Shortcut = item.Shortcut,
                    OrderCol = item.OrderCol,
                    OrderRow = item.OrderRow
                });
            }

            return retVal;
        }

        public static List<OddEntity> GetServerOdds(List<OddEntityClient> list)
        {
            List<OddEntity> retVal = new List<OddEntity>();

            foreach (var item in list)
            {
                var odd = new OddEntity()
                {
                    Id = item.Id,
                    Name = item.Name,
                    ShortName = item.ShortName,
                    Shortcut = item.Shortcut,
                };
                odd.SetOrder(item.OrderRow, item.OrderCol);
                retVal.Add(odd);
            }

            return retVal;
        }

        #region PrivateFuncs

        private static string buildStatusString(OrderEntity order)
        {
            var list = order.OrderRows;
            string retVal = string.Empty;
            retVal += (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Winner) > 0 ? (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Winner) == 1 ? Winner : Winner + "(" + list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Winner) + ")") + (order.CheckoutTime.HasValue ? " - Paid" : "") + ", " : string.Empty);
            retVal += (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Loser) > 0 ? (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Loser) == 1 ? Loser : Loser + "(" + list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Loser) + ")") + ", " : string.Empty);
            retVal += (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Pending) > 0 ? (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Pending) == 1 ? Pending : Pending + "(" + list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Pending) + ")") + ", " : string.Empty);
            retVal += (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.MoneyBack) > 0 ? (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.MoneyBack) == 1 ? MoneyBack : MoneyBack + "(" + list.Count(x => x.WinStatus == Model.Consts.eWinStatus.MoneyBack) + ")") + (order.CheckoutTime.HasValue ? " - Paid" : "") + ", " : string.Empty);
            retVal += (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Unknown) > 0 ? (list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Unknown) == 1 ? Unknown : Unknown + "(" + list.Count(x => x.WinStatus == Model.Consts.eWinStatus.Unknown) + ")") + ", " : string.Empty);

            retVal = retVal.TrimEnd(',', ' ');
            return retVal;
        }

        //private static string calcAmountToWin(OrderEntity item)
        //{
        //    string retVal = string.Empty;

        //    if (item.OrderRows.Count() == 1)
        //    {
        //        if(item.OrderRows.FirstOrDefault().WinStatus == eWinStatus.Winner || item.OrderRows.FirstOrDefault().WinStatus == eWinStatus.MoneyBack  )
        //            retVal = item.OrderRows.Sum(x => x.AmountToWin).Value.ToCommaString();
        //        else if (item.OrderRows.FirstOrDefault().WinStatus == eWinStatus.Pending)
        //            retVal = OrderCalculator.Calculate(new OrderCalculationRow() { Amount = (decimal)item.OrderRows.FirstOrDefault().Amount, Odds = item.OrderRows.FirstOrDefault().Bets.Where(x => x.Odd.WinStatus != eWinStatus.MoneyBack).Select(x => x.Odd.CurrentPrice).ToList() }).Winnings.ToCommaString();
        //    }

        //    return retVal;
        //}

        #endregion

    }
}