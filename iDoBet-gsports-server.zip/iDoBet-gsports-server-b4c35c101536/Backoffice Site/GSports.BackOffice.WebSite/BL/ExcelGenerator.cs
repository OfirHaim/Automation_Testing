﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web;
//using System.IO;
//using SpreadsheetLight;
//using System.Web.Mvc;
//using GSports.Model.Entities;
//using GSports.Model.Entities.Event;
//using GSports.Model.Entities.Excel;
//using GSports.Channel;
//using GSports.Model.Requests.Metadata;
//using GSports.Model.Filter;
//using GSports.BackOffice.WebSite.Models;
//using System.Drawing;

//namespace GSports.BackOffice.WebSite.BL
//{
//    public class ExcelGenerator
//    {
//        const string AUTO_LINE = "auto", LINE_CONST = "Line";

//        public static MemoryStream ExportCouponToExcel(List<ExcelSheetData> dataSheets)
//        {
//            try
//            {
//                const string MAIN_DATE_CELL = "A1", DATE_FORMAT = "dddd, dd MMMM, yyyy", STYLE_CELL_REF = "A5";
//                const int STARTING_ROW = 5;
//                string[] SportTypes = { "Soccer", "Basketball", "Tennis" };

//                using (FileStream fs = new FileStream(Path.Combine(HttpRuntime.AppDomainAppPath, "Content/CouponTemplate.xlsx"), FileMode.Open, FileAccess.Read))
//                {
//                    MemoryStream ms = new MemoryStream();
//                    using (SLDocument sl = new SLDocument(fs))
//                    {
//                        foreach (var dataSheet in dataSheets)
//                        {
//                            sl.SelectWorksheet(dataSheet.Events.First().SportType.Name);

//                            int betTypeNameCounter = 7;
//                            int eventRowCounter = STARTING_ROW;
//                            int columnsCount = dataSheet.Events.First().BetTypes.Sum(s => s.Odds.Count) + 6;

//                            dataSheet.Events = dataSheet.Events.OrderBy(x => x.GameNumber).ToList();
//                            DateTime currentDay = dataSheet.Events.First().EventDate;

//                            var changedDateCells = new List<int>();
//                            var lineCells = new Dictionary<int, int>();
//                            var refStyle = sl.GetCellStyle(STYLE_CELL_REF);
//                            var leftBorders = new List<int>();

//                            sl.SetCellValue(MAIN_DATE_CELL, currentDay.ToString(DATE_FORMAT));
//                            sl.MergeWorksheetCells(1, 1, 1, columnsCount);

//                            #region Setting BetType Data

//                            foreach (var bt in dataSheet.BetTypes)
//                            {
//                                sl.SetCellValue(2, betTypeNameCounter, bt.ToString().Trim());
//                                sl.MergeWorksheetCells(2, betTypeNameCounter, 2, betTypeNameCounter + bt.Odds.Count - 1);

//                                int shortCutCounter = betTypeNameCounter;
//                                foreach (var odd in bt.Odds)
//                                {
//                                    sl.SetCellValue(3, shortCutCounter++, (odd.Shortcut ?? "").Trim());
//                                }

//                                int shortNameCouter = betTypeNameCounter;
//                                foreach (var odd in bt.Odds)
//                                {
//                                    sl.SetCellValue(4, shortNameCouter++, odd.ToString().Trim());
//                                }
//                                leftBorders.Add(betTypeNameCounter);
//                                betTypeNameCounter += bt.Odds.Count;

//                            }

//                            #endregion

//                            #region Filling Events Data

//                            foreach (var eve in dataSheet.Events)
//                            {
//                                if (eve.EventDate.Date > currentDay.Date)
//                                {
//                                    currentDay = eve.EventDate;
//                                    sl.SetCellValue(eventRowCounter, 1, eve.EventDate.ToString(DATE_FORMAT));
//                                    changedDateCells.Add(eventRowCounter);
//                                    sl.MergeWorksheetCells(eventRowCounter, 1, eventRowCounter, columnsCount);
//                                    eventRowCounter++;
//                                }
//                                int columsCounter = 1;

//                                sl.SetCellValue(eventRowCounter, columsCounter++, eve.GameNumber);
//                                sl.SetCellValue(eventRowCounter, columsCounter++, eve.IsBooked ? "Live" : "");
//                                sl.SetCellValue(eventRowCounter, columsCounter++, eve.EventDate.ToString("HH:mm"));
//                                sl.SetCellValue(eventRowCounter, columsCounter++, eve.League.ToString());
//                                sl.SetCellValue(eventRowCounter, columsCounter++, eve.HomeTeam.ToString());
//                                sl.SetCellValue(eventRowCounter, columsCounter++, eve.AwayTeam.ToString());
//                                foreach (var bt in eve.BetTypes)
//                                {
//                                    foreach (var odd in bt.Odds)
//                                    {
//                                        var text = string.Empty;
//                                        if (odd.Name == LINE_CONST)
//                                        {
//                                            text = odd.Line;
//                                            lineCells.Add(eventRowCounter, columsCounter);
//                                        }
//                                        else
//                                            text = odd.CurrentPrice == 0 ? "~" : odd.CurrentPrice.ToString("F");
//                                        sl.SetCellValue(eventRowCounter, columsCounter++, text);
//                                    }
//                                }
//                                eventRowCounter++;
//                            }

//                            #endregion

//                            #region Style

//                            var lineCellStyleStyle = sl.GetCellStyle(STYLE_CELL_REF);
//                            lineCellStyleStyle.Font.Bold = true;
//                            lineCellStyleStyle.Font.Italic = true;

//                            var changeDataStyle = sl.GetCellStyle(STYLE_CELL_REF);
//                            changeDataStyle.Font.Bold = true;
//                            changeDataStyle.Font.FontSize += 15;

//                            var leftBorderStyle = sl.GetCellStyle(STYLE_CELL_REF);
//                            leftBorderStyle.Border.LeftBorder.BorderStyle = DocumentFormat.OpenXml.Spreadsheet.BorderStyleValues.Thick;
//                            leftBorderStyle.Border.LeftBorder.Color = System.Drawing.Color.Black;

//                            var leftText = sl.GetCellStyle(STYLE_CELL_REF);
//                            leftText.SetHorizontalAlignment(DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Left);

//                            sl.SetCellStyle(STARTING_ROW, 1, eventRowCounter - 1, columnsCount, refStyle);
//                            changedDateCells.ForEach(x => sl.SetCellStyle(x, 1, changeDataStyle));
//                            lineCells.ToList().ForEach(x => sl.SetCellStyle(x.Key, x.Value, lineCellStyleStyle));
//                            leftBorders.ForEach(x => sl.SetCellStyle(STARTING_ROW - 3, x, eventRowCounter - 1, x, leftBorderStyle));
//                            for (int i = 1; i <= 6; i++)
//                                sl.SetCellStyle(STARTING_ROW - 3, i, eventRowCounter - 1, i, leftBorderStyle);

//                            sl.SetColumnStyle(4, leftText);
//                            sl.SetColumnStyle(5, leftText);
//                            sl.SetColumnStyle(6, leftText);

//                            sl.SetRowHeight(2, eventRowCounter - 1, 40);

//                            #endregion
//                        }

//                        foreach (var st in SportTypes)
//                        {
//                            if (!dataSheets.Any(x => x.SportTypeName == st))
//                                sl.DeleteWorksheet(st);
//                        }

//                        sl.SaveAs(ms);
//                    }
//                    ms.Position = 0;
//                    return ms;
//                }
//            }
//            catch (Exception ex)
//            {
//                GLogger.Logger.WriteLog(ex);
//                return null;
//            }
//        }

//        public static ExcelSheetData PrepareDataForExcel(ExcelSettings excelSetting, List<SportGame> events, TimeZoneInfo tzi)
//        {
//            ExcelSheetData retVal = new ExcelSheetData();
//            retVal.BetTypes = new List<BetType>();
//            retVal.Events = events;
//            retVal.SportTypeName = string.Format("{0}", excelSetting.SportType.Name);

//            //try
//            //{
//            var orderedExcelBetTypes = excelSetting.ExcelBetTypes.OrderBy(x => x.Order).ToList();
//            var dbBetTypes = BetMetadataChannel.GetItems(MetadataType.BetType, null, new BetTypeFilter() { Ids = excelSetting.ExcelBetTypes.Select(x => x.BetType.Id).ToList() }).ConvertAll(x => (BetType)x);

//            //sort odds in betTypes by order from excel setting
//            foreach (var item in orderedExcelBetTypes)
//            {
//                var btOdds = new List<OddEntity>();
//                var bt = dbBetTypes.First(x => x.Id == item.BetType.Id);
//                var sOdds = item.OddsOrder.Split(',').ToList();
//                bt.Odds.ForEach(x => btOdds.Add(
//                    new OddEntity()
//                    {
//                        Name = x.Name,
//                        ShortName = x.ShortName,
//                        Shortcut = string.Format(x.Shortcut ?? "", item.Line),
//                        Order = sOdds.IndexOf(x.Name) + 1,
//                        Line = item.Line
//                    }));
//                if ((item.Line ?? "").Trim().ToLower() == AUTO_LINE)
//                    btOdds.Add(new OddEntity() { Name = LINE_CONST, Order = 0 });
//                retVal.BetTypes.Add(new BetType() { Id = bt.Id, ShortName = bt.ToString() + (string.IsNullOrEmpty(item.Line) || item.Line.Trim().ToLower() == AUTO_LINE ? "" : " (" + item.Line + ")"), Order = item.Order, Line = item.Line, Odds = btOdds.OrderBy(x => x.Order).ToList() });
//            }

//            //sort bet types and odds in all events according to retval
//            foreach (var eve in events)
//            {
//                var orderedEveBetTypes = new List<BetType>();

//                foreach (var bt in retVal.BetTypes.OrderBy(x => x.Order))
//                {
//                    var exsistBt = eve.BetTypes.FirstOrDefault(x => x.Id == bt.Id);
//                    if (exsistBt != null)
//                    {
//                        if ((bt.Line ?? "").Trim().ToLower() == AUTO_LINE)
//                        {
//                            var sortedOdd = Model.Helper.SortOddsByClosestPrice(exsistBt).FirstOrDefault();
//                            if (sortedOdd != null)
//                            {
//                                var perfectLine = string.Empty;
//                                perfectLine = sortedOdd.Odds.First().Line;
//                                bt.Odds.ForEach(x => x.Line = perfectLine);
//                            }
//                        }

//                        var newOdds = new List<OddEntity>();

//                        foreach (var odd in bt.Odds)
//                        {
//                            var fitOdd = exsistBt.Odds.FirstOrDefault(x => x.Name == odd.Name && x.Line == odd.Line);
//                            if (fitOdd != null)
//                            {
//                                fitOdd.Order = odd.Order;
//                                newOdds.Add(fitOdd);
//                            }
//                            else if (odd.Name == LINE_CONST)
//                                newOdds.Insert(0, new OddEntity() { Name = LINE_CONST, Line = odd.Line });
//                            else
//                                newOdds.Add(new OddEntity());
//                        }

//                        orderedEveBetTypes.Add(
//                            new BetType()
//                            {
//                                Id = exsistBt.Id,
//                                Name = exsistBt.Name,
//                                ShortName = exsistBt.ShortName,
//                                Order = bt.Order,
//                                Line = exsistBt.Line,
//                                Odds = newOdds
//                            });
//                    }
//                    else
//                    {
//                        var sortedBt = new BetType();
//                        var sortedBtOdds = new List<OddEntity>();

//                        bt.Odds.ForEach(x => sortedBtOdds.Add(new OddEntity()));
//                        sortedBt.Odds = sortedBtOdds;
//                        sortedBt.Order = bt.Order;

//                        orderedEveBetTypes.Add(sortedBt);
//                    }
//                }

//                eve.BetTypes = orderedEveBetTypes;
//                TimeZoneInfo.ConvertTimeFromUtc(eve.EventDate, tzi);
//            }
//            //}
//            //catch { }

//            return retVal;

//        }

//    }
//}

