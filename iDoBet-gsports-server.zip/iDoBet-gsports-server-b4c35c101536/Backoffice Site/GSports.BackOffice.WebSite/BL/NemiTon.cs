﻿using System;
using System.Collections.Generic;

namespace GSports.BackOffice.WebSite.BL
{
    public sealed class NemiTon
    {
        private NemiTon()
        {
            Users = new Dictionary<int, UserNotification>();        
        }
        private static readonly Lazy<NemiTon> lazy = new Lazy<NemiTon>(() => new NemiTon());
        public static NemiTon Instance { get { return lazy.Value; } }

        public Dictionary<int, UserNotification> Users { get; set; }
    }

    public class UserNotification
    {
        public UserNotification()
        {
            Notifications = new HashSet<eUserNotiType>();
        }

        public HashSet<eUserNotiType> Notifications { get; set; }
    }

    public enum eUserNotiType
    {
        UserChange,
        BalanceChange
    }
}