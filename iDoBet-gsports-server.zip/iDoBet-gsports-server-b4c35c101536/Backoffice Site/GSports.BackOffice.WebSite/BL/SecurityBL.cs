﻿using GSports.Channel;
using GSports.Common;
using GSports.Model.Consts.BackOffice;
using GSports.Model.Consts.Security;
using GSports.Model.Entities.User;
using GSports.Model.Requests.Metadata;
using GSports.Model.Security;
using System.Collections.Generic;
using System.Linq;

namespace GSports.BackOffice.WebSite.BL
{
    public class SecurityBL
    {
        public static bool IsAllowedInBackOffice(UserEntity user)
        {
            //retVal = (from s in new List<int>() { (int)eRole.SuperAdmin, (int)eRole.Operator, (int)eRole.Agent }
            //         join d in user.Roles.Select(x => x.Id) on s equals d
            //         select s).Any();
            //if (user.Roles.Any(x => x.Level < 10)) //under level 10 eg superAdmin Operator Agent
            //var activities = new List<Activity>();

            // activities = UserServiceChannel.GetActivities(null, 10);
           
            var activityType = new List<string>() { CodeAttribute.ActivityType.BACKOFFICE_SETTINGS,CodeAttribute.ActivityType.BACKOFFICE_COUPONS, CodeAttribute.ActivityType.BACKOFFICE_REPORTS, CodeAttribute.ActivityType.BACKOFFICE_ADMINISTRATION, CodeAttribute.ActivityType.BACKOFFICE_MATCHES, CodeAttribute.ActivityType.BACKOFFICE_NOTIFICATION, CodeAttribute.ActivityType.BACKOFFICE_FINANCE, CodeAttribute.ActivityType.BACKOFFICE_ONLINE, CodeAttribute.ActivityType.BACKOFFICE_AGENTS };
            var activities = new List<Activity>();
            activities = UserServiceChannel.GetActivities(null, null);
            var intersectActivityType = activities.Where(p2 => activityType.Any(p1 => p1 == p2.ActivityType.CodeAttribute)).ToList();
                 var userActivityInterSect = user.PermissionMatrix.Where(p2 => intersectActivityType.Any(p1 => p1.CodeAttribute == p2.Key && p2.Value >= ePermissionsLevel.Read)).ToList();
            if (userActivityInterSect.Count>0)
                return true;
            else
                return false;
        }
    }
}