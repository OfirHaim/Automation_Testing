﻿using GSports.Common;
using GSports.Model.Consts;
using GSports.Model.Entities;
using System.Collections.Generic;
using System.Linq;

namespace GSports.BackOffice.WebSite.BL
{
    public class OddValidator
    {
        public static bool ValidateOdds(List<OddEntity> oddList, out string errorStatus)
        {
            var isValid = true;

            errorStatus = string.Empty;
            foreach (var odds in oddList.GroupBy(x => x.Line))
            {
                if (odds.All(x => x.WinStatus == eWinStatus.HalfLose) || odds.All(x => x.WinStatus == eWinStatus.HalfWin) || odds.All(x => x.WinStatus == eWinStatus.Loser) || odds.All(x => x.WinStatus == eWinStatus.Winner))
                {
                    isValid = false;
                    errorStatus = "Cannot set " + Resources.EnumResourceTranslator.Translate<eWinStatus>(odds.First().WinStatus).ToString() + " for all odds";
                    break;
                }

                var newMargin = new BetType() { Odds = odds.ToList() }.CalculatedMargin;
                if (newMargin < 1)
                {
                    isValid = false;
                    var oddsLine = odds.First().Line;
                    errorStatus = string.Format("The new margin" + (oddsLine.IsNotNullOrEmpty() ? " for line {0}" : "") + " is {1} and it cannot be less than 1!</br> Please re-enter correct odds", oddsLine, newMargin);
                    break;
                }
            }
            return isValid;
        }

    }
}