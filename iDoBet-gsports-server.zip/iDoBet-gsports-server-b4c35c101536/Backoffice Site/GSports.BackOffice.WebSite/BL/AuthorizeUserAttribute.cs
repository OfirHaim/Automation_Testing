﻿using GSports.GLogger;
using GSports.Common;
using GSports.Model.Consts.Security;
using System.Web;
using System.Web.Mvc;

namespace GSports.BackOffice.WebSite.BL
{
    public class AuthorizeUserAttribute : AuthorizeAttribute
    {
        public string Activity { get; set; }
        public ePermissionsLevel permissionsLevel { get; set; }
        public eRole Role { get; set; }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            var isAuthorized = base.AuthorizeCore(httpContext);
            var user = SessionManager.CurrentUser.User;

            if (isAuthorized)
            {
                if (Role != eRole.Unknown)
                {
                    if(user != null)
                        isAuthorized = user.IsInRole(Role);
                }
                else if (Activity.IsNotNullOrEmpty())
                {
                    isAuthorized = false;
                    if (user != null)
                    {
                        var matrix = user.PermissionMatrix;
                        if (matrix != null)
                        {
                            if (matrix.ContainsKey(Activity))
                                isAuthorized = matrix[Activity] >= permissionsLevel;
                            else
                                Logger.WriteLog(eLogLevel.Info, string.Format("User Id: {0} tried to enter activity {1} that requires permission level {2} with insufficent permission", user.Id, Activity, permissionsLevel));
                        }
                        else
                            Logger.WriteLog(eLogLevel.Info, string.Format("User Id: {0} failed authentication because matrix could not be found", user.Id));
                    }
                }
            }
            else
                Logger.WriteLog(eLogLevel.Info, "User access denied");

            return isAuthorized;
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.Request.IsAjaxRequest())
                filterContext.HttpContext.Items["AjaxPermissionDenied"] = true;
            else
                base.HandleUnauthorizedRequest(filterContext);
        }
    }
}