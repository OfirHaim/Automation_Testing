﻿using GSports.Online.Model.Request;
using GSports.Online.Model.Request.MetadataService;
using GSports.Online.Model.Response;
using GSports.Online.Model.Response.MetadataService;
using System.Collections.Generic;

namespace GSports.Online.Contracts
{
    public interface IMetadataContext
    {
        GetCountriesResponse GetCountries(GetCountriesRequest request);

        GetBetTypesTemplateResponse GetBetTypeTemplate(GetBetTypesTemplateRequest request);

        GetUserCountriesResponse GetUserCountries(GetUserCountriesRequest request);
        GetUserCurrenciesResponse GetUserCurrencies(GetUserCurrenciesRequest request);
        GetSecurityQuestionsResponse GetSecurityQuestions(GetSecurityQuestionsRequest request);
    }
}
