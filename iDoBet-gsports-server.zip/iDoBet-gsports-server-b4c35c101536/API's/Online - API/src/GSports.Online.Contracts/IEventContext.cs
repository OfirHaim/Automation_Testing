﻿using GSports.Online.Model.Request.EventService;
using GSports.Online.Model.Response.EventService;

namespace GSports.Online.Contracts
{
    public interface IEventContext
    {
        GetEventsResponse GetEvents(GetEventsRequest request);
    }
}
