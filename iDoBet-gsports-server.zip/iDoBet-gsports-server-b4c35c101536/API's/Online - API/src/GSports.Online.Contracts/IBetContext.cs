﻿using GSports.Online.Model.Request.BetService;
using GSports.Online.Model.Response.BetService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Contracts
{
    public interface IBetContext
    {
        PlaceBetsResponse PlaceBets(PlaceBetsRequest request);

        ExecuteOnlineOrderResponse ExecuteOrder(ExecuteOnlineOrderRequest request);

        GetBetHistoryResponse GetBetHistory(GetBetHistoryRequest request);

        GetBetHistoryResponse GetBetOrderData(GetBetHistoryOrderDataRequest request);

    }


}
