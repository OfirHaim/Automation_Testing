﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Online.Model.Request.FinanceService;
using GSports.Online.Model.Response.FinanceService;

namespace GSports.Online.Contracts
{
   public interface IFinanceContext
    {
        GetTransactionResponse GetTransactions(GetTransactionRequest request);

        DepositResponse Deposit(DepositRequest request);

        WithdrawResponse Withdraw(WithdrawRequest request);

        CancelWithdrawResponse CancelWithdraw(CancelWithdrawRequest request);

        GetTransferHistoryResponse GetTransferHistory(GetTransferHistoryRequest request);

        SendWithdrawCodeResponse SendWithdrawCode(SendWithdrawCodeRequest request);
    }
}
