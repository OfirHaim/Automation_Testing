﻿using GSports.Online.Model.Request.UserService;
using GSports.Online.Model.Response.UserService;

namespace GSports.Online.Contracts
{
    public interface IUserContext
    {
        LoginResponse LoginUser(LoginRequest request);

        RegisterUserResponse RegisterUser(RegisterUserRequest request);

        //ForgotLoginDetailsResponse ForgotLoginDetails(ForgotLoginDetailsRequest request,string _apiToken);

        ActivateAccountResponse ActivateAccount(ActivateAccountRequest request);

        UpdateUserResponse UpdateUserProfile(UpdateUserRequest request);

        LogoutUserResponse LogoutUser(LogoutUserRequest request);

        ResendActivationLinkResponse ResendActivationLink(ResendActivationLinkRequest request);

        ChangePasswordResponse ChangePassword(ChangePasswordRequest request,bool isReset = false);

        GetUserInfoResponse GetUserInfo(GetUserInfoRequest request);

        GetUserByTokenResponse GetUserByToken(GetUserByTokenRequest request);

        KeepAliveResponse KeepAlive(KeepAliveRequest request);
        GetUserSecurityQuestionResponse GetUserSecurityQuestion(GetUserSecurityQuestionRequest request,string apiToken);
        ForgotLoginDetailsResponse ForgotUserLoginDetails(ForgotLoginDetailsRequest request,string _apiToken);
        ResetPasswordResponse ResetPassword(ResetPasswordRequest request);
    }
}
