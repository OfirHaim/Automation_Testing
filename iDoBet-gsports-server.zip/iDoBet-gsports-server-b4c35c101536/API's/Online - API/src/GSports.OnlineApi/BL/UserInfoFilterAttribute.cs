﻿using GSports.Online.Context.Channel;
using GSports.Online.Model.Request;
using GSports.Online.Model.Response;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.OnlineApi.BL
{
    public class UserInfoFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            var token = context.HttpContext.Items["userToken"] as string;

            if (!string.IsNullOrEmpty(token))
            {
                var userInfo = UserChannel.GetUserInfo(token);
                if (!string.IsNullOrEmpty(userInfo))
                {
                    var result = context.Result as ObjectResult;
                    var response = result.Value as BaseResponse;
                    if (response != null)
                        response.UserInfo = Newtonsoft.Json.JsonConvert.DeserializeObject(userInfo); 
                }
            }
            base.OnActionExecuted(context);
        }

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            var req = context.ActionArguments.FirstOrDefault(x => x.Value is BaseRequest).Value;
            if(req != null)
                context.HttpContext.Items["userToken"] = (req as BaseRequest).UserToken;
            base.OnActionExecuting(context);
        }
    }
}
