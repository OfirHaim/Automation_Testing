﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.OnlineApi.BL
{
    public class GsAuthorizationHelper
    {
        public const string TokenAudience = "OnlineClients";
        public const string TokenIssuer = "GSportsOnlineWebApi";
        public static Microsoft.IdentityModel.Tokens.SymmetricSecurityKey key;
        public static TokenAuthOptions tokenOptions;
    }

    public class TokenAuthOptions
    {
        public string Audience { get; set; }
        public string Issuer { get; set; }
        public Microsoft.IdentityModel.Tokens.SigningCredentials SigningCredentials { get; set; }
    }
}
