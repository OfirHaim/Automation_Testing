﻿using FakeContext;
using GSports.Online.Context.Implementations;
using GSports.Online.Contracts;
using Microsoft.Extensions.DependencyInjection;

namespace GSports.OnlineApi.BL
{
    public class DiFakeRegistration
    {
        public static void RegisterServices(IServiceCollection services)
        {
            services.AddTransient<IEventContext, FakeEventContext>();
            services.AddTransient<IUserContext, UserContext>();
            //services.AddTransient<IMetadataContext, FakeMetadataContext>();
            services.AddTransient<IMetadataContext, MetadataContext>();
            services.AddTransient<IBetContext, BetContext>();
            services.AddTransient<IFinanceContext, FinanceContext>();
        }
    }
}
