﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.OnlineApi.BL
{
    public static class ServicesExtensions
    {
        //public static void AddGsAuthorization(this IServiceCollection services)
        //{
        //    // *** CHANGE THIS FOR PRODUCTION USE ***
        //    // Here, we're generating a random key to sign tokens - obviously this means
        //    // that each time the app is started the key will change, and multiple servers 
        //    // all have different keys. This should be changed to load a key from a file 
        //    // securely delivered to your application, controlled by configuration.
        //    //
        //    // See the RSAKeyUtils.GetKeyParameters method for an examle of loading from
        //    // a JSON file.
        //    var keyForHmacSha256 = Encoding.ASCII.GetBytes(Guid.NewGuid().ToString());

        //    // Create the key, and a set of token options to record signing credentials 
        //    // using that key, along with the other parameters we will need in the 
        //    // token controlller.
        //    GsAuthorizationHelper.key = new SymmetricSecurityKey(keyForHmacSha256);
        //    GsAuthorizationHelper.tokenOptions = new TokenAuthOptions()
        //    {
        //        Audience = GsAuthorizationHelper.TokenAudience,
        //        Issuer = GsAuthorizationHelper.TokenIssuer,
        //        SigningCredentials = new SigningCredentials(GsAuthorizationHelper.key, SecurityAlgorithms.HMAC_SHA256)
        //    };

        //    // Save the token options into an instance so they're accessible to the 
        //    // controller.
        //    services.AddInstance(GsAuthorizationHelper.tokenOptions);

        //    // Enable the use of an [Authorize("Bearer")] attribute on methods and
        //    // classes to protect.
        //    services.AddAuthorization(auth =>
        //    {
        //        auth.AddPolicy("Bearer", new AuthorizationPolicyBuilder()
        //            .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme‌​)
        //            .RequireAuthenticatedUser().Build());
        //    });
        //}
    }
}
