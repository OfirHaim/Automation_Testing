﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Server.Kestrel.Internal.Http;
using System;
using System.IO;
using System.IO.Compression;
using System.Linq;

namespace GSports.OnlineApi.BL
{
    public static class MiddlewareExtensions
    {
        public static void UseGsGzipCompression(this IApplicationBuilder app)
        {
            app.Use(async (context, next) =>
            {
                try
                {
                    var headers = context.Request.Headers;
                    if (/*context.Items["costumGzip"] is bool && */headers is FrameRequestHeaders && ((FrameRequestHeaders)headers).HeaderAcceptEncoding.FirstOrDefault() != null
                        && ((FrameRequestHeaders)context.Request.Headers).HeaderAcceptEncoding.First().Contains("gzip"))
                    {
                        using (var memoryStream = new MemoryStream())
                        {
                            var stream = context.Response.Body;
                            context.Response.Body = memoryStream;
                            await next();
                            using (var compressedStream = new GZipStream(stream, CompressionLevel.Optimal))
                            {
                                context.Response.Headers.Remove("Content-Length");
                                context.Response.Headers.Add("Content-Encoding", new string[] { "gzip" });
                                memoryStream.Seek(0, SeekOrigin.Begin);
                                await memoryStream.CopyToAsync(compressedStream);
                                context.Response.Body = stream;
                            }
                        }
                    }
                    else
                        await next();
                }
                catch (Exception ex)
                {
                }
            });
        }
    }
}