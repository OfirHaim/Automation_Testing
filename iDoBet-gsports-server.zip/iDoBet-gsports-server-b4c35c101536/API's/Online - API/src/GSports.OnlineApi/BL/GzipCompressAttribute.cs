﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNet.Mvc.Filters;

//namespace GSports.OnlineApi.BL
//{
//    public class GzipCompressAttribute : ActionFilterAttribute
//    {
//        public override void OnActionExecuted(ActionExecutedContext context)
//        {
//            base.OnActionExecuted(context);
//            var headers = context.HttpContext.Request.Headers;
//            if (headers is Microsoft.AspNet.Server.Kestrel.Http.FrameRequestHeaders && ((Microsoft.AspNet.Server.Kestrel.Http.FrameRequestHeaders)headers).HeaderAcceptEncoding.FirstOrDefault() != null
//                && ((Microsoft.AspNet.Server.Kestrel.Http.FrameRequestHeaders)context.HttpContext.Request.Headers).HeaderAcceptEncoding.First().Contains("gzip"))
//            {
//                using (var memoryStream = new System.IO.MemoryStream())
//                {
//                    var stream = context.HttpContext.Response.Body;
//                    context.HttpContext.Response.Body = memoryStream;

//                    using (var compressedStream = new System.IO.Compression.GZipStream(stream, System.IO.Compression.CompressionLevel.Optimal))
//                    {
//                        context.HttpContext.Response.Headers.Add("Content-Encoding", new string[] { "gzip" });
//                        memoryStream.Seek(0, System.IO.SeekOrigin.Begin);
//                        memoryStream.CopyTo(compressedStream);
//                    }
//                }
//            }
//        }
//        //public override void OnActionExecuted(ActionExecutedContext context)
//        //{
//        //    try
//        //    {
//        //        base.OnActionExecuted(context);

//        //        var headers = context.HttpContext.Request.Headers;
//        //        if (headers is Microsoft.AspNet.Server.Kestrel.Http.FrameRequestHeaders && ((Microsoft.AspNet.Server.Kestrel.Http.FrameRequestHeaders)headers).HeaderAcceptEncoding.FirstOrDefault() != null
//        //            && ((Microsoft.AspNet.Server.Kestrel.Http.FrameRequestHeaders)context.HttpContext.Request.Headers).HeaderAcceptEncoding.First().Contains("gzip"))
//        //        {
//        //            using (var memoryStream = new System.IO.MemoryStream())
//        //            {
//        //                var stream = context.HttpContext.Response.Body;
//        //                context.HttpContext.Response.Body = memoryStream;

//        //                using (var compressedStream = new System.IO.Compression.GZipStream(stream, System.IO.Compression.CompressionLevel.Optimal))
//        //                {
//        //                    context.HttpContext.Response.Headers.Add("Content-Encoding", new string[] { "gzip" });
//        //                    memoryStream.Seek(0, System.IO.SeekOrigin.Begin);
//        //                    memoryStream.CopyTo(compressedStream);
//        //                }
//        //            }
//        //        }
//        //            //using (var memoryStream = new System.IO.MemoryStream())
//        //            //{
//        //            //var stream = context.HttpContext.Response.Body;
//        //            //context.HttpContext.Response.Body = memoryStream;

//        //            //var compressedStream = new System.IO.Compression.GZipStream(context.HttpContext.Response.Body, System.IO.Compression.CompressionLevel.Optimal));
//        //            //context.HttpContext.Response.Body = compressedStream;
//        //            //context.HttpContext.Response.Headers.Add("Content-Encoding", new string[] { "gzip" });
//        //            //using (var compressedStream = new System.IO.Compression.GZipStream(context.HttpContext.Response.Body, System.IO.Compression.CompressionLevel.Optimal))
//        //            //    {
//        //            //    //compressedStream.Seek(0, System.IO.SeekOrigin.Begin);
//        //            //        context.HttpContext.Response.Body = compressedStream;
//        //            //        context.HttpContext.Response.Headers.Add("Content-Encoding", new string[] { "gzip" });
//        //            //        //memoryStream.Seek(0, System.IO.SeekOrigin.Begin);
//        //            //        //memoryStream.CopyToAsync(compressedStream);
//        //            //    }

//        //            //context.HttpContext.Response.Body = new PushStreamContent(async (stream, content, ctx) =>
//        //            //{
//        //            //    using (contentStream)
//        //            //    using (var zipStream = new GZipStream(stream, CompressionLevel.Optimal))
//        //            //    {
//        //            //        await contentStream.CopyToAsync(zipStream);
//        //            //    }
//        //            //});
//        //            //}
//        //            //}
//        //        }
//        //    catch (Exception ex) { }
//        //    ////context.HttpContext.Items["costumGzip"] = true;
//        //    //bool supportGZip = context.HttpContext.Request.Headers["AcceptEncoding"].Any(x => x.Contains("gzip"));

//        //    //if (!supportGZip)
//        //    //{
//        //    //    base.OnActionExecuted(context);
//        //    //    return;
//        //    //}

//        //    //var contentStream = context.HttpContext.Response.Body;

//        //    //context.HttpContext.Response.Body = new PushStreamContent(async (stream, content, ctx) =>
//        //    //{
//        //    //    using (contentStream)
//        //    //    using (var zipStream = new GZipStream(stream, CompressionLevel.Optimal))
//        //    //    {
//        //    //        await contentStream.CopyToAsync(zipStream);
//        //    //    }
//        //    //});

//        //    //context.HttpContext.Response.Headers.Remove("Content-Type");
//        //    //context.HttpContext.Response.Headers.Add("Content-encoding", "gzip");
//        //    //context.HttpContext.Response.Headers.Add("Content-Type", "application/json");
//        //}
//    }
//}
