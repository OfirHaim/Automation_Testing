﻿using GSports.Online.Contracts;
using GSports.Online.Context.Implementations;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.OnlineApi.BL
{
    public class DiRegistration
    {
        public static void RegisterServices(IServiceCollection services)
        {
            services.AddTransient<IEventContext, EventContext>();
            services.AddTransient<IUserContext, UserContext>();
            services.AddTransient<IMetadataContext, MetadataContext>();
            services.AddTransient<IBetContext, BetContext>();
            services.AddTransient<IFinanceContext, FinanceContext>();
        }

    }
}
