﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GSports.Online.Contracts;
using System.Threading;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Builder;
using GSports.Online.Model.Response.FinanceService;
using GSports.Online.Model.Request.FinanceService;
using GSports.OnlineApi.BL;
using GSports.Online.Model.Response.Base;
using GSports.OnlineAPI.BL;

namespace GSports.OnlineApi.Controllers
{
    [Route("[controller]/[action]")]
    public class FinanceController : GSBaseController, IFinanceContext
    {
        private readonly IFinanceContext financeChannel;

        public FinanceController(IFinanceContext channel)
        {
            financeChannel = channel;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public GetTransactionResponse GetTransactions([FromBody] GetTransactionRequest request)
        {
            GetTransactionResponse retVal = new GetTransactionResponse();
            try
            {
                retVal = financeChannel.GetTransactions(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        [HttpPost]
        [UserInfoFilter]
        [LogFilterAtrribute]
        public DepositResponse Deposit([FromBody] DepositRequest request)
        {
            DepositResponse retVal = new DepositResponse();
            try
            {
                retVal = financeChannel.Deposit(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        [HttpPost]
        [UserInfoFilter]
        [LogFilterAtrribute]
        public WithdrawResponse Withdraw([FromBody] WithdrawRequest request)
        {
            WithdrawResponse retVal = new WithdrawResponse();
            try
            {
                retVal = financeChannel.Withdraw(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        [HttpPost]
        [UserInfoFilter]
        [LogFilterAtrribute]
        public CancelWithdrawResponse CancelWithdraw([FromBody] CancelWithdrawRequest request)
        {
            CancelWithdrawResponse retVal = new CancelWithdrawResponse();
            try
            {
                retVal = financeChannel.CancelWithdraw(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        [HttpPost]
        [LogFilterAtrribute]
        public GetTransferHistoryResponse GetTransferHistory([FromBody] GetTransferHistoryRequest request)
        {
            GetTransferHistoryResponse retVal = new GetTransferHistoryResponse();
            try
            {
                retVal = financeChannel.GetTransferHistory(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;

        }
        [HttpPost]
        [LogFilterAtrribute]
        public SendWithdrawCodeResponse SendWithdrawCode([FromBody]SendWithdrawCodeRequest request)
        {
            return financeChannel.SendWithdrawCode(request);
            SendWithdrawCodeResponse retVal = new SendWithdrawCodeResponse();
            try
            {
                retVal = financeChannel.SendWithdrawCode(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
    }
}
