﻿using GSports.Online.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Online.Model.Request.MetadataService;
using GSports.Online.Model.Response.MetadataService;
using Microsoft.Extensions.Configuration;
using GSports.Online.Model.ConfigModels;
using GSports.Online.Model.Entities;
using Newtonsoft.Json;
using Microsoft.Extensions.Caching.Memory;
using GSports.OnlineApi.BL;
using Microsoft.Extensions.Options;
using GSports.Online.Model.Response.Base;

namespace GSports.OnlineApi.Controllers
{
    [Route("[controller]/[action]")]
    public class MetadataController : GSBaseController, IMetadataContext
    {
        private readonly IMetadataContext MetadataChannel;
        private readonly List<Item> btTemplate;
        private readonly IMemoryCache _cache;

        public MetadataController(IMetadataContext metadataChannel, IOptions<DisplayBetTypes> displayBetTypesConfig, IMemoryCache cache)
        {
            MetadataChannel = metadataChannel;
            btTemplate = displayBetTypesConfig.Value.Items;
            _cache = cache;
        }

        public GetCountriesResponse GetCountries(GetCountriesRequest request)
        {
            GetCountriesResponse retVal = new GetCountriesResponse();
            try
            {
                retVal = MetadataChannel.GetCountries(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        [HttpGet]
        public GetUserCountriesResponse GetUserCountries(GetUserCountriesRequest request)
        {
            GetUserCountriesResponse retVal = new GetUserCountriesResponse();
            try
            {
                retVal = MetadataChannel.GetUserCountries(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        [HttpGet]
        public GetSecurityQuestionsResponse GetSecurityQuestions(GetSecurityQuestionsRequest request)
        {
            GetSecurityQuestionsResponse retVal = new GetSecurityQuestionsResponse();
            try
            {
                retVal = MetadataChannel.GetSecurityQuestions(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        [HttpGet]
        public GetUserCurrenciesResponse GetUserCurrencies(GetUserCurrenciesRequest request)
        {
            GetUserCurrenciesResponse retVal = new GetUserCurrenciesResponse();
            try
            {
                retVal = MetadataChannel.GetUserCurrencies(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        //cache output
        [HttpGet]
        public GetBetTypesTemplateResponse GetBetTypeTemplate(GetBetTypesTemplateRequest request)
        {
            GetBetTypesTemplateResponse retVal = new GetBetTypesTemplateResponse()  ;
            try
            {
                if (!_cache.TryGetValue("betTypeTemplate", out retVal))
                {
                    retVal = MetadataChannel.GetBetTypeTemplate(request);
                    if (retVal.IsSuccessfull)
                    {
                        var joined = btTemplate.SelectMany(s => s.Live).Union(btTemplate.SelectMany(s => s.Prematch));

                        joined.ToList().ForEach(x =>
                        {
                            if (x.Lines != null && x.Lines.Count > 1)
                            {
                                var corrBt = retVal.BetTypesSchema.FirstOrDefault(bts => bts.Id == x.Id);
                                retVal.BetTypesSchema.Remove(corrBt);
                                x.Lines.ForEach(line =>
                                {
                                    var copy = Newtonsoft.Json.JsonConvert.DeserializeObject<BetTypeTemplate>(Newtonsoft.Json.JsonConvert.SerializeObject(corrBt), new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace });
                                    copy.DisplayLine = line;
                                    copy.IsLineDisplay = x.isLineDisplay;
                                    copy.ForDisplay = true;
                                    retVal.BetTypesSchema.Add(copy);
                                });
                            }
                            else
                            {
                                var bt = retVal.BetTypesSchema.FirstOrDefault(f => f.Id == x.Id);
                                if (bt != null)
                                {
                                    bt.ForDisplay = true;
                                    bt.IsLineDisplay = x.isLineDisplay;
                                    bt.DisplayLine = x.Lines?.FirstOrDefault();
                                }
                            }
                        });
                    }
                    _cache.Set("betTypeTemplate", retVal, new MemoryCacheEntryOptions().SetAbsoluteExpiration(relative: TimeSpan.FromHours(1)));
                }
            }
            catch(Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            
            return retVal;
        }
    }
}
