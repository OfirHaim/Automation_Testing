﻿//using GSports.Online.Model.Request.UserService;
//using GSports.OnlineApi.BL;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Mvc;
//using System;
//using System.Collections.Generic;
//using System.IdentityModel.Tokens;
//using System.IdentityModel.Tokens.Jwt;
//using System.Linq;
//using System.Security.Claims;
//using System.Security.Principal;
//using System.Text;
//using System.Threading.Tasks;

//namespace GSports.OnlineApi.Controllers
//{
//    [Route("[controller]/[action]")]
//    public class TokenController : GSBaseController
//    {
//        private readonly TokenAuthOptions tokenOptions;

//        public TokenController(TokenAuthOptions tokenOptions)
//        {
//            this.tokenOptions = tokenOptions;
//            //this.bearerOptions = options.Value;
//            //this.signingCredentials = signingCredentials;
//        }

//        /// <summary>
//        /// Check if currently authenticated. Will throw an exception of some sort which shoudl be caught by a general
//        /// exception handler and returned to the user as a 401, if not authenticated. Will return a fresh token if
//        /// the user is authenticated, which will reset the expiry.
//        /// </summary>
//        /// <returns></returns>
//        [HttpGet]
//        [Authorize("Bearer")]
//        public dynamic GetData()
//        {
//            /* 
//            ******* WARNING WARNING WARNING ****** 
//            ******* WARNING WARNING WARNING ****** 
//            ******* WARNING WARNING WARNING ****** 
//            THIS METHOD SHOULD BE REMOVED IN PRODUCTION USE-CASES - IT ALLOWS A USER WITH 
//            A VALID TOKEN TO REMAIN LOGGED IN FOREVER, WITH NO WAY OF EVER EXPIRING THEIR
//            RIGHT TO USE THE APPLICATION.
//            Refresh Tokens (see https://auth0.com/docs/refresh-token) should be used to 
//            retrieve new tokens. 
//            ******* WARNING WARNING WARNING ****** 
//            ******* WARNING WARNING WARNING ****** 
//            ******* WARNING WARNING WARNING ****** 
//            */
//            bool authenticated = false;
//            string user = null;
//            int entityId = -1;
//            string token = null;
//            DateTime? tokenExpires = default(DateTime?);

//            var currentUser = HttpContext.User;
//            if (currentUser != null)
//            {
//                authenticated = currentUser.Identity.IsAuthenticated;
//                if (authenticated)
//                {
//                    user = currentUser.Identity.Name;
//                    foreach (Claim c in currentUser.Claims) if (c.Type == "EntityID") entityId = Convert.ToInt32(c.Value);
//                    tokenExpires = DateTime.UtcNow.AddMinutes(2);
//                    token = GetToken(currentUser.Identity.Name, tokenExpires);
//                }
//            }
//            return new { authenticated = authenticated, user = user, entityId = entityId, token = token, tokenExpires = tokenExpires };
//        }

//        /// <summary>
//        /// Request a new token for a given username/password pair.
//        /// </summary>
//        /// <param name="request"></param>
//        /// <returns></returns>
//        [HttpPost]
//        public object LogIn([FromBody] LoginRequest request)
//        {
//            // Obviously, at this point you need to validate the username and password against whatever system you wish.
//            if (request.Username == "TEST" && request.Password == "TEST")
//            {
//                DateTime? expires = DateTime.UtcNow.AddMinutes(10);
//                var token = GetToken(request.Username, expires);
//                return new { authenticated = true, entityId = 1, token = token, tokenExpires = expires };
//            }
//            return new { authenticated = false };
//        }

//        private string GetToken(string user, DateTime? expires)
//        {
//            var handler = new JwtSecurityTokenHandler();

//            // Here, you should create or look up an identity for the user which is being authenticated.
//            // For now, just creating a simple generic identity.
//            ClaimsIdentity identity = new ClaimsIdentity(new GenericIdentity(user, "TokenAuth"), new[] { new Claim("EntityID", "1", ClaimValueTypes.Integer) });
//            var securityToken = handler.CreateToken(
//                issuer: tokenOptions.Issuer,
//                audience: tokenOptions.Audience,
//                signingCredentials: tokenOptions.SigningCredentials,
//                subject: identity,
//                expires: expires,
//                issuedAt: DateTime.UtcNow
//                );
//            return handler.WriteToken(securityToken);
//        }
//    }
//}
