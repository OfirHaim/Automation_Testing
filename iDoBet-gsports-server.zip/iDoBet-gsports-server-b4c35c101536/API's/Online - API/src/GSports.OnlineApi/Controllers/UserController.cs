﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GSports.Online.Contracts;
using GSports.Online.Model.Request.UserService;
using GSports.Online.Model.Response.UserService;
using Microsoft.AspNetCore.Http.Features;
using System.Threading;
using GSports.OnlineApi.BL;
using GSports.Online.Model.Response.Base;
using Microsoft.Extensions.Options;
using GSports.Online.Model.ConfigModels;
using GSports.OnlineAPI.BL;

namespace GSports.OnlineApi.Controllers
{
    [Route("[controller]/[action]")]
    public class UserController : GSBaseController, IUserContext
    {
        private readonly IUserContext _userChannel;
        private readonly string _apiToken;
        //private readonly IHttpConnectionFeature _httpContextFeature;

        public UserController(IUserContext userContext/*, IHttpConnectionFeature httpContextFeature*/, IOptions<AppConfig> appConfig)
        {
            _userChannel = userContext;
            _apiToken = appConfig.Value.APIToken;
        }
        [HttpPost]
        [LogFilterAtrribute]
        public ActivateAccountResponse ActivateAccount([FromBody] ActivateAccountRequest request)
        {
            ActivateAccountResponse retVal = new ActivateAccountResponse();
            try
            {
                retVal = _userChannel.ActivateAccount(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public ChangePasswordResponse ChangePassword([FromBody] ChangePasswordRequest request, bool isReset = false)
        {
            ChangePasswordResponse retVal = new ChangePasswordResponse();
            try
            {
                retVal = _userChannel.ChangePassword(request);
            }
            catch(Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        //public ForgotLoginDetailsResponse ForgotLoginDetails(ForgotLoginDetailsRequest request)
        //{
        //    ForgotLoginDetailsResponse retVal = new ForgotLoginDetailsResponse();
        //    try
        //    {
        //        retVal = _userChannel.ForgotLoginDetails(request);
        //    }
        //    catch (Exception ex)
        //    {
        //        retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
        //    }
        //    return retVal;
        //}

        [HttpPost]
        [LogFilterAtrribute]
        public LoginResponse LoginUser([FromBody] LoginRequest request)
        {
            //var remoteIpAddress = _httpContextFeature.RemoteIpAddress.ToString();                      
            LoginResponse retVal = new LoginResponse();
            try
            {
                retVal = _userChannel.LoginUser(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public LogoutUserResponse LogoutUser([FromBody] LogoutUserRequest request)
        {
            LogoutUserResponse retVal = new LogoutUserResponse();
            try
            {
                retVal = _userChannel.LogoutUser(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public RegisterUserResponse RegisterUser([FromBody] RegisterUserRequest request)
        {
            RegisterUserResponse retVal = new RegisterUserResponse();
            try
            {
                retVal = _userChannel.RegisterUser(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        [HttpPost]
        [LogFilterAtrribute]
        public ResendActivationLinkResponse ResendActivationLink([FromBody] ResendActivationLinkRequest request)
        {
            ResendActivationLinkResponse retVal = new ResendActivationLinkResponse();
            try
            {
                retVal = _userChannel.ResendActivationLink(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public UpdateUserResponse UpdateUserProfile([FromBody]UpdateUserRequest request)
        {
            UpdateUserResponse retVal = new UpdateUserResponse();
            try
            {
                retVal = _userChannel.UpdateUserProfile(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        [HttpGet]
        [LogFilterAtrribute]
        public GetUserInfoResponse GetUserInfo(GetUserInfoRequest request)
        {
            GetUserInfoResponse retVal = new GetUserInfoResponse();
            try
            {
                retVal = _userChannel.GetUserInfo(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public GetUserByTokenResponse GetUserByToken([FromBody]GetUserByTokenRequest request)
        {
            GetUserByTokenResponse retVal = new GetUserByTokenResponse();
            try
            {
                retVal = _userChannel.GetUserByToken(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        [HttpPost]
        [UserInfoFilter]
        public KeepAliveResponse KeepAlive([FromBody]KeepAliveRequest request)
        {
            KeepAliveResponse retVal = new KeepAliveResponse();
            try
            {
                retVal = _userChannel.KeepAlive(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        [HttpGet]
        [LogFilterAtrribute]
        public GetUserSecurityQuestionResponse GetUserSecurityQuestion(GetUserSecurityQuestionRequest request,string api)
        {
            GetUserSecurityQuestionResponse retVal = new GetUserSecurityQuestionResponse();
            try
            {
                retVal = _userChannel.GetUserSecurityQuestion(request,_apiToken);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public ForgotLoginDetailsResponse ForgotUserLoginDetails([FromBody]ForgotLoginDetailsRequest request,string _api = null)
        {
            ForgotLoginDetailsResponse retVal = new ForgotLoginDetailsResponse();
            try
            {
                retVal = _userChannel.ForgotUserLoginDetails(request,_apiToken);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public ResetPasswordResponse ResetPassword([FromBody]ResetPasswordRequest request)
        {
            ResetPasswordResponse retVal = new ResetPasswordResponse();
            try
            {
                retVal = _userChannel.ResetPassword(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
    }
}
