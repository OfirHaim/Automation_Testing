﻿using Microsoft.AspNetCore.Mvc;
using GSports.Online.Contracts;
using GSports.Online.Model.Request.EventService;
using GSports.Online.Model.Response.EventService;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using GSports.Clients.EventsManager;
using GSports.OnlineApi.BL;

namespace GSports.OnlineApi.Controllers
{
    [Route("[controller]/[action]")]
    public class EventController : GSBaseController, IEventContext
    {
        private readonly IEventContext eventChannel;
        //private readonly ILogger<EventController> logger;

        public EventController(IEventContext channel)
        {
            //logger = _logger;
            //logger.LogError("EventController started");
            eventChannel = channel;
        }

        //[GzipCompress]
        [HttpGet]
        public GetEventsResponse GetEvents(GetEventsRequest request)
        {
            try 
           { 
                return eventChannel.GetEvents(request);
            }
            catch(Exception ex)
            {
                //logger.LogError(ex.Message);
            }
            return null;
        }

     

        //[HttpGet]
        //public object GetUpdateLog(string eventCk, string betTypeCk, DateTime fromDate)
        //{
        //    return EventSingleton.Instance.updateLog.Where(x => x.Key >= fromDate).Select(x => new { lastUpdate = x.Key, betType = x.Value.Where(a => a.CompareKey == eventCk).SelectMany(b => b.BetTypes).Where(w => w.CompareKey == betTypeCk) });
        //}

    }
}
