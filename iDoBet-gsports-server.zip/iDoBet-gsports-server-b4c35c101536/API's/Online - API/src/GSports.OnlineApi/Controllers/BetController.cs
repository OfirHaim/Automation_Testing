﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GSports.Online.Contracts;
using GSports.Online.Model.Request.BetService;
using GSports.Online.Model.Response.BetService;
using System.Threading;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Builder;
using GSports.OnlineApi.BL;
using GSports.Online.Model.Response.Base;
using GSports.OnlineAPI.BL;

namespace GSports.OnlineApi.Controllers
{
    [Route("[controller]/[action]")]
    public class BetController : GSBaseController, IBetContext
    {
        private readonly IBetContext betChannel;

        public BetController(IBetContext channel)
        {
            betChannel = channel;
        }
        [HttpPost]
        [LogFilterAtrribute]
        public GetBetHistoryResponse GetBetHistory([FromBody] GetBetHistoryRequest request)
        {
            GetBetHistoryResponse retVal = new GetBetHistoryResponse();
            try
            {
                retVal = betChannel.GetBetHistory(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;

        }
        [HttpPost]
        [LogFilterAtrribute]
        public GetBetHistoryResponse GetBetOrderData([FromBody] GetBetHistoryOrderDataRequest request)
        {
            GetBetHistoryResponse retVal = new GetBetHistoryResponse();
            try
            {
                retVal = betChannel.GetBetOrderData(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }


      
        [HttpPost]
        [LogFilterAtrribute]
        public PlaceBetsResponse PlaceBets([FromBody]PlaceBetsRequest request)
        {
            PlaceBetsResponse retVal = new PlaceBetsResponse();
            try
            {
                retVal = betChannel.PlaceBets(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError, ex.Message);
            }
            return retVal;
        }
        
        [HttpPost]
        [UserInfoFilter]
        [LogFilterAtrribute]
        public ExecuteOnlineOrderResponse ExecuteOrder([FromBody]ExecuteOnlineOrderRequest request)
        {
            ExecuteOnlineOrderResponse retVal = new ExecuteOnlineOrderResponse();
            try
            {
                retVal = betChannel.ExecuteOrder(request);
            }
            catch(Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.ApiError,ex.Message );
            }
            return retVal;
        }
    }
}
