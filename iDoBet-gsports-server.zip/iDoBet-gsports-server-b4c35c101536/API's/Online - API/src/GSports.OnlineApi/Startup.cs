﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using GSports.OnlineApi.BL;
using GSports.Clients.EventsManager;
using GSports.Online.Model.ConfigModels;
using GSports.Online.Model.Request.UserService;
using GSports.Online.Context.Implementations;
using GSports.GLogger;

namespace GSports.OnlineAPI
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            Logger.WriteLog(eLogLevel.Info, "Service Starting");
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile("displayBetTypes.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            ServicesConfiguration.ConfigureGeneralServices(services);
            DiRegistration.RegisterServices(services);
            services.Configure<DisplayBetTypes>(options => Configuration.GetSection("DisplayBetTypes").Bind(options));
            services.Configure<AppConfig>(options => Configuration.GetSection("AppConfig").Bind(options));
           


        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, IOptions<AppConfig> appConfig, IOptions<DisplayBetTypes> displayBetTypesConfig)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();
            app.UseCors(builder =>
                        builder.WithOrigins(appConfig.Value.OriginsUrls.Split(',')) 
                               .AllowAnyHeader().AllowAnyMethod().AllowCredentials()
                        );

            app.UseGsGzipCompression();//has to stay in this order
            app.UseMvc();
            app.UseFileServer();
            app.UseStaticFiles();            
            UserContext context = new UserContext();
            LoginRequest request = new LoginRequest() { Username = appConfig.Value.SystemUser, Password = appConfig.Value.SystemPass, IP = "127.0.0.1" };
            var res = context.LoginUser(request);
            string token = res.UserToken;
            appConfig.Value.APIToken = token;
            Task.Run(() => EventSingleton.InitEventSingelton(appConfig.Value.PushServerURL, token, appConfig.Value.IsCacheMaster, appConfig.Value.ChannelName, appConfig.Value.IsDailyCouponOnly,0, appConfig.Value.CheckForChangesInterval, appConfig.Value.ProviderIds));
            Logger.WriteLog(eLogLevel.Info, "Service Started");
        }
    }
}
