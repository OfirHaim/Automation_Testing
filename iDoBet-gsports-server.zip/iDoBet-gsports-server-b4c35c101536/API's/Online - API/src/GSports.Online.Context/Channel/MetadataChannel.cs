﻿using GSports.Common;
using GSports.Model.Filter;
using GSports.Contracts;
using System;
using GSports.GLogger;
using GSports.Online.Model.Request.MetadataService;
using GSports.Online.Model.Response.MetadataService;
using GSports.Model.Requests.Metadata;
using GSports.Online.Context.ModelConvertors;
using System.Linq;
using System.Collections.Generic;

namespace GSports.Online.Context.Channel
{
    public class MetadataChannel
    {
        public static GetBetTypesTemplateResponse GetBetTypeTemplate(GetBetTypesTemplateRequest request)
        {
            var retVal = new GetBetTypesTemplateResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetMetadata>(ServiceConsts.BET_METADATA_SERVICE))
                {
                    var service = factory.CreateChannel();
                    var res = service.GetItems(new GetItemsRequest() { Type = MetadataType.BetType, Filter = new BetTypeFilter() { All = true } });
                    retVal = MetadataConvertor.ConvertToGetTypeResponse(res);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        public static GetUserCountriesResponse GetUserCountries()
        {
            GetUserCountriesResponse retVal = new GetUserCountriesResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetMetadata>(ServiceConsts.BET_METADATA_SERVICE))
                {
                    var service = factory.CreateChannel();
                    var res = service.GetItems(new GetItemsRequest() { Type = MetadataType.UserCountries });
                    retVal = MetadataConvertor.ConvertToUserCountriesResponse(res);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        public static GetSecurityQuestionsResponse GetSecurityQuestions()
        {
            GetSecurityQuestionsResponse retVal = new GetSecurityQuestionsResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetMetadata>(ServiceConsts.BET_METADATA_SERVICE))
                {
                    var service = factory.CreateChannel();
                    var res = service.GetItems(new GetItemsRequest() { Type = MetadataType.SecurityQuestion });
                    retVal = MetadataConvertor.ConvertToGetSeucrityQuestionsResponse(res);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static GetUserCurrenciesResponse GetUserCurrencies()
        {
            GetUserCurrenciesResponse retVal = new GetUserCurrenciesResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetMetadata>(ServiceConsts.BET_METADATA_SERVICE))
                {
                    var service = factory.CreateChannel();
                    var res = service.GetItems(new GetItemsRequest() { Type = MetadataType.Currency });
                    retVal = MetadataConvertor.ConvertToUserCurrenciesResponse(res);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }
    }
}
