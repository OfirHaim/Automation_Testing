﻿using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using GSports.Model.Consts.Notifications;
using GSports.Model.Entities;
using GSports.Model.Requests.Notifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Context.Channel
{
    public class NotificationChannel
    {
        public static bool SendEmail( string title, string message, string recipients, bool isHtml)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<INotificationService>(ServiceConsts.NOTIFICATION_SERVICE))
                {
                   var service = factory.CreateChannel();
                   var noti =new Notification()
                   {                       
                        IsHtml = isHtml,
                        NotificationType = eNotificationAlertType.EMAIL,
                        Recipients = recipients,
                        Message = message,
                        Title = title,
                    };
                    
                    retVal = service.SendNotification(new SendNotificationRequest() { Notification = noti }).IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }
    }
}
