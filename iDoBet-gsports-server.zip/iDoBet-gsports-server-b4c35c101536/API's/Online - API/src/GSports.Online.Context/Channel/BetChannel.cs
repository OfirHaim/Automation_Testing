﻿using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using GSports.Model.Requests.Order;
using GSports.Model.Responses.Order;
using GSports.Online.Context.ModelConvertors;
using GSports.Online.Model.Request.BetService;
using GSports.Online.Model.Response.BetService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Context.Channel
{
    public class BetChannel
    {
        public static OrderResponse RequestForOrder(OrderRequest request)
        {
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var service = factory.CreateChannel();
                    return service.RequestForOrder(request);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return null;
        }

        public static ExecuteOrderResponse ExecuteOrder(ExecuteOrderRequest request)
        {
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var service = factory.CreateChannel();
                    return service.ExecuteOrder(request);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return null;
        }

        public static GetBetHistoryResponse GetBets(GetBetHistoryRequest request)
        {
            GetBetHistoryResponse retVal = new GetBetHistoryResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var req = BetConvertor.ConvertToServerRequest(request);
                    var service = factory.CreateChannel();
                    var res = service.GetBetOrders(req);
                    retVal = BetConvertor.ConvertToClientResponse(res);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(Model.Response.Base.eErrorCode.BadRequest, ex.Message);
            }
            return retVal;
        }

        public static GetBetHistoryResponse GetBetOrderData (GetBetHistoryOrderDataRequest request)
        {
            var retVal = new GetBetHistoryResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var req = BetConvertor.ConvertToServerRequest(request);
                    var service = factory.CreateChannel();
                    
                    var res = service.GetOrdersData(req);
                    retVal = BetConvertor.ConvertToClientResponse(res);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(Model.Response.Base.eErrorCode.BadRequest, ex.Message);
            }
            return retVal;
        }

    }
}


