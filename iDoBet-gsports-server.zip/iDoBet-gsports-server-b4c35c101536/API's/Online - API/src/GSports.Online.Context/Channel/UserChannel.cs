﻿using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using GSports.Model.Entities.User;
using GSports.Model.Filter;
using GSports.Model.Requests.Authentication;
using GSports.Model.Requests.UserService;
using GSports.Model.Responses.Authentication;
using GSports.Model.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Context.Channel
{
    public static class UserChannel
    {
        public static string LoginUser(string userName, string password, string ip)
        {
            string retVal = null;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>(ServiceConsts.AUTHENTICATION_SERVICE))
                {
                    var req = new LoginRequest()
                    {
                        UserName = userName,
                        Password = password,
                        IP = ip,
                        LoginFrom = eLoginFrom.Online,
                    };
                    var service = factory.CreateChannel();
                    var res = service.LoginUser(req);
                    if (!string.IsNullOrEmpty(res.Token))
                    {
                        retVal = res.Token;
                    }
                    else
                        return null;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static ChangePasswordResponse ChangePassword(ChangePasswordRequest request)
        {
            ChangePasswordResponse retVal = new ChangePasswordResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE))
                {
                    var userService = factory.CreateChannel();
                    retVal = userService.ChangeUserPassword(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static bool LogoutUser(string userToken)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>(ServiceConsts.AUTHENTICATION_SERVICE))
                {
                    var req = new LogoutRequest()
                    {
                        UserToken = userToken
                    };
                    var service = factory.CreateChannel();
                    var res = service.LogoutUser(req);
                    retVal = res.IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static ClientUser GetUser(string token, UserFilter filter)
        {
            ClientUser retVal = null;
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE))
                {
                    var userService = userFactory.CreateChannel();
                    var request = new GetUsersRequest();
                    request.Filter = new UserFilter();
                    request.Filter = filter;
                    request.UserToken = token;
                    //{
                    //    UserToken = token,
                    //    Filter = new UserFilter();
                   
                    //    //{
                    //    //    LoadMatrix = true,
                    //    //    LoadLastAccess = true,
                    //    //    IncludeServices = true
                    //    //}
                    //};
                    retVal = userService.GetUsers(request)?.Users?.SingleOrDefault() as ClientUser;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static RegisterUserResponse  RegisterUser(RegisterUserRequest request )
        {
            RegisterUserResponse retVal = new RegisterUserResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>(ServiceConsts.AUTHENTICATION_SERVICE))
                {
                    var service = factory.CreateChannel();
                

                    retVal = service.RegisterUser(request);         

                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InsertWithdrawFailed, ex.Message);
            }
            return retVal;
        }

        public static bool ActivateAccount(string code)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>(ServiceConsts.AUTHENTICATION_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.ActivateOnlineAccount(new ActivateOnlineAccountRequest() {Code = code }).IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static bool ResendActivationLink(int userId)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>(ServiceConsts.AUTHENTICATION_SERVICE))
                {
                    var service = factory.CreateChannel();
                    var user = new ResendActivationCodeRequest() { UserId = userId };
                    retVal = service.ResendActivationCodeToClient(user).IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static bool UpdateUser(ClientUser user)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.UpdateUser(new UpdateUserRequest() { User = user }).IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static string GetUserInfo(string token)
        {
            var retVal = string.Empty;
            try
            {
                using (var factory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetUserInfo(token);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static bool ForgotUserLoginDetails(ForgotPasswordRequest request)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.ForgotPassword(request);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }
    }
}
