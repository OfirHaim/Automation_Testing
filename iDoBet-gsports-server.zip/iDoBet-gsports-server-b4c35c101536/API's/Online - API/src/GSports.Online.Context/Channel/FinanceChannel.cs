﻿using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using GSports.Model.Requests.Order;
using GSports.Model.Responses.Order;
using GSports.Online.Context.ModelConvertors;
using GSports.Online.Model.Request.FinanceService;
using GSports.Online.Model.Response.FinanceService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Context.Channel
{
    public class FinanceChannel
    {
        public static GetTransactionResponse GetTranscations(GetTransactionRequest request)
        {
            GetTransactionResponse retVal = new GetTransactionResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var req = FinanceConverter.ConvertToServerRequest(request);
                    var service = factory.CreateChannel();
                    var res = service.GetTransactions(req);
                    retVal = FinanceConverter.ConvertToClientResponse(res);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(Model.Response.Base.eErrorCode.BadRequest, ex.Message);
            }
            return retVal;
        }

        public static bool Deposit(string token, string code)
        {
            bool retVal = false;

            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    var res = service.UpdateTransfer(new GSports.Model.Requests.Finance.UpdateTransferRequest()
                    {
                        UserToken = token,
                        TransferCode = code,
                        ResponseTypeCodeAttr = Common.CodeAttribute.TransferResponseType.Approved
                    });
                    retVal = res.IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        public static GSports.Model.Responses.Finance.InsertWithdrawResponse Withdraw(WithdrawRequest request)
        {
            var  retVal = new GSports.Model.Responses.Finance.InsertWithdrawResponse() ;

            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    var res = service.InsertWithdraw(new GSports.Model.Requests.Finance.InsertWithdrawRequest()
                    {
                        UserToken = request.UserToken,
                        Amount = request.Amount,
                        PaymentMethod = GSports.Model.Consts.ePaymentMethod.Shop,
                        Password = request.Password,
                        Email = request.Email
                    });
                    retVal = res;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        public static bool CancelWithdraw(string token, long transferId)
        {
            bool retVal = false;

            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    var res = service.UpdateTransfer(new GSports.Model.Requests.Finance.UpdateTransferRequest()
                    {
                        UserToken = token,
                        TransferId = transferId,
                        ResponseTypeCodeAttr = Common.CodeAttribute.TransferResponseType.Cancel
                    });
                    retVal = res.IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        public static GSports.Model.Responses.Finance.GetTransfersResponse GetTransfers(GSports.Model.Requests.Finance.GetTransfersRequest request)
        {
            var retVal = new GSports.Model.Responses.Finance.GetTransfersResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetTransfers(request);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);                
            }

            return retVal;
        }

          
    }
}


