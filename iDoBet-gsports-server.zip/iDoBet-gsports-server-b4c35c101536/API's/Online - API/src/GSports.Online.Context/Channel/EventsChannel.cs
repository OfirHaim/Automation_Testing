﻿using GSports.Common;
using GSports.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.GLogger;
using GSports.Clients.EventsManager;
using GSports.Online.Model.Request.EventService;
using GSports.Online.Model.Response.EventService;
using GSports.Online.Model.Entities;

namespace GSports.Online.Context.Channel
{
    public class EventsChannel
    {
        public static GetEventsResponse GetEvents(GetEventsRequest request)
        {
            GetEventsResponse retVal = new GetEventsResponse() ;
            try
            {
                var res = EventSingleton.Instance.GetEvents(null, null, null, request.EventIds, request.Skip, request.Take, request.BetTypeIds);
                if (res != null)
                {

                    retVal.Events = res.OrderByDescending(x => x.BetTypes.Count).ToList() ;
                    retVal.LastUpdateTime = EventSingleton.Instance.LastUpdate;
                }
                else
                    retVal.SetErrorResult(Model.Response.Base.eErrorCode.EventsNotReady, "Event not ready try again after 10 second");
                
                
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(Model.Response.Base.eErrorCode.EventsNotReady, "Event not ready try again after 10 second");
            }

            return retVal;
        }
        public static GetSportsTreeResponse GetSportsTree(GetSportsTreeRequest request)
        {
            GetSportsTreeResponse retVal = new GetSportsTreeResponse();
         
            try
            {
                var res = EventSingleton.Instance.GetEvents(null, null, null, null);
                if (res != null)
                {
                    TreeNode tree = new TreeNode("root", "root");
                    res.GroupBy(x => x.EventData.SportTypeId).ToList().ForEach(sport =>
                    {

                        TreeNode tSport = new TreeNode(sport.ToList()[0].EventData.SportTypeId.ToString(), sport.ToList()[0].EventData.SportTypeName);

                        sport.GroupBy(x => x.EventData.CountryId).ToList().ForEach(country =>
                        {
                            TreeNode cCounty = new TreeNode(country.ToList()[0].EventData.CountryId.ToString(), country.ToList()[0].EventData.CountryName);

                            country.GroupBy(x => x.EventData.LeagueId).ToList().ForEach(league =>
                            {
                                TreeNode tLeague = new TreeNode(league.ToList()[0].EventData.LeagueId.ToString(), league.ToList()[0].EventData.LeagueName);
                                cCounty.Children.Add(tLeague);
                            });
                            tSport.Children.Add(cCounty);
                        });
                        tree.Children.Add(tSport);
                        retVal.SportsTree = tree;

                    });
                }
                else
                    retVal.SetErrorResult(Model.Response.Base.eErrorCode.EventsNotReady, "Event not ready try again after 10 second");
                }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(Model.Response.Base.eErrorCode.EventsNotReady, "Event not ready try again after 10 second");
            }
            return retVal;
        }
    }
}
