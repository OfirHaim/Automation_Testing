﻿using GSports.GLogger;
using GSports.Model.Entities;

using GSports.Model.Responses.Metadata;
using GSports.Online.Model.Entities;
using GSports.Online.Model.Enums;
using GSports.Online.Model.Request.MetadataService;
using GSports.Online.Model.Response.MetadataService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Context.ModelConvertors
{
    public class MetadataConvertor
    {
        public static GetBetTypesTemplateResponse ConvertToGetTypeResponse(GetItemsResponse data)
        {
            var retVal = new GetBetTypesTemplateResponse();
            retVal.BetTypesSchema = new List<Model.Entities.BetTypeTemplate>();
            try
            {
                var res = data.Items.ConvertAll(x => (BetType)x);

                foreach (var bt in res.OrderByDescending(x => x.Order.HasValue).ThenBy(x => x.Order))
                {
                    Model.Entities.BetTypeTemplate btSchema = new Model.Entities.BetTypeTemplate(bt.Id, bt.ToString(), bt.IsLive, bt.SportType.Id, false, false);
                    btSchema.Odds = new List<List<Model.Entities.OddTemplate>>();
                    bt.Odds.OrderBy(x => x.OrderRow).GroupBy(x => x.OrderRow).ToList().ForEach(x => {
                        var rowOdds = new List<Model.Entities.OddTemplate>();
                        x.OrderBy(o => o.OrderCol).ToList().ForEach(f => rowOdds.Add(new Model.Entities.OddTemplate(f.ToString())));
                        btSchema.Odds.Add(rowOdds);
                    });
                    retVal.BetTypesSchema.Add(btSchema);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);

            }
            return retVal;
        }

        public static GetUserCountriesResponse ConvertToUserCountriesResponse(GetItemsResponse res)
        {
            GetUserCountriesResponse retVal = new GetUserCountriesResponse();
            retVal.Countries = new List<UserCountry>();
            foreach (var item in res.Items)
            {
                var country = item as GSports.Model.Entities.LocalSystem.UserCountry;
                retVal.Countries.Add(new UserCountry(country.Id, country.Name, country.PhoneCode));
            }
            return retVal;
        }
        public static GetUserCurrenciesResponse ConvertToUserCurrenciesResponse(GetItemsResponse res)
        {
            GetUserCurrenciesResponse retVal = new GetUserCurrenciesResponse();
            retVal.Currencies = new List<Currency>();
            foreach (var item in res.Items)
            {
                var currency = item as GSports.Model.Entities.LocalSystem.Currency;
                retVal.Currencies.Add(new Currency(currency.Id, currency.Name));
            }
            return retVal;
        }

        public static GetSecurityQuestionsResponse ConvertToGetSeucrityQuestionsResponse(GetItemsResponse res)
        {
            GetSecurityQuestionsResponse retVal = new GetSecurityQuestionsResponse();
            retVal.SecurityQuestions = new List<SecurityQuestion>();
            foreach (var item in res.Items)
            {
                var securityQuestion = item as GSports.Model.Entities.LocalSystem.SecurityQuestion;
                retVal.SecurityQuestions.Add(new SecurityQuestion(securityQuestion.Id,securityQuestion.Question,string.Empty));
            }
            return retVal;
        }
    }
}
