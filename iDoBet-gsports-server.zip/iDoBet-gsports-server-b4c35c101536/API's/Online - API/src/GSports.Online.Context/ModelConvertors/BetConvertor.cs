﻿using GSports.Model.Entities.Event;
using GSports.Model.Requests.Order;
using GSports.Model.Responses.Order;
using GSports.Online.Context.Implementations;
using GSports.Online.Model.Request.BetService;
using GSports.Online.Model.Response.BetService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Configuration;
using GSports.Common.RecieptHelper;
using GSports.Clients.EventsManager.BL.ModelConvertor;
using GSports.Common;

namespace GSports.Online.Context.ModelConvertors
{
    public class BetConvertor
    {
        public static OrderRequest ConvertOrderRequest(PlaceBetsRequest request)
        {
            return new OrderRequest()
            {
                ExternalID = "Online",
                UserToken = request.UserToken,
                TerminalSecurityCode = "online",
                Selections = GetServerSelections(request.Selections),
                Rows = GetServerRows(request.Rows),
                IsBooking = request.IsBooking
            };
        }

        public static GetBetOrderRequest ConvertToServerRequest(GetBetHistoryRequest request)
        {
            var retVal = new GetBetOrderRequest();
            retVal.Filter = new GSports.Model.Filter.OrderFilter();
            retVal.Filter.FromDate = request.FromDate;
            retVal.Filter.ToDate = request.ToDate;
            retVal.Filter.OrderNumber =  request.OrderNumber;
            retVal.Filter.WinStatusIds = (request.WinStatusIds != null) ? request.WinStatusIds.ConvertAll(x => (int)x) : null;
            retVal.UserToken = request.UserToken;
            return retVal;
        }
        public static GetOrdersDataRequest ConvertToServerRequest(GetBetHistoryOrderDataRequest request)
        {
            var retVal = new GetOrdersDataRequest();
            retVal.Barcod = request.Barcode;
            retVal.Id = request.OrderId;
            retVal.UserToken = request.UserToken;
            return retVal;
        }
        public static GetBetHistoryResponse ConvertToClientResponse(GetBetOrderResponse res)
        {
            var retVal = new GetBetHistoryResponse();
            retVal.Orders = ConvertOrderEntityToOrder(res.Orders);
            retVal.Result = ConvertGsportResResultToModelResponseRes(res.Result);
            return retVal;
        }

        public static GetBetHistoryResponse ConvertToClientResponse(GetOrdersDataResponse res)
        {
            var retVal = new GetBetHistoryResponse();
            retVal.Orders = ConvertOrderEntityToOrder(res.Orders);
            retVal.Result = ConvertGsportResResultToModelResponseRes(res.Result);
            return retVal;
        }



        private static List<GSports.Model.Requests.Order.Selection> GetServerSelections(List<Model.Request.BetService.Selection> list)
        {
            var retVal = new List<GSports.Model.Requests.Order.Selection>();

            list.ForEach(x => retVal.Add(new GSports.Model.Requests.Order.Selection()
            {
                BetTypeId = x.BetTypeId,
                EventId = x.EventId,
                Key = x.Key,
                OddLine = x.OddLine,
                OddName = x.OddName,
                OddPrice = x.OddPrice
            }));

            return retVal;
        }

        private static List<GSports.Model.Requests.Order.RequestOrderRow> GetServerRows(List<Model.Request.BetService.RequestOrderRow> list)
        {
            var retVal = new List<GSports.Model.Requests.Order.RequestOrderRow>();

            list.ForEach(x => retVal.Add(new GSports.Model.Requests.Order.RequestOrderRow()
            {
                Amount = x.Amount,
                SelectionKeys = x.SelectionKeys
            }));

            return retVal;
        }

        private static List<GSports.Online.Model.Entities.Order> ConvertOrderEntityToOrder(List<GSports.Model.Entities.OrderEntity> list)
        {
            var retVal = new List<GSports.Online.Model.Entities.Order>();

            list.ForEach(x => retVal.Add(new GSports.Online.Model.Entities.Order()
            {
                Id = x.Id,
                Amount = x.Amount,
                Barcode = x.Barcode,
                CreationTime = x.CreateTime,
                CurrencyId = x.OrderCurrency.Id,
                CurrencyName = x.OrderCurrency.Name,
                ExpiryDate = x.ExpiryDate,
                ExternalId = x.ExternalId,
                MaxPayout = x.MaxPayout,
                OrderNumber = x.OrderNumber,
                OrderProd = (Model.Entities.eOrderProd)x.OrderProd,
                OrderRows = ConvertOrderRowEntityToOrderRow(x.OrderRows),
                RequestGuid = x.RequestGuid,
                SettledTime = x.SettledTime,
                SoldTime = x.SoldTime,
                Status = (Model.Enums.eOrderStatus)x.Status,
                TransactionId = x.TransactionId,
                UserId = x.Employee.Id,
                UserName = x.Name,
                WinStatus = (Model.Entities.eWinStatus)x.WinStatus,
                Payout = x.ActualPayout,
                TaxDesc = x.TaxDesc,
                TotalTax = x.TotalTax,
                BonusDesc = x.BonusDesc,
                TotalBonus = x.TotalBonus,
                TotalSelections = x.TotlaSelection,
                TotalLines = x.TotlaLines

            }));

            return retVal;
        }

        private static List<Model.Entities.OrderRow> ConvertOrderRowEntityToOrderRow(List<GSports.Model.Entities.Order.OrderRowEntity> list)
        {
            var retVal = new List<Model.Entities.OrderRow>();
            //It will be bull whne call to get orders methods,  
            //it will be with data when call to get order data 
            if (list != null)
            {
                list.ForEach(x => retVal.Add(new Model.Entities.OrderRow()
                {
                    Amount = x.Amount,
                    Id = x.Id,
                    OrderId = x.OrderId,
                    TotalRatio =  x.TotalRatio,
                    Payout =  x.Payout,
                    Bonus =  x.BonusAmount,                    
                    WinStatus = (Model.Entities.eWinStatus)x.WinStatus,
                    Bets = ConvertGsportModelOrderBetToOnlineOrderBet(x.Bets),
                }));
            }
            return retVal;
        }

        private static List<Model.Entities.OrderBet> ConvertGsportModelOrderBetToOnlineOrderBet(List<GSports.Model.Entities.OrderBet> list)
        {
            var retVal = new List<Model.Entities.OrderBet>();
            var listOfSportEvent = new List<SportGame>();
            list.ForEach(x => listOfSportEvent.Add(x.Event));
            var eventList = EventConverter.convertEvents(listOfSportEvent);
            list.ForEach(x => retVal.Add(new Model.Entities.OrderBet()
            {
                Id = x.Id,
                OrderId = x.OrderId,
                OrderRowId = x.OrderRowId,
                BetInfo =x.BetInfo+ ((x.Event.Scores == null) ? "" : string.Join(" ", x.Event.Scores.ToList().Select(e => (e.Value == null) ? "" : string.Format("{0}: {1}-{2} ", e.Key.ToEnumString(), e.Value.HomeScore, e.Value.AwayScore)))),
                LiveInfo = x.LiveInfo,
                WinStatus = (Model.Entities.eWinStatus)x.Odd.WinStatus                             
            }));
            for (int i = 0; i < list.Count; i++)
            {
                retVal[i].Event = eventList[i];
            }
            return retVal;
        }
        private static Model.Response.Base.Result ConvertGsportResResultToModelResponseRes(GSports.Model.Responses.Result res)
        {
            var retVal = new Model.Response.Base.Result();
            retVal.AdditionalInfo = res.AdditionalInfo;
            retVal.ErrorCode = (GSports.Online.Model.Response.Base.eErrorCode)res.ErrorCode;
            retVal.ErrorCodeDescription = res.ErrorDescription;
            retVal.ResultCode = (GSports.Online.Model.Response.Base.eResultCode)res.ResultCode;
            return retVal;
        }
    }
}

