﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Model.Entities.Finance;
using GSports.Model.Requests.Finance;
using GSports.Model.Responses.Finance;
using GSports.Online.Model.Entities;
using GSports.Online.Model.Request.FinanceService;
using GSports.Online.Model.Response.FinanceService;
using GSports.Common;

namespace GSports.Online.Context.ModelConvertors
{
    public class FinanceConverter
    {
        public static GSports.Model.Requests.Finance.GetTransactionsRequest ConvertToServerRequest(GetTransactionRequest request)
        {
            var retVal = new GetTransactionsRequest();
            retVal.Filter = new GSports.Model.Filter.TransactionFilter();
            retVal.UserToken = request.UserToken;
            retVal.Filter.FromDate = request.FromDate;
            retVal.Filter.ToDate = request.ToDate;
            retVal.Filter.TransactionTypeCode = request.TransactionTypeCode;
            retVal.Filter.TransactionReasonCode = request.TransactionReasonCode;
            return retVal;
        }

        public static GSports.Model.Requests.Finance.GetTransfersRequest ConvertToServerRequest(GetTransferHistoryRequest request)
        {
            var retVal = new GSports.Model.Requests.Finance.GetTransfersRequest();
            retVal.Filter = new GSports.Model.Filter.TransferFilter()
            {
                FromDate = request.FromDate,
                ToDate = request.ToDate,
                OpenOnly = request.OpenOnly,
                ShiftId = request.ShiftId,
                TransferId = request.ShiftId,
                UserId = request.UserId,               
            };
            if (request.TransferTypeCode != null)
                retVal.Filter.TransferRequestTypes = new List<string>() { request.TransferTypeCode };
            retVal.UserToken = request.UserToken;
            return retVal;
        }
        public static GSports.Online.Model.Response.FinanceService.GetTransactionResponse ConvertToClientResponse(GetTransactionsResponse res)
        {
            var retVal = new GetTransactionResponse();
            retVal.Transactions = new List<TransactionsEntity>();
            retVal.Transactions = ConvertTranscationEntityToTranscation(res.Transactions);
            return retVal;
        }

        private static List<TransactionsEntity> ConvertTranscationEntityToTranscation(List<Transaction> list)
        {
            var retval = new List<TransactionsEntity>();
            list.ForEach(x => retval.Add(new TransactionsEntity()
            {
                Amount = Math.Round((x.TransactionType.CodeAttribute == CodeAttribute.TransactionType.Credit ? x.Amount : -x.Amount),2),
                Comments = x.Comments,
                CreateTime = x.CreateTime,
                CurrentBalance = Math.Round (x.OpenBalance + (x.TransactionType.CodeAttribute == CodeAttribute.TransactionType.Credit ? x.Amount : -x.Amount),2),
                TranscationType = convertTransactionTypeToOnline(x.TransactionType),
                TransactionReason = convertTransactionReasonToOnline(x.TransactionReason),
                AddressedObjectId = x.AddressedObjectId,
                ObjectType = x.ObjectType
            }));
            return retval;
            throw new NotImplementedException();
        }

        private static Model.Entities.TransactionReason convertTransactionReasonToOnline(GSports.Model.Entities.Finance.TransactionReason transactionReason)
        {
            var retVal = new Model.Entities.TransactionReason();
            retVal.CodeAttribute = transactionReason.CodeAttribute;
            retVal.Name = transactionReason.Name;
            return retVal;
        }

        private static Model.Entities.TransactionType convertTransactionTypeToOnline(GSports.Model.Entities.Finance.TransactionType transactionType)
        {
            var retVal = new Model.Entities.TransactionType();
            retVal.CodeAttribute = transactionType.CodeAttribute;
            return retVal;
        }

        public static GetTransferHistoryResponse ConvertToClientResponse(GetTransfersResponse res)
        {
            var retVal = new GetTransferHistoryResponse();
            retVal.Transfers = new List<TransferHistory>();


            res.Transfers.ForEach(x =>
            {               
                    retVal.Transfers.Add(new TransferHistory()
                    {
                        Amount = x.RequestAmount,
                        Comments = x.RequestComments,                        
                        ResponseType = new TransferReason() {  CodeAttribute = x.ResponseType.CodeAttribute, Name =x.ResponseType.Name },                          
                        Date = x.CreateTime,
                        TransactionType = new TransferType() { CodeAttribute = x.RequestType.CodeAttribute, Name = x.RequestType.Name },
                        Id = x.Id
                    });
            });
            return retVal;
        }
    }
}
