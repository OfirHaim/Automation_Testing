﻿using GSports.Online.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Online.Model.Request.UserService;
using GSports.Model.Responses.Authentication;
using GSports.Online.Model.Response.UserService;
using GSports.Online.Model.Enums;

namespace GSports.Online.Context.ModelConvertors
{
    public class UserConvertor
    {
        public static UserEntity ConvertUserEntity(GSports.Model.Entities.User.ClientUser userEnitity)
        {

            if (userEnitity == null) return null;
            else
            {
                UserEntity retVal = new UserEntity();

                retVal.AcceptNewsletter = userEnitity.AcceptNewsletter;
                retVal.Birthday = userEnitity.Birthday;
                retVal.Gender = (Model.Enums.eGender)userEnitity.Gender;
                retVal.IsActivated = userEnitity.ConfirmationEmailTime.HasValue;
                retVal.AccountId = userEnitity.AccountId ?? -1;
                retVal.Balance = userEnitity.ActualBalance ?? -1;
                retVal.Address = userEnitity.Address;
                retVal.Email = userEnitity.Email;
                retVal.Holding = userEnitity.Holding ?? -1;
                retVal.LastName = userEnitity.LastName;
                retVal.FirstName = userEnitity.FirstName;
                retVal.Phone = userEnitity.Phone;
                retVal.Token = userEnitity.LastAccess.Token.ToString();
                retVal.UserId = userEnitity.Id;
                retVal.UserName = userEnitity.UserName;
                retVal.OddsView = (eOddsDisplay)userEnitity.OddsView;
                if (userEnitity.Currency != null)
                    retVal.Currency = new Currency(userEnitity.Currency.Id, userEnitity.Currency.Name);
                retVal.MaxBet = userEnitity.MaxBet;
                retVal.MinBet = userEnitity.MinBet;
                if (userEnitity.Country != null)
                    retVal.Country = new Country(userEnitity.Country.Id, userEnitity.Country.Name);

                if (!string.IsNullOrEmpty(userEnitity.FirstName) && !string.IsNullOrEmpty(userEnitity.LastName) && !string.IsNullOrEmpty(userEnitity.Email)
                    && !string.IsNullOrEmpty(userEnitity.Phone) && userEnitity.Security != null && !string.IsNullOrEmpty(userEnitity.Security.Answer))
                    retVal.IsFullProfile = true;
                else
                    retVal.IsFullProfile = false;
                return retVal;
            }
        }

        public static Model.Response.UserService.ChangePasswordResponse ToChangePassowrdClientRespone(GSports.Model.Responses.Authentication.ChangePasswordResponse res)
        {
            var retVal = new GSports.Online.Model.Response.UserService.ChangePasswordResponse();
            try
            {
                if (res.IsSuccessfull())
                {
                    retVal.IsPasswordChanged = true;
                }
                else
                {
                    retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.FailedToChangePassword, "Change password Failed!");
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.ConvertorError, "Convertor error");
            }
            return retVal;

        }

        public static GSports.Model.Requests.Authentication.ChangePasswordRequest ConvertToChangePasswordRequest(ChangePasswordRequest request, bool? isReset = false)
        {
            var retVal = new GSports.Model.Requests.Authentication.ChangePasswordRequest();
            retVal.UserToken = request.UserToken;
            retVal.OldPassword = request.OldPassword;
            retVal.NewPassword = request.NewPassword;
            retVal.IsReset = isReset ?? false;
            return retVal;
        }
    }
}
