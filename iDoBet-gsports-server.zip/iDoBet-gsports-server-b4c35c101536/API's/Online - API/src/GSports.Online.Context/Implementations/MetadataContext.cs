﻿using GSports.Online.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Online.Model.Request;
using GSports.Online.Model.Response;
using GSports.Online.Model.Request.MetadataService;
using GSports.Online.Model.Response.MetadataService;
using GSports.Online.Context.Channel;
using GSports.Model.Entities;

namespace GSports.Online.Context.Implementations
{
    public class MetadataContext : IMetadataContext
    {
        public GetCountriesResponse GetCountries(GetCountriesRequest request)
        {
            return new GetCountriesResponse()
            {
                Countries = new List<Model.Entities.Country>()
                {
                    new Model.Entities.Country() { Id = 1, Name = "Israel" },
                    new Model.Entities.Country() { Id = 2, Name = "Uganda" }
                }
            };
        }

        public GetUserCountriesResponse GetUserCountries(GetUserCountriesRequest request)
        {
            GetUserCountriesResponse retVal = new GetUserCountriesResponse();
            retVal = MetadataChannel.GetUserCountries();
            return retVal;
        }
      
        public GetUserCurrenciesResponse GetUserCurrencies(GetUserCurrenciesRequest request)
        {
            GetUserCurrenciesResponse retVal = new GetUserCurrenciesResponse();
            retVal = MetadataChannel.GetUserCurrencies();
            return retVal;
        }

        public GetBetTypesTemplateResponse GetBetTypeTemplate(GetBetTypesTemplateRequest request)
        {
            var retVal = new GetBetTypesTemplateResponse();
             retVal = MetadataChannel.GetBetTypeTemplate(request);

            return retVal;
        }

        public GetSecurityQuestionsResponse GetSecurityQuestions(GetSecurityQuestionsRequest request)
        {
            GetSecurityQuestionsResponse retVal = new GetSecurityQuestionsResponse();
            retVal = MetadataChannel.GetSecurityQuestions();
            return retVal;
        }

      
    }
}
