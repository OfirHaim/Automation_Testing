﻿using GSports.Online.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Online.Model.Request.BetService;
using GSports.Online.Model.Response.BetService;
using GSports.Online.Context.ModelConvertors;
using GSports.Online.Context.Channel;
using System.Threading;
using GSports.GLogger;
using GSports.Online.Model.Response.Base;
using GSports.Model.Responses.Order;
using GSports.Common.RecieptHelper;
using GSports.Online.Model.Entities;
using GSports.Clients.EventsManager;

namespace GSports.Online.Context.Implementations
{
    public class BetContext : IBetContext
    {
        public GetBetHistoryResponse GetBetHistory(GetBetHistoryRequest request)
        {
            var retVal = BetChannel.GetBets(request);
            if (retVal != null)
                retVal.Orders.ForEach(x => x.UrlKey = PrintService.GetOrderKey(request.UserToken, x.RequestGuid, false, 300, template: "OnlineSite"));
            return retVal;
        }

        public GetBetHistoryResponse GetBetOrderData(GetBetHistoryOrderDataRequest request)
        {
            var retVal = new GetBetHistoryResponse();
            retVal = BetChannel.GetBetOrderData(request);
            retVal.Orders.ForEach(x =>
            {
                x.UrlKey = PrintService.GetOrderKey(request.UserToken, x.RequestGuid, false, 300, template: "OnlineSite");
            });
            return retVal;
        }

        public PlaceBetsResponse PlaceBets(PlaceBetsRequest request)
        {
            var retVal = new PlaceBetsResponse();
            try
            {
                var requestOrder = BetConvertor.ConvertOrderRequest(request);
                var serverResponse = BetChannel.RequestForOrder(requestOrder);
                if (serverResponse.IsSuccessfull())
                {
                    retVal.PlacedSuccessfully = true;
                    retVal.Timeout = serverResponse.Timeout;
                    retVal.TimeoutGuid = serverResponse.TimeoutGuid;
                    retVal.Number = serverResponse.Number;
                }
                else
                {
                    retVal.Result = new Model.Response.Base.Result();
                    if (serverResponse.ValidationResult != null && serverResponse.ValidationResult.Count() > 0 && serverResponse.ValidationResult[0].OrderBetValidationResults.Count() > 0)
                    {   
                        var Changes = new List<OrderChange>();
                        foreach (var sel in request.Selections)
                        {

                            var eve = EventSingleton.Instance.GetEventByCk(sel.EventId.ToString());
                            if (eve != null && eve.BetTypes != null)
                            {
                                var betType = eve.BetTypes.FirstOrDefault(bt => bt.BetTypeData.Id == sel.BetTypeId && (bt.BetTypeData.Line ?? "") == (sel.OddLine ?? ""));
                                if (betType != null && betType.Odds != null)
                                {
                                    var odd = betType.Odds.FirstOrDefault(o => o.Name == sel.OddName);

                                    OrderChange change = new OrderChange(eve.EventData.Id, eve.EventData.EventStatus, betType.BetTypeData.Id, betType.BetTypeData.Status, betType.BetTypeData.Line, odd.Name, odd.Price, odd.Status);
                                    Changes.Add(change);
                                }
                            }

                        }
                        var vResult = serverResponse.ValidationResult.FirstOrDefault().OrderBetValidationResults.FirstOrDefault();
                        retVal.SetErrorResult(vResult.ValidationResult,string.Format("Place bet failed, error message = {0}", vResult.Message), Changes);
                    }  
                    else
                        retVal.SetErrorResult(serverResponse.Result.ErrorCode, serverResponse.Result.ErrorDescription);

                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.InternalServerError, "Request for order failed");
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }
        public ExecuteOnlineOrderResponse ExecuteOrder(ExecuteOnlineOrderRequest request)
        {
            var retVal = new ExecuteOnlineOrderResponse();
            try
            {
                var res = BetChannel.ExecuteOrder(new GSports.Model.Requests.Order.ExecuteOrderRequest()
                {
                    TimeoutGuid = request.TimeoutGuid,
                    UserToken = request.UserToken
                });
                if (res.IsSuccessfull() && res.NewOrder.Id > 0)
                    retVal.ExecutedSuccessfully = true;
                else
                { 
                    retVal.Result = new Model.Response.Base.Result();
                    if (res.ValidationResult != null && res.ValidationResult.Count() > 0 && res.ValidationResult[0].OrderBetValidationResults.Count() > 0)
                    {
                        var vResult = res.ValidationResult.FirstOrDefault().OrderBetValidationResults.FirstOrDefault();
                        retVal.SetErrorResult(vResult.ValidationResult, string.Format("Execute bet failed, error message = {0}", vResult.Message), vResult.Event);
                    }
                    else
                    {
                        retVal.SetErrorResult(eErrorCode.InternalServerError, "Execute bet failed");
                    }
                }

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(eErrorCode.InternalServerError, "Request for order failed");
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
         
            }
            return retVal;
        }
    }
}
