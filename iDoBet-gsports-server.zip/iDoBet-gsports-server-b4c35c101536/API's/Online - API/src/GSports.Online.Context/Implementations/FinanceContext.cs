﻿using GSports.Online.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Online.Model.Request.BetService;
using GSports.Online.Model.Response.BetService;
using GSports.Online.Context.ModelConvertors;
using GSports.Online.Context.Channel;
using System.Threading;
using GSports.GLogger;
using GSports.Online.Model.Response.Base;
using GSports.Model.Responses.Order;
using GSports.Common.RecieptHelper;
using GSports.Online.Model.Response.FinanceService;
using GSports.Online.Model.Request.FinanceService;

namespace GSports.Online.Context.Implementations
{
    public class FinanceContext : IFinanceContext
    {
        public GetTransactionResponse GetTransactions(GetTransactionRequest request)
        {
            var retVal = new GetTransactionResponse();
            retVal = FinanceChannel.GetTranscations(request);
            return retVal;
        }

        public DepositResponse Deposit(DepositRequest request)
        {
            var retVal = new DepositResponse();
            if (!FinanceChannel.Deposit(request.UserToken, request.DepositCode))
                retVal.SetErrorResult(eErrorCode.InternalServerError, "Failed deposit");
            return retVal;
        }

        public WithdrawResponse Withdraw(WithdrawRequest request)
        {
            WithdrawResponse retVal = new WithdrawResponse();

            var res = FinanceChannel.Withdraw(request);                      
            if (res.WithdrawData !=null && !string.IsNullOrEmpty(res.WithdrawData.Code))
            {
                retVal.Code = res.WithdrawData.Code;
                SendWithdrawCode(new SendWithdrawCodeRequest() { UserToken = request.UserToken, WithdrawId = res.WithdrawData.Id });                
            }
            return retVal;
        }
        //private bool SendActivationEmail(string email, string url)
        //{
        //    bool retVal = false;

        //    try
        //    {
        //        var title = SystemSettingsBL.GetSystemConfigurationByCode(eConfigurationCode.ActivationCodeEmailTitle);
        //        var body = SystemSettingsBL.GetSystemConfigurationByCode(eConfigurationCode.ActivationCodeEmailBody);
        //        var sendFrom = SystemSettingsBL.GetSystemConfigurationByCode(eConfigurationCode.EmailSendFrom);

        //        using (var factory = new GSportsChannelFactory<INotificationService>(ConfigurationManager.AppSettings[SERVICE_USER_CONF], ConfigurationManager.AppSettings[SERVICE_PASSWORD_CONF], ServiceConsts.NOTIFICATION_SERVICE))
        //        {
        //            var noti = new Notification()
        //            {
        //                SendFrom = sendFrom,
        //                IsHtml = true,
        //                NotificationType = eNotificationAlertType.EMAIL,
        //                Recipients = email,
        //                Message = string.Format(body, url),
        //                Title = title,
        //            };
        //            var service = factory.CreateChannel();
        //            retVal = service.SendNotification(new SendNotificationRequest() { Notification = noti }).IsSuccessfull();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        writeToLog(GSports.GLogger.eLogLevel.Error, string.Empty, ex);
        //    }

        //    return retVal;
        //}
        public CancelWithdrawResponse CancelWithdraw(CancelWithdrawRequest request)
        {
            var retVal = new CancelWithdrawResponse();

            if(!FinanceChannel.CancelWithdraw(request.UserToken, request.TransferId))
                retVal.SetErrorResult(eErrorCode.InternalServerError, "Failed canceling");

            return retVal;
        }

        public GetTransferHistoryResponse GetTransferHistory(GetTransferHistoryRequest request)
        {
            var retVal = new GetTransferHistoryResponse();            
            var res =  FinanceChannel.GetTransfers(FinanceConverter.ConvertToServerRequest(request));
            retVal = FinanceConverter.ConvertToClientResponse(res);
            return retVal;

        }

        public SendWithdrawCodeResponse SendWithdrawCode(SendWithdrawCodeRequest request)
        {
            var  retVal = new SendWithdrawCodeResponse();
            var withdraw = FinanceChannel.GetTransfers(new GSports.Model.Requests.Finance.GetTransfersRequest()
            {
                UserToken = request.UserToken,
                Filter = new GSports.Model.Filter.TransferFilter()
                {
                    TransferId = request.WithdrawId
                }
                 
            });
            if (withdraw != null && withdraw.Transfers.Count ==1)
            {
                var userFilter = new GSports.Model.Filter.UserFilter();
                userFilter.IncludeServices = true;
                userFilter.LoadLastAccess = true;
                userFilter.FilterToken = request.UserToken;
                var user = UserChannel.GetUser(request.UserToken,userFilter);
                if (user != null)
                {
                    NotificationChannel.SendEmail("Withdraw Code", String.Format("Hello {0},<br><br> Your withdrawal code is {1}", string.Format("{0} {1}", user.LastName, user.FirstName), withdraw.Transfers[0].Code), user.Email, true);
                    retVal.IsSent = true;
                }

            }
            return retVal;
        }
    }
}
