﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Online.Model.Request.EventService;
using GSports.Online.Model.Response.EventService;
using GSports.Online.Contracts;
using GSports.Online.Model.Entities;
using GSports.Clients.EventsManager;
using GSports.Clients.EventsManager.Model.Entities;
using GSports.Online.Context.Channel;

namespace GSports.Online.Context.Implementations
{
    public class EventContext : IEventContext
    {
        public GetEventsResponse GetEvents(GetEventsRequest request)
        {
            return EventsChannel.GetEvents(request);
        }
    }
}
