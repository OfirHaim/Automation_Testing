﻿using GSports.Online.Contracts;
using System;
using GSports.Online.Model.Request.UserService;
using GSports.Online.Model.Response.UserService;
using GSports.Online.Context.Channel;
using GSports.Online.Model.Response.Base;
using GSports.Online.Context.ModelConvertors;
using GSports.Model.Consts.Notifications;
using System.IO;
using GSports.Online.Context.Helpers;
using GSports.Model.Entities.User;

namespace GSports.Online.Context.Implementations
{
    public class UserContext : IUserContext
    {
        public GetUserByTokenResponse GetUserByToken(GetUserByTokenRequest request)
        {
            var retVal = new GetUserByTokenResponse();
            var userFilter = new GSports.Model.Filter.UserFilter()
            {
                LoadLastAccess = true,
                LoadMatrix = true
            };
            retVal.UserEntity = retVal.UserEntity = UserConvertor.ConvertUserEntity(UserChannel.GetUser(request.UserToken, userFilter));
            return retVal;
        }

        public ActivateAccountResponse ActivateAccount(ActivateAccountRequest request)
        {
            var retVal = new ActivateAccountResponse();
            if (!UserChannel.ActivateAccount(request.Code))
                retVal.SetErrorResult(eErrorCode.InternalServerError, "Server has failed activating account");
            return retVal;
        }

        public ChangePasswordResponse ChangePassword(ChangePasswordRequest request, bool isReset = false)
        {
            var retVal = new ChangePasswordResponse();
            string passwordErrorDescription = string.Empty;
            eErrorCode errorCode = new eErrorCode();
            if ((request.NewPassword == request.ConfirmedNewPassword) && PasswordValidation.IsPasswordValid(request.NewPassword, ref passwordErrorDescription, ref errorCode))
            {
                var res = UserChannel.ChangePassword(UserConvertor.ConvertToChangePasswordRequest(request, isReset));
                retVal = UserConvertor.ToChangePassowrdClientRespone(res);
            }
            else
            {
                if (passwordErrorDescription == string.Empty)
                    retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.FailedToChangePassword, "Passwords are not match");
                else
                {
                    retVal.SetErrorResult(errorCode, passwordErrorDescription);
                }
            }
            return retVal;
        }

        public ForgotLoginDetailsResponse ForgotLoginDetails(ForgotLoginDetailsRequest request, string _apiToken)
        {
            var retVal = new ForgotLoginDetailsResponse();

            return retVal;

        }

        public GetUserInfoResponse GetUserInfo(GetUserInfoRequest request)
        {
            return new GetUserInfoResponse() { Data = Newtonsoft.Json.JsonConvert.DeserializeObject(UserChannel.GetUserInfo(request.UserToken)) };
        }

        public LoginResponse LoginUser(LoginRequest request)
        {
            var retVal = new LoginResponse();
            var token = UserChannel.LoginUser(request.Username, request.Password, request.IP);
            if (token != null)
                retVal.UserToken = token;
            else
                retVal.SetErrorResult(eErrorCode.WrongCredetials, "Could not login");
            return retVal;
        }

        public LogoutUserResponse LogoutUser(LogoutUserRequest request)
        {
            var retVal = new LogoutUserResponse();
            bool isSuccessful = UserChannel.LogoutUser(request.UserToken);
            if (!isSuccessful)
                retVal.SetErrorResult(eErrorCode.InternalServerError, "Failed logout user.");
            return retVal;
        }

        public RegisterUserResponse RegisterUser(RegisterUserRequest request)
        {
            var retVal = new RegisterUserResponse();
            string passwordErrorDescription = string.Empty;
            eErrorCode errorCode = new eErrorCode();
            if (PasswordValidation.IsPasswordValid(request.Password, ref passwordErrorDescription, ref errorCode))
            {

                var res = UserChannel.RegisterUser(new GSports.Model.Requests.Authentication.RegisterUserRequest()
                {
                    User = new GSports.Model.Entities.User.ClientUser()
                    {
                        Email = request.Email,
                        UserName = request.UserName,
                        Enabled = true,
                    },
                    Password = request.Password
                });

                if (!res.IsSuccessfull())
                {
                    retVal.SetErrorResult(res.Result.ErrorCode, res.Result.ErrorDescription);
                }
            }
            else if (!string.IsNullOrEmpty(passwordErrorDescription))
            {
                retVal.SetErrorResult(errorCode, passwordErrorDescription);
            }
            return retVal;
        }

        public ResendActivationLinkResponse ResendActivationLink(ResendActivationLinkRequest request)
        {
            var retVal = new ResendActivationLinkResponse();

            if (!UserChannel.ResendActivationLink(request.UserId))
                retVal.SetErrorResult(eErrorCode.InternalServerError, "Failed resending link!");
            return retVal;
        }

        public UpdateUserResponse UpdateUserProfile(UpdateUserRequest request)
        {
            var retVal = new UpdateUserResponse();
            var userFilter = new GSports.Model.Filter.UserFilter(request.UserToken);
            var user = UserChannel.GetUser(request.UserToken, userFilter);
            if (user != null)
            {
                if (string.IsNullOrEmpty(user.FirstName))
                {
                    //First time update!
                    if (request.Currency.HasValue)
                    {
                        user.Currency = new GSports.Model.Entities.LocalSystem.Currency();
                        user.Currency.Id =  (int)request.Currency;

                    }
                    else
                    {
                        retVal.SetErrorResult(eErrorCode.UpdateInfoFailed, "Could not update user,Currency");
                    }

                    user.FirstName = !string.IsNullOrEmpty(request.FirstName) ? request.FirstName : null;

                }
                if (string.IsNullOrEmpty(user.LastName))
                    user.LastName = !string.IsNullOrEmpty(request.LastName) ? request.LastName : null;
                if (string.IsNullOrEmpty(user.Phone))
                    user.Phone = !string.IsNullOrEmpty(request.PhoneNumber) ? request.PhoneNumber : string.Empty;
                if (user.Security == null && request.SecurityQuestion != null && !string.IsNullOrEmpty(request.SecurityQuestion.Answer))
                {
                    user.Security = new GSports.Model.Entities.LocalSystem.SecurityQuestion();
                    user.Security.Id = request.SecurityQuestion.QuestionId ?? 0;
                    user.Security.Answer = request.SecurityQuestion.Answer;
                }

                //user.Gender = request.Gender != null ? (GSports.Model.Consts.User.eGender)request.Gender : user.Gender;
                //user.Birthday = request.Birthdate != null ? (DateTime) request.Birthdate : user.Birthday;
                //user.Email = !string.IsNullOrEmpty(request.Email) ? request.Email : user.Email;
                user.Address = !string.IsNullOrEmpty(request.Address) ? request.Address : user.Address;
                user.OddsView = request.OddPriceView != null ? (GSports.Model.Consts.User.eOddsDisplay)request.OddPriceView : user.OddsView;
                //user.Currency = request.Currency != null ? request.Currency : user.Currency;
                



                if (request.CountryId == null)
                    retVal.SetErrorResult(eErrorCode.NoneCountry, "Country must be sent");
                user.Country = new GSports.Model.Entities.LocalSystem.UserCountry();
                user.Country.Id = request.CountryId;
                user.AcceptNewsletter = request.AcceptNewsLetter;

            }
            var res = UserChannel.UpdateUser(user);
            if (!retVal.IsSuccessfull && !res)
                retVal.SetErrorResult(eErrorCode.UpdateInfoFailed, "Could not update user");

            return retVal;
        }

        public KeepAliveResponse KeepAlive(KeepAliveRequest request)
        {
            var retVal = new KeepAliveResponse();
            return retVal;
        }

        private ClientUser GetUserByEmail(string apiToken, string email)
        {

            var userFilter = new GSports.Model.Filter.UserFilter()
            {
                Email = email
            };
            var res = UserChannel.GetUser(apiToken, userFilter);
            return res;

        }

        public GetUserSecurityQuestionResponse GetUserSecurityQuestion(GetUserSecurityQuestionRequest request, string apiToken)
        {
            var retVal = new GetUserSecurityQuestionResponse();
            retVal.CanProceed = false;
            var res = this.GetUserByEmail(apiToken, request.Email);
            if (res != null)
            {
                if (!IsFullProfileUser(res))
                    retVal.CanProceed = true;
                if (res.Security != null)
                {
                    retVal.SecurityQuestion = new Model.Entities.SecurityQuestion();
                    retVal.SecurityQuestion.Question = res.Security.Question;
                    retVal.SecurityQuestion.QuestionId = res.Security.QuestionId;
                    retVal.Result = new Result();
                    retVal.Result.ErrorCode = eErrorCode.Success;
                    retVal.CanProceed = false;
                }
         
            }

            else 
            {
                retVal.SetErrorResult(eErrorCode.EmailNotFound, "User email not found");

            }
            return retVal;
        }

        public ForgotLoginDetailsResponse ForgotUserLoginDetails(ForgotLoginDetailsRequest request, string _apiToken)
        {
            var retVal = new ForgotLoginDetailsResponse();
            var user = GetUserByEmail(_apiToken, request.Email);
            bool res = false;
            if (user != null)
            {
                if (!IsFullProfileUser(user) || user.Security != null && user.Security.Answer.ToLower() == request.SecurityQuestionAnswer.ToLower())
                {
                    res = UserChannel.ForgotUserLoginDetails(new GSports.Model.Requests.UserService.ForgotPasswordRequest() { Email = request.Email });
                    if (!res)
                        retVal.SetErrorResult(eErrorCode.GerneralApi, "Reset failed");
                    else
                        retVal.CanProceed = true;
                }

                else
                {
                    retVal.SetErrorResult(eErrorCode.NotMatchSecurityAnswer, "Wrong credentials");
                    retVal.CanProceed = false;
                }

            }
            else
            {
                retVal.SetErrorResult(eErrorCode.EmailNotFound, "Wrong credentials");
                retVal.CanProceed = false;
            }
            return retVal;

        }

        public ResetPasswordResponse ResetPassword(ResetPasswordRequest request)
        {
            var retVal = new ResetPasswordResponse();
            retVal.ResetPasswordSucceed = null;
            bool IsGuidValid = false;
            bool? res = null;
            if (string.IsNullOrEmpty(request.Password))
                retVal.IsValid = UserChannel.ForgotUserLoginDetails(new GSports.Model.Requests.UserService.ForgotPasswordRequest() { PasswordToken = request.Guid });
            else
            {
                string passwordErrorDescription = string.Empty;
                eErrorCode errorCode = new eErrorCode();
                if (request.Password == request.ConfirmPassword && PasswordValidation.IsPasswordValid(request.Password, ref passwordErrorDescription, ref errorCode))
                {
                    res = UserChannel.ForgotUserLoginDetails(new GSports.Model.Requests.UserService.ForgotPasswordRequest() { PasswordToken = request.Guid, NewPassword = request.Password });

                }
                else if (passwordErrorDescription == string.Empty)
                    retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.FailedToChangePassword, "Passwords are not match");
                else
                    retVal.SetErrorResult(errorCode, passwordErrorDescription);

            }
            if ((res == false || res == null)  && !retVal.IsValid)
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.FailedToChangePassword, "Change password failed");
            else
            {
                retVal.IsValid = true;
                retVal.ResetPasswordSucceed = res;
            }
            return retVal;

        }

        private bool IsFullProfileUser(ClientUser user)
        {
            bool retVal = false;
            if (!string.IsNullOrEmpty(user.FirstName) && !string.IsNullOrEmpty(user.LastName) && !string.IsNullOrEmpty(user.Email)
                 && !string.IsNullOrEmpty(user.Phone) && user.Security != null && !string.IsNullOrEmpty(user.Security.Answer))
                retVal = true;
            else
                retVal = false;

            return retVal;
        }
    }
}
