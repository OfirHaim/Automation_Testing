﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading;
//using GSports.GLogger;
//using GSports.Common;
//using GSports.Model.Entities.Event;
//using GSports.Online.Model.Entities;
//using GSports.Online.Model.Response.EventService;
//using GSports.Online.Context.Helpers;
//using GSports.Online.Context.Implementations;
//using System.Threading.Tasks;
//using GSports.PushService.Client;

//namespace GSports.Online.Context.Hubs
//{
//    public sealed class EventSingleton
//    {
//        private const string EVENT_CHANNEL = "EVENT";
//        public Dictionary<DateTime, List<Event>> updateLog = new Dictionary<DateTime, List<Event>>();

//        private List<Event> _data { get; set; }
//        private DateTime _lastUpdate { get; set; }

//        private Timer _timer;

//        private object _lockObject = new object();
//        private static object _syncRoot = new object();

//        private static volatile EventSingleton _instance;

//        private EventSingleton()
//        {
//            Task.Run(() => Channel.EventsChannel.GetEvents()).ContinueWith((res) =>
//            {
//                var events = CompressedBinaryConverter.ToObject<List<SportGame>, SportGame>(res.Result.EventData);
//                _lastUpdate = res.Result.ServerLastUpdate;
//                _data = EventConverter.convertEvents(events);
//                _timer = new Timer(checkForChanges, null, 1000, 1000);
//            });
//        }

//        public static EventSingleton Instance
//        {
//            get
//            {
//                if (_instance != null)
//                    return _instance;
//                else
//                    throw new Exception("Instance should be instanced through the InitEventSingelton method");
//            }
//        }

//        public static EventSingleton InitEventSingelton(string pushServerUrl, string token)
//        {
//            if (_instance == null)
//            {
//                lock (_syncRoot)
//                {
//                    if (_instance == null)
//                    {
//                        _instance = new EventSingleton();
//                        PushClient.Instance.Connect(pushServerUrl, token);
//                    }
//                }
//            }
//            return _instance;
//        }

//        public GetEventsResponse GetEvents() => new GetEventsResponse()
//        {
//            Events = _data.Where(x => x.ForClient).ToList(),
//            LastUpdateTime = DateTime.UtcNow
//        };

//        public GetEventByCkResponse GetEventByCk(string ck) => new GetEventByCkResponse()
//        {
//            Event = _data.FirstOrDefault(x => x.CompareKey == ck)
//        };

//        private void checkForChanges(object state)
//        {
//            if (Monitor.TryEnter(_lockObject))
//            {
//                bool toDelete, toAdd;
//                var toDeleteList = new List<string>();
//                var toAddList = new List<string>();

//                try
//                {
//                    var response = Channel.EventsChannel.GetEvents(_lastUpdate);

//                    if (response != null && response.IsSuccessfull())
//                    {
//                        _lastUpdate = response.ServerLastUpdate;
//                        var changedEvents = CompressedBinaryConverter.ToObject<List<SportGame>, SportGame>(response.EventData);
//                        var convertedEvents = EventConverter.convertEvents(changedEvents);
//                        updateLog.Add(_lastUpdate, convertedEvents.ToList());
//                        var formattedEvents = new List<Dictionary<string, object>>();
//                        convertedEvents.ForEach(x =>
//                        {
//                            var updatedObj = mergeChangesIntoEvent(x, out toDelete, out toAdd);
//                            if (x.ForClient && updatedObj.IsNotNullAndAny() && !toDelete && !toAdd)
//                                formattedEvents.Add(updatedObj);
//                            else if (toDelete)
//                                toDeleteList.Add(x.CompareKey);
//                            else if (toAdd)
//                                toAddList.Add(x.CompareKey);
//                        });
//                        if (formattedEvents.Any())
//                            updateEvents(JsonConvert.SerializeObject(formattedEvents));

//                        deleteEvents(toDeleteList);
//                        insertNewEvents(_data.Where(x => toAddList.Contains(x.CompareKey)).ToList());
//                    }
//                    else
//                        Logger.WriteLog(eLogLevel.Error, "TODO");
//                }
//                catch (Exception ex)
//                {
//                    Logger.WriteLog(ex);
//                }
//                finally
//                {
//                    Monitor.Exit(_lockObject);
//                }
//            }
//        }

//        private Dictionary<string, object> mergeChangesIntoEvent(Event newUpdateEve, out bool toDelete, out bool toAdd)
//        {
//            Dictionary<string, object> retVal = null;
//            toDelete = toAdd = false;

//            var currentEvent = _data.FirstOrDefault(x => x.CompareKey == newUpdateEve.CompareKey);
//            var index = _data.IndexOf(currentEvent);
//            if (currentEvent != null)
//            {
//                var diff = DiffComparer.GetDiff(newUpdateEve, currentEvent);
//                if (diff.Count > 1)
//                    retVal = diff;
//                newUpdateEve.BetTypes.ForEach(bt =>
//                {
//                    var existsBetType = currentEvent.BetTypes.FirstOrDefault(x => x.CompareKey == bt.CompareKey);
//                    if (existsBetType != null)
//                        bt.Odds.AddRange(existsBetType.Odds.Where(x => !bt.Odds.Any(a => a.CompareKey == x.CompareKey)));
//                });
//                newUpdateEve.BetTypes.AddRange(currentEvent.BetTypes.Where(x => !newUpdateEve.BetTypes.Any(a => a.CompareKey == x.CompareKey)));

//                toDelete = _data[index].ForClient && !newUpdateEve.ForClient;
//                toAdd = !_data[index].ForClient && newUpdateEve.ForClient;

//                _data[index] = newUpdateEve;
//            }
//            return retVal;
//        }

//        private void updateEvents(string updates)
//        {
//            try
//            {
//                PushClient.Instance.PushMessageToChannel(EVENT_CHANNEL, new PushMessage("updateEvents", updates));
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(ex);
//            }
//        }

//        private void deleteEvents(List<string> toDeleteList)
//        {
//            try
//            {
//                if (toDeleteList.Any())
//                    PushClient.Instance.PushMessageToChannel(EVENT_CHANNEL, new PushMessage("deleteEvents", JsonConvert.SerializeObject(toDeleteList)));
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(ex);
//            }
//        }

//        private void insertNewEvents(List<Event> events)
//        {
//            try
//            {
//                if (events.Any())
//                    PushClient.Instance.PushMessageToChannel(EVENT_CHANNEL, new PushMessage("insertNewEvents", JsonConvert.SerializeObject(events)));
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(ex);
//            }
//        }

//    }
//}
