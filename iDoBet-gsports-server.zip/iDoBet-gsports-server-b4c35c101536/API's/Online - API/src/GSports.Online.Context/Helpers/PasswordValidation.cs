﻿using GSports.Online.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Context.Helpers
{

    public class PasswordValidation
    {
        private const int kMinimumLength = 8;
        private static string _specialChars = "@#_$%^";
        private static bool IsSpecialChar(char c) { return _specialChars.IndexOf(c) >= 0; }
        private static bool IsValidPasswordChar(char c) { return IsSpecialChar(c) || Char.IsLetterOrDigit(c); }
        private static bool IsSequenceChar(string s)
        {
            int counter = 0,
                i = 0;
            while (i != s.Length - 1 && counter < 2)
            {
                if ((char)s[i] + 1 == (char)s[i + 1] || (char)s[i] - 1 == (char)s[i + 1] || (char)s[i] == (char)s[i + 1])
                {
                    counter++;
                }
                else
                    counter = 0;
                i++;
            }
            return counter >= 2 ? false : true;
        }


        private static List<Rule> rules = new List<Rule>() {
            new Rule(){ Predicate = (s => s != null),
              Description = "Password must not be null",ErrorCode = eErrorCode.PasswordCantBeNull },
            new Rule(){ Predicate = (s => s.Length >= kMinimumLength ),
              Description = "Password must have at least " + kMinimumLength + " characters.", ErrorCode = eErrorCode.PasswordMinPasswordLength},
            //new Rule(){ Predicate = (s => s.Count(c => IsSpecialChar(c)) >= 1),
            //  Description = "Password must contain at least one of " + _specialChars , ErrorCode = eErrorCode.PasswordMustContainsSpecialChar},
            //new Rule(){ Predicate = (s => !IsSpecialChar(s[0]) && !IsSpecialChar(s[s.Length - 1])),
            //  Description = "Password must not start or end with " + _specialChars,ErrorCode = eErrorCode.PasswordCantStartSpecialChar },
            new Rule(){ Predicate = (s => s.Count(c => Char.IsLetter(c)) > 0),
              Description = "Password must contain at least one letter.", ErrorCode = eErrorCode.PasswordAtLeastOneLetter },
            new Rule(){ Predicate = (s => s.Count(c => Char.IsDigit(c)) > 0),
              Description = "Password must contain at least one digit." ,ErrorCode = eErrorCode.PasswordAtLeatOneDigit},
            //new Rule(){ Predicate = (s =>s.Count(c => !IsValidPasswordChar(c)) == 0),
            //  Description = "Password must contain letters, digits, or one of " + _specialChars ,ErrorCode = eErrorCode.PasswordCombination },
             //new Rule(){ Predicate = (s => IsSequenceChar(s)),
             // Description = "Password cannot contain sequences of characters",ErrorCode = eErrorCode.PasswordSequence },
        };

        public static bool IsPasswordValid(string s, ref string failureReason, ref eErrorCode errorCode)
        {
            foreach (Rule r in rules)
            {
                if (!r.Predicate(s))
                {
                    failureReason = r.Description;
                    errorCode = r.ErrorCode;
                    return false;
                }
            }
            return true;
        }
    }
    public class Rule
    {
        public Func<string, bool> Predicate { get; set; }
        public string Description { get; set; }
        public eErrorCode ErrorCode { get; set; }
    }


}
