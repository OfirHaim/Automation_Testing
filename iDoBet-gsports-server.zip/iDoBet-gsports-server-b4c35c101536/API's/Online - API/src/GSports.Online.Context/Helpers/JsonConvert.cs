﻿//using Newtonsoft.Json;
//using Newtonsoft.Json.Serialization;

//public class JsonConvert
//{
//    public static string SerializeObject(object value)
//    {
//        return Newtonsoft.Json.JsonConvert.SerializeObject(value, new JsonSerializerSettings()
//        {
//            ContractResolver = new CamelCasePropertyNamesContractResolver()
//        });
//    }

//    public static T DeserializeObject<T>(string value)
//    {
//        return Newtonsoft.Json.JsonConvert.DeserializeObject<T>(value);
//    }
//}
