﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Entities
{
    public class SecurityQuestion
    {
        public SecurityQuestion() { }
        public SecurityQuestion(int id, string question, string answer)
        {
            QuestionId = id;
            Question = question;
            Answer = answer;
        }

        public int? QuestionId { get; set; }

        public string Question { get; set; }
        public string Answer { get; set; }
    }
}
