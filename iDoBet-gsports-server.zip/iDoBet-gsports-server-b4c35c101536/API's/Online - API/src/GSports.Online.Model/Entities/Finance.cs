﻿using GSports.Online.Model.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Entities
{
    public class TransactionsEntity
    {

        public DateTime CreateTime { get; set; }
        public double CurrentBalance { get; set; }
        public double Amount { get; set; }
        public TransactionReason TransactionReason { get; set; }
        public TransactionType TranscationType { get; set; }
        public string Comments { get; set; }
        public long? AddressedObjectId { get; set; }
        public string ObjectType { get; set; }


    }

    public class TransactionReason 
    {
        public string CodeAttribute { get; set; }
        public string Name { get; set; }
    }
    public class TransactionType 
    {
        public string CodeAttribute { get; set; }
    }
}

