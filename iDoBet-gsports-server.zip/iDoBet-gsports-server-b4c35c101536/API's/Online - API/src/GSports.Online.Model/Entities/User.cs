﻿using System;
using GSports.Online.Model.Enums;
    

namespace GSports.Online.Model.Entities
{
    public class UserEntity
    {
        #region UserIdentification

        public int UserId { get; set; }

        public bool IsActivated { get; set; }

        public string Token { get; set; }

        #endregion

        #region UserInfo

        public long? AccountId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string UserName { get; set; }

        public string Email { get; set; }

        public Country Country { get; set; }

        public eGender Gender { get; set; }
        
        public string Language { get; set; }

        public DateTime Birthday { get; set; }

        public int? GMTOffset { get; set; }

        public eOddsDisplay OddsView { get; set; }
        public bool IsFullProfile { get; set; }


        #endregion

        #region Account Finance
        public Currency Currency { get; set; }

        public double? Balance { get; set; }

        public double? Holding { get; set; }

        #endregion

        #region ContactData

        public string Address { get; set; }

        public string Phone { get; set; }

        public bool AcceptNewsletter { get; set; }

        #endregion
        #region limit 

        public int? MinBet { get; set; }
        public int? MaxBet { get; set; }

        #endregion
    }

}
