﻿using GSports.Clients.EventsManager.Model.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Entities
{
    public class OrderChange
    {
        public OrderChange(long eventId, eEventStatus eventStatus, long betTypeId, eBetStatus betTypeStatus, string betTypeLine, string oddName, decimal? oddPrice, eOddStatus oddStatus)
        {
            EventId = eventId;
            EventStatus = eventStatus;
            BetTypeId = betTypeId;
            BetTypeStatus = betTypeStatus;
            OddName = oddName;
            BetTypeLine = betTypeLine;
            OddPrice = oddPrice;
            OddStatus = oddStatus;
        }

        public long EventId { get; set; }
        public eEventStatus EventStatus { get; set; }

        public long BetTypeId { get; set; }

        public eBetStatus BetTypeStatus { get; set; }

        public string OddName { get; set; }

        public string BetTypeLine { get; set; }

        public decimal? OddPrice { get; set; }

        public eOddStatus OddStatus { get; set; }

    }

}
