﻿
using Newtonsoft.Json;

namespace GSports.Online.Model.Entities
{

    public class Country
    {
        public Country() { }
        public Country(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public int Id { get; set; }

        public string DisplayName
        {
            get
            {
                return string.IsNullOrEmpty(this.ShortName) ? this.Name : this.ShortName;
            }
        }
        [JsonIgnore]
        public string Name { get; set; }
        [JsonIgnore]
        public string ShortName { get; set; }
    }
}
