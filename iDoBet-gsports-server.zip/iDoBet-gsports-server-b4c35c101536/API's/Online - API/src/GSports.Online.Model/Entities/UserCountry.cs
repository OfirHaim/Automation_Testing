﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Entities
{
    public class UserCountry
    {
        public UserCountry(int id, string name,short? phoneCode)
        {
            this.Id = id;
            this.Name = name;
            this.PhoneCode = phoneCode;
        }
        public string Name { get; set; }
        public int Id { get; set; }
        public short? PhoneCode { get; set; }

    }
}
