﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Entities
{
    public class TreeNode
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Count {
             get { return this.Children ==null ? 0: this.Children.Count; } 
        }
        public List<TreeNode> Children { get; private set; }

        public TreeNode(string id, string name)
            : this(id, name, new TreeNode[0])
        { }

        public TreeNode(string node, string name, params TreeNode[] children)
        {
            Id = node;
            Name = name;
            Children = new List<TreeNode>(children);
        }
    }
}
