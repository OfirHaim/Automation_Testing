﻿using GSports.Online.Model.Consts;
using GSports.Online.Model.Enums;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace GSports.Online.Model.Entities
{

    #region BetTypeTemplate

    public class BetTypeTemplate
{
    public BetTypeTemplate() { }

    public BetTypeTemplate(long id, string displayName, bool isLive, long sportTypeId, bool forDisplay, bool isFilter)
    {
        Id = id;
        DisplayName = displayName;
        IsLive = isLive;
        SportTypeId = sportTypeId;
        ForDisplay = forDisplay;
        IsFilter = isFilter;
    }

    public long Id { get; set; }

    public long SportTypeId { get; set; }

    public bool ForDisplay { get; set; }

    public bool IsLineDisplay { get; set; }

    public string DisplayLine { get; set; }    
        

    public bool IsFilter { get; set; }

    [JsonProperty(PropertyName = PropertyNames.NAME)]
    public string DisplayName { get; set; }

    public bool IsLive { get; set; }

    public List<List<OddTemplate>> Odds { get; set; }

}

public class OddTemplate
{
    public OddTemplate() { }

    public OddTemplate(string name)
    {
        DisplayName = name;
    }

    [JsonProperty(PropertyName = PropertyNames.NAME)]
    public string DisplayName { get; set; }
}

#endregion
}
