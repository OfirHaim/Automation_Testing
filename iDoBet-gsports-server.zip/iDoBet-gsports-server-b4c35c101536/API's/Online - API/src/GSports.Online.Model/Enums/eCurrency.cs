﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Enums
{
    public enum eCurrency
    {
        USD = 1,
        UGX = 2,
        CDF = 3, 
        EUR = 4,
        TZS = 5,

    }
}
