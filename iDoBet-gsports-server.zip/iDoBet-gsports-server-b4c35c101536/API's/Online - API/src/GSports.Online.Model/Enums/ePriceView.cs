﻿
namespace GSports.Online.Model.Enums
{
    public enum eOddsDisplay
    {
        Decimal = 0,
        American = 1,
        Fractional = 2
    }
}
