﻿
namespace GSports.Online.Model.Enums
{

    
    public enum eLogoutType
    {
        
        Unknown = 0,
        
        Logout = 1,
        
        Relogin = 2,
        
        System = 3,
        
        ForcedLogout = 4
    }

}
