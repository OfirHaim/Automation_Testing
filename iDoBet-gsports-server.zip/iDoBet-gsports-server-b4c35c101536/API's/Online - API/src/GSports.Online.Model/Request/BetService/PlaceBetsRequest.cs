﻿using GSports.Online.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.BetService
{
    public class PlaceBetsRequest : BaseRequest
    {
        public List<Selection> Selections { get; set; }

        public List<RequestOrderRow> Rows { get; set; }
        public bool? IsBooking { get; set; }
    }
}
