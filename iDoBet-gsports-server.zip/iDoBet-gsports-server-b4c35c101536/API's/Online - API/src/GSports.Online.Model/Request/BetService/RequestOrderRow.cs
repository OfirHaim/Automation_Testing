﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.BetService
{
    public class RequestOrderRow
    {
        public double Amount { get; set; }
        
        public List<string> SelectionKeys { get; set; }
    }
}
