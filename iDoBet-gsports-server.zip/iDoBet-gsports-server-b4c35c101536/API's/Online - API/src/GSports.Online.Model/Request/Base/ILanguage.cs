﻿
namespace GSports.Online.Model.Request
{
    public interface ILanguage
    {
        string Language { get; set; }
    }
}
