﻿
using GSports.Online.Model.Helpers;
using System;

namespace GSports.Online.Model.Request
{ 
    public class BaseRequest 
    {
        public string UserToken { get; set; }
    }
}
