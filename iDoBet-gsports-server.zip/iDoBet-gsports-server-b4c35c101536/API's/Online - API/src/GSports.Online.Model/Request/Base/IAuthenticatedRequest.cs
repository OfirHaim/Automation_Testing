﻿
namespace GSports.Online.Model.Request
{


    public interface IAuthenticatedRequest
    {

        string Token { get; set; }

    }

}
