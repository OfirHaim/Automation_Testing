﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.FinanceService
{
    public class GetTransferHistoryRequest : BaseRequest
    {
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public bool? OpenOnly { get; set; }
        public long? ShiftId { get; set; }
        public long? TransferId { get; set; }
        public int? UserId { get; set; }
        public  string TransferTypeCode { get; set; }
    }

 
}
