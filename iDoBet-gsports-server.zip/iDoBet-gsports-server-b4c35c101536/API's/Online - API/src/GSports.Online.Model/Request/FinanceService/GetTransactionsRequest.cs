﻿using GSports.Online.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.FinanceService
{
    public class GetTransactionRequest: BaseRequest
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string TransactionTypeCode { get; set; }
        public string TransactionReasonCode { get; set; }
    }
}
