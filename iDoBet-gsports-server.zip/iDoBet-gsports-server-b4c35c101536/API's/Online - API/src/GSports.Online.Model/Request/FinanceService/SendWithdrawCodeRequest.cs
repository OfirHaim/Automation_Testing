﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.FinanceService
{
    public class SendWithdrawCodeRequest: BaseRequest 
    {
        public long WithdrawId { get; set; }
    }
}
