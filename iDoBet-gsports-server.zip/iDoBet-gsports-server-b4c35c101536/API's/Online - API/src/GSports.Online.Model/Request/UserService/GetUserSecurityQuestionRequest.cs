﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.UserService
{
    public class GetUserSecurityQuestionRequest : BaseRequest
    {
       public string Email { get; set; }
    }
}
