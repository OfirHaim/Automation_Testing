﻿using GSports.Online.Model.Entities;
using GSports.Online.Model.Enums;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.UserService
{
    public class RegisterUserRequest : BaseRequest
    {
        #region UserInfo
        public string Email { get; set; }
        public string UserName { get; set;}
        public string Password { get; set; }

        #endregion
    }
}
