﻿
using GSports.Online.Model.Helpers;

namespace GSports.Online.Model.Request.UserService
{
    public class LoginRequest : BaseRequest
    {
        [TsRequired]
        public string Username { get; set; }
        [TsRequired]
        public string Password { get; set; }

        public string IP { get; set; }

    }
}
