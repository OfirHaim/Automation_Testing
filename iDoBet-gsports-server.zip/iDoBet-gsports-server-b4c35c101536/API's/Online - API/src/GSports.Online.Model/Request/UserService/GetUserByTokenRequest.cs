﻿namespace GSports.Online.Model.Request.UserService
{
    public class GetUserByTokenRequest : BaseRequest
    {
    }
}
