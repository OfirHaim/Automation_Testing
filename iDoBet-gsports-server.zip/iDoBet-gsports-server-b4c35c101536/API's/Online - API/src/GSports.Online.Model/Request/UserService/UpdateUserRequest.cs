﻿using GSports.Online.Model.Entities;
using GSports.Online.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.UserService
{
    public class UpdateUserRequest : BaseRequest
    {
        public string Email { get; set; }
        public eGender? Gender { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime? Birthdate { get; set; }
        public eCurrency? Currency { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; }
        public eOddsDisplay? OddPriceView { get; set; }
        public int CountryId { get; set; }
        public bool AcceptNewsLetter { get; set; }
        public SecurityQuestion SecurityQuestion { get; set; }
    }
}
