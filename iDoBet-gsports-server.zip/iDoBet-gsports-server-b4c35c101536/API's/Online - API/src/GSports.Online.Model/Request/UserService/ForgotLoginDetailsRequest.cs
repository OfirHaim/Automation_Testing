﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.UserService
{
    public class ForgotLoginDetailsRequest : BaseRequest
    {
        public string Email { get; set; }
        public string SecurityQuestionAnswer { get; set; }
             
    }
}

