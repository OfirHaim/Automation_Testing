﻿using System;
using System.Collections.Generic;

namespace GSports.Online.Model.Request.EventService
{
    public class GetEventsRequest : BaseRequest, ILanguage
    {
        public string Language { get; set; }
        public List<long> EventIds { get; set; }
        public List<long> BetTypeIds { get; set; }
        public int? Skip { get; set; }
        public int? Take { get; set; }
    }
}
