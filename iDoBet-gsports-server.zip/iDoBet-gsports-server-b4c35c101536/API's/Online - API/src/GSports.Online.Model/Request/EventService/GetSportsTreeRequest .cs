﻿using System;
using System.Collections.Generic;

namespace GSports.Online.Model.Request.EventService
{
    public class GetSportsTreeRequest : BaseRequest, ILanguage
    {
        public string Language { get; set; }

     
    }
}
