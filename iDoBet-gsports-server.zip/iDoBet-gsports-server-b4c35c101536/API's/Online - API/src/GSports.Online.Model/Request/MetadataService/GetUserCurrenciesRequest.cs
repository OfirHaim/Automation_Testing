﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Request.MetadataService
{
    public class GetUserCurrenciesRequest:BaseRequest
    {
    }
}
