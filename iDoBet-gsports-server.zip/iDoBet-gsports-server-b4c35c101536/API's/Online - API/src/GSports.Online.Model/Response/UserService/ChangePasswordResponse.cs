﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Response.UserService
{
    public class ChangePasswordResponse : BaseResponse
    {
        public bool IsPasswordChanged { get; set; }
        public override bool IsResponseDataValid()
        {
            return IsPasswordChanged;
        }
    }
}
