﻿using GSports.Online.Model.Entities;
using System.Runtime.Serialization;
using System;

namespace GSports.Online.Model.Response.UserService
{   
    public class LoginResponse : BaseResponse
    {
        public string UserToken { get; set; }

        public override bool IsResponseDataValid()
        {
            return !string.IsNullOrEmpty(UserToken);
        }
    }
}
