﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Response.UserService
{
    public class GetUserInfoResponse : BaseResponse
    {
        public object Data { get; set; }

        public override bool IsResponseDataValid()
        {
            return Data != null;
        }
    }
}
