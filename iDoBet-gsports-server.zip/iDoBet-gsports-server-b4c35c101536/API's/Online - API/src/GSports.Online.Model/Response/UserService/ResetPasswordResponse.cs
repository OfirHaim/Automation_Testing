﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Response.UserService
{
    public class ResetPasswordResponse : BaseResponse
    {
        public bool IsValid { get; set; }
        public bool? ResetPasswordSucceed { get; set; }
        public override bool IsResponseDataValid()
        {
            return IsValid && (ResetPasswordSucceed ?? true);
        }
    }
}
