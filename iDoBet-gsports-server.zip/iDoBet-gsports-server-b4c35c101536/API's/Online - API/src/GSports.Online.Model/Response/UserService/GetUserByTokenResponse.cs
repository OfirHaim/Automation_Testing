﻿using GSports.Online.Model.Entities;

namespace GSports.Online.Model.Response.UserService
{
    public class GetUserByTokenResponse : BaseResponse
    {
        public UserEntity UserEntity { get; set; }

        public override bool IsResponseDataValid()
        {
            return UserEntity != null;
        }
    }
}
