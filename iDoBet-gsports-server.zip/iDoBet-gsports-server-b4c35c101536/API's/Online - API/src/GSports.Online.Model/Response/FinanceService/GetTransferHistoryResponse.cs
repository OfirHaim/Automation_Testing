﻿using GSports.Online.Model.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Response.FinanceService
{
    public class GetTransferHistoryResponse: BaseResponse
    {
        public List<TransferHistory> Transfers {get;set;}
        public override bool IsResponseDataValid()
        {
            return Transfers != null;
        }
    }

    public class TransferHistory
    {
        public DateTime Date { get; set; }
        public TransferType TransactionType { get; set; }
        public TransferReason ResponseType { get; set; }
        public double Amount { get; set; }
        public string Comments { get; set; }
        public long Id { get; set; }
    }


    public class TransferReason
    {
        public string CodeAttribute { get; set; }
        public string Name { get; set; }
    }

    public class TransferType
    {
        public string CodeAttribute { get; set; }
        public string Name { get; set; }
    }

}

