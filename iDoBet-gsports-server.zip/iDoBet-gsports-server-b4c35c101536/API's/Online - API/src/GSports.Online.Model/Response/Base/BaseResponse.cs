﻿using GSports.Online.Model.Response.Base;
using System.Runtime.Serialization;

namespace GSports.Online.Model.Response
{
    public abstract class BaseResponse
    {
        public BaseResponse() { }

        private Result mResult;

        public Result Result
        {
            get { return mResult; }
            set { mResult = value; }
        }

        public abstract bool IsResponseDataValid();

        public void SetErrorResult(GSports.Model.Consts.eErrorCode errorCode, string errorDescription, object additionalInfo = null)
        {
            if (mResult == null) mResult = new Result();

            try
            {
                mResult.ErrorCode = (eErrorCode)(int)errorCode;
            }
            catch
            {
                mResult.ErrorCode = eErrorCode.ApiError;
            }
            mResult.ErrorDescription = errorDescription;
            mResult.ResultCode = eResultCode.Failure;
            mResult.AdditionalInfo = additionalInfo;
            }

        public void SetErrorResult(eErrorCode errorCode = eErrorCode.ApiError, string errorDescription = null, object additionalInfo = null)
        {
            if (mResult == null) mResult = new Result();
            mResult.ErrorCode = errorCode;
            mResult.ErrorDescription = errorDescription;
            mResult.ResultCode = eResultCode.Failure;
            mResult.AdditionalInfo = additionalInfo;
        }

      

        public bool IsSuccessfull
        {
            get
            {
                if ((Result == null ||Result.ResultCode == eResultCode.Success) && !IsResponseDataValid())
                {
                    if (Result == null)   
                        Result = new Result();
                    Result.ErrorCode = eErrorCode.EmptyResultData;
                    return false;
                }
                return Result == null || Result.ResultCode == eResultCode.Success;
            }
        }

        public object UserInfo { get; set; }

    }
}
