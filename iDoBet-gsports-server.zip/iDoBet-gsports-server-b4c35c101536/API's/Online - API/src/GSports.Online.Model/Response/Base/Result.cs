﻿
namespace GSports.Online.Model.Response.Base
{
    public class Result
    {        
        public string ErrorDescription { get; set; }
        public object AdditionalInfo { get; set; }      
        public eErrorCode ErrorCode { get; set; }        
        public eResultCode ResultCode { get; set; }       
        public string ErrorCodeDescription { get; set; }       
    }

}
