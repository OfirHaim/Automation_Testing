﻿
namespace GSports.Online.Model.Response.Base
{

    
    
    public enum eResultCode
    {
        
        Success = 0,
        
        Failure = 1,
    }

}
