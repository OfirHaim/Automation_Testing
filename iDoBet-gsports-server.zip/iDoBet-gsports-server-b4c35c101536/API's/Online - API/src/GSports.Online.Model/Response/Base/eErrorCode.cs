﻿
namespace GSports.Online.Model.Response.Base
{
    
    
    public enum eErrorCode
    {
        
        Success = 0,

        #region General Error
        
        DatabaseError = 1,
        
        InternalServerError = 2,
        
        BadRequest = 3,
        
        BadOdds = 4,
        
        EventColosedForBetting = 5,
        
        EventEnded = 6,
        
        EventDosntExsist = 7,
        
        NoPermission = 8,
        
        DuplicateData = 9,

        EmptyResultData = 10,

        #endregion

        #region Register + Login Error (100)

        // THIS VALUES ARE USED IN DB, DO NOT CHANGE

        UserTokenInvalid = 100,
        
        TerminalTokenInvalid = 101,
        
        TerminalTokenAlreadyInUse = 102,
        
        WrongCredetials = 103,
        
        NoOpenShiftForTerminalUser = 104,
        
        LogoutFailed = 105,
     
        UserHasBeenLocked = 106,
        //Register
        UserNameAlreadyExists = 120,
        
        EmailAlreadyExists = 121,
        EmailNotFound = 122,
        //User 
        NotMatchSecurityAnswer = 130,
        #endregion

        #region order error (200)


        OrderValidationError = 200,

        
        OrderNotFound = 201,

        
        OrderCanotPayout = 202,


        //Event 
       
        EventDataNotFound = 240,

        OddsPriceChanged = 241,

        //Limitation
      
        LimitationFailed,
        //User 
      
        MinBetLimit = 250,

      
        MaxBetLimit = 251,

      
        OverCrditLimit = 252,

      
        EventStatusDisabled = 253,

      
        BetTypeStatusDisabled = 254,

      
        OddStatusDisabled = 255,

      
        ExecuteTimeIncorrect = 260,

        #endregion

        #region Terminal Error (300)

        TerminalNotFound = 300,
        
        TerminalAlreadyRegister = 301,
        
        TerminalIsNotActive = 302,
        #endregion

        #region Finance error(400)

        
        NotEnoughMoney = 400,
     
        InsertWithdrawFailed = 410,
       
        CommitWithdrawFailed = 411,

        #endregion


        #region Online (500)
        
        AlreadyActivated = 500,
        UpdateInfoFailed = 501,
        NoneCountry = 502,
        #endregion

        #region API ERRORS
        EventsNotReady = 1000,
        ApiError = 1001,
        GerneralApi = 1000,
        PasswordCantBeNull = 1010,
        PasswordMinPasswordLength = 1011,
        PasswordMustContainsSpecialChar = 1012,
        PasswordCantStartSpecialChar = 1013,
        PasswordAtLeatOneDigit = 1014,
        PasswordAtLeastOneLetter = 1015,
        PasswordCombination = 1016,
        PasswordSequence = 1017
        #endregion



    }
}
