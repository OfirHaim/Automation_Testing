﻿using GSports.Online.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Response.MetadataService
{
    public class GetUserCurrenciesResponse : BaseResponse
    {
        public List<Currency> Currencies { get; set; }
        public override bool IsResponseDataValid()
        {
          return  Currencies != null;
        }
    }
}
