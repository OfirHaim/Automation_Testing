﻿using GSports.Online.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.Response.BetService
{
   public class GetBetHistoryResponse: BaseResponse
    {
        public List<Order> Orders { get; set; }
        public override bool IsResponseDataValid()
        {
            return Orders != null;
        }
    }
}
