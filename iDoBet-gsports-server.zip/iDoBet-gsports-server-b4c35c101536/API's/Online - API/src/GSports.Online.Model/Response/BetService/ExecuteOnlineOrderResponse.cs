﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.Online.Model.Response.BetService
{
    public class ExecuteOnlineOrderResponse : BaseResponse
    {
        public bool ExecutedSuccessfully { get; set; }



        public override bool IsResponseDataValid()
        {
            return ExecutedSuccessfully;
        }
    }
}
