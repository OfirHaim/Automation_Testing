﻿using GSports.Clients.EventsManager.Model.Entities;
using GSports.Online.Model.Entities;
using GSports.Online.Model.Request;
using System;
using System.Collections.Generic;

namespace GSports.Online.Model.Response.EventService
{
    public class GetEventsResponse : BaseResponse
    {
        public List<Event> Events { get; set; }
        
        public DateTime LastUpdateTime { get; set; }
        public int EventCount
        {
            get { return (this.Events == null) ? 0 : this.Events.Count; }
        }
        public override bool IsResponseDataValid()
        {
            return Events != null;
        }
    }
}
