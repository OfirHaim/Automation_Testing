﻿using GSports.Clients.EventsManager.Model.Entities;
using GSports.Online.Model.Entities;
using GSports.Online.Model.Request;
using System;
using System.Collections.Generic;

namespace GSports.Online.Model.Response.EventService
{
    public class GetSportsTreeResponse : BaseResponse
    {
        public TreeNode SportsTree { get; set; }
           
        public override bool IsResponseDataValid()
        {
            return SportsTree != null;
        }
    }
}
