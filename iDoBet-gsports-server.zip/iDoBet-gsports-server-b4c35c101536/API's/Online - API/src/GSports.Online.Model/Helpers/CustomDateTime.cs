﻿//using Newtonsoft.Json.Converters;

//namespace GSports.Online.Model.Helpers
//{
//    internal class CustomDateTime: IsoDateTimeConverter
//    {
//        public CustomDateTime()
//        {
//            base.DateTimeFormat = "yyyy'-'MM'-'dd'T'HH':'mm'Z'";
//        }
//    }
//}