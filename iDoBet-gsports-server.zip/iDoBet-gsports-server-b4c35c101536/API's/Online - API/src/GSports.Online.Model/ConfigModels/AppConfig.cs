﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.ConfigModels
{
    public class AppConfig
    {
        public string PushServerURL { get; set; }
        public string SystemUser { get; set; }
        public string SystemPass { get; set; }
        public bool IsCacheMaster { get; set; }
        public string ChannelName { get; set; }
        public bool IsDailyCouponOnly { get; set; }
        public string APIToken { get; set; }
        public string OriginsUrls { get; set; }
        public string ProviderIds { get; set; }
        public int CheckForChangesInterval { get; set; }

        

    }
}
