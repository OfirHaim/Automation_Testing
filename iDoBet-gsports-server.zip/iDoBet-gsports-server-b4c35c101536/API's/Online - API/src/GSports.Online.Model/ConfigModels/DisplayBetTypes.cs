﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Online.Model.ConfigModels
{
    public class DisplayBetTypes
    {
        public List<Item> Items { get; set; }
    }

    public class Item
    {
        public int Id { get; set; }
        public List<Data> Live { get; set; }
        public List<Data> Prematch { get; set; }
    }

    public class Data
    {
        public int Id { get; set; }
        public List<string> Lines { get; set; }
        public bool isLineDisplay { get; set; }
    }
}
