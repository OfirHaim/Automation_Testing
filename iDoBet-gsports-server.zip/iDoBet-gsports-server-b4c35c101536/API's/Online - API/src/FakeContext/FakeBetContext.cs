﻿using GSports.Online.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Online.Model.Request.BetService;
using GSports.Online.Model.Response.BetService;
using System.Threading;
using GSports.Online.Model.Entities;

namespace FakeContext
{
    public class FakeBetContext : IBetContext
    {
        public GetBetHistoryResponse GetBetHistory(GetBetHistoryRequest request)
        {
            return new GetBetHistoryResponse() {
                Orders = new List<Order>() { new Order() { Amount = 1000 } }
            };
        }

        public GetBetHistoryResponse GetBetOrderData(GetBetHistoryOrderDataRequest request)
        {
            return new GetBetHistoryResponse()
            {
                Orders = new List<Order>() { new Order() { Amount = 1000 } }
            };
        }

        public PlaceBetsResponse PlaceBets(PlaceBetsRequest request)
        {
            return new PlaceBetsResponse() { PlacedSuccessfully = true };
        }

        public ExecuteOnlineOrderResponse ExecuteOrder(ExecuteOnlineOrderRequest request)
        {
            return new ExecuteOnlineOrderResponse() { ExecutedSuccessfully = true };
        }
    }
}
