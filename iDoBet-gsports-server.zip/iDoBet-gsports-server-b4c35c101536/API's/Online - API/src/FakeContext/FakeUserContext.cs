﻿using GSports.Online.Contracts;
using System;
using GSports.Online.Model.Request.UserService;
using GSports.Online.Model.Response.UserService;

namespace FakeContext
{
    public class FakeUserContext : IUserContext
    {
        public ActivateAccountResponse ActivateAccount(ActivateAccountRequest request)
        {
            return new ActivateAccountResponse();
        }

        public ChangePasswordResponse ChangePassword(ChangePasswordRequest request, bool isReset = false)
        {
            throw new NotImplementedException();
        }

        public ForgotLoginDetailsResponse ForgotLoginDetails(ForgotLoginDetailsRequest request)
        {
            return new ForgotLoginDetailsResponse();
        }

        public GetUserInfoResponse GetUserInfo(GetUserInfoRequest request)
        {
            throw new NotImplementedException();
        }

        public LoginResponse LoginUser(LoginRequest request)
        {
            if(request.Username == "nemmy" && request.Password == "1q2w3e")
            return new LoginResponse()
            {
                UserToken = "TOKEN"
            };
            else
            {
                var res = new LoginResponse();
                res.SetErrorResult(GSports.Online.Model.Response.Base.eErrorCode.WrongCredetials, "User not found!");
                return res;
             }
        }

        public LogoutUserResponse LogoutUser(LogoutUserRequest request)
        {
            return new LogoutUserResponse();
        }

        public RegisterUserResponse RegisterUser(RegisterUserRequest request)
        {
            return new RegisterUserResponse();
        }

        public ResendActivationLinkResponse ResendActivationLink(ResendActivationLinkRequest request)
        {
            throw new NotImplementedException();
        }

        public UpdateUserResponse UpdateUserProfile(UpdateUserRequest request)
        {
            return new UpdateUserResponse();
        }

        public GetUserByTokenResponse GetUserByToken(GetUserByTokenRequest request)
        {
            throw new NotImplementedException();
        }

        public KeepAliveResponse KeepAlive(KeepAliveRequest request)
        {
            throw new NotImplementedException();
        }

        public GetUserSecurityQuestionResponse GetUserSecurityQuestion(GetUserSecurityQuestionRequest request, string apiToken)
        {
            throw new NotImplementedException();

        }

        public ForgotLoginDetailsResponse ForgotUserLoginDetails(ForgotLoginDetailsRequest request, string apiToken)
        {
            throw new NotImplementedException();
        }

        public ResetPasswordResponse ResetPassword(ResetPasswordRequest request)
        {
            throw new NotImplementedException();
        }
    }
}
