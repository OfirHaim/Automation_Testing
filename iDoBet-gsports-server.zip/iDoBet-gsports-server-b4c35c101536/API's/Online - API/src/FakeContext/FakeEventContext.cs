﻿using GSports.Online.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Online.Model.Request.EventService;
using GSports.Online.Model.Response.EventService;
using GSports.Online.Context.Implementations;
using GSports.Online.Model.Entities;
using GSports.Clients.EventsManager.Model.Entities;

namespace FakeContext
{
    public class FakeEventContext : IEventContext
    {
      
        public GetEventsResponse GetEvents(GetEventsRequest request)
        {
            return new EventContext().GetEvents(request);
        }

       
    }
}
