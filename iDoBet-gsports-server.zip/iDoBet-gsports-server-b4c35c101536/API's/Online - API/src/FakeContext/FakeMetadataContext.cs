﻿using GSports.Online.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Online.Model.Request.MetadataService;
using GSports.Online.Model.Response.MetadataService;
using GSports.Online.Model.Entities;

namespace FakeContext
{
    public class FakeMetadataContext : IMetadataContext
    {
        public GetCountriesResponse GetCountries(GetCountriesRequest request)
        {
            return new GetCountriesResponse()
            {
                Countries = new List<Country>()
                {
                    new Country() { Id = 1, Name = "Israel" },
                    new Country() { Id = 2, Name = "Uganda" }
                }
            };
        }

        public GetBetTypesTemplateResponse GetBetTypeTemplate(GetBetTypesTemplateRequest request)
        {
            return new GetBetTypesTemplateResponse();
        }
        public GetUserCountriesResponse GetUserCountries (GetUserCountriesRequest request)
        {
            return new GetUserCountriesResponse();
        }
        public GetUserCurrenciesResponse GetUserCurrencies(GetUserCurrenciesRequest request)
        {
            return new GetUserCurrenciesResponse();
        }

        public GetSecurityQuestionsResponse GetSecurityQuestions(GetSecurityQuestionsRequest request)
        {
            return new GetSecurityQuestionsResponse();
        }
    }
}
