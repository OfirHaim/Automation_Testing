﻿
interface IUserDetails {
    id: string;
    firstname: string;
    lastname: string;
    balance: number;
    email: string;
    username: string;
    currency: eCurrency;
    country: string;
    phoneNumber: string;
    isNewsLetterApproved: boolean;
    address: string;
}
interface IUserHistory {
    bets: IBetType[];
    pendingBets: number;
    statement: IOrder[];
    widthdraws: ITransferHistory[];
    depoosits: ITransferHistory[];
    accessLog: IAccessLog[];
}
interface IUi {
    isPending: boolean;
    language: string;
    oddsDisplay: eOddsDisplay;
    isError: boolean;
    popupMessage?: IMessage
}
interface IMessage {
    tilte: string;
    description: string;
    isShown: boolean;
    button: IButton[];
    messageType: eMessageStatus;
}
interface IButton {
    label: string;
    action: IAction;
    type: eMessageStatus;
}
export enum eMessageStatus {
    error = 1,
    success,
    info,
    warning
}
interface IAccessLog {
}
interface IAction {
    action: (type: string, paylod: Object, ) => void;
}
interface IAuth {
    isLogin: boolean;
    isActivated: boolean;
    isProfileCompleted: boolean;
    securityQuestion: string;
}


interface IBaseResponse {
    result?: IResult;
    isSuccessfull?: boolean;
    userInfo?: any;
}

interface IActivateAccountResponse extends IBaseResponse {
}

interface IChangePasswordResponse extends IBaseResponse {
    isPasswordChanged?: boolean;
}

interface IForgotLoginDetailsResponse extends IBaseResponse {
    canProceed?: boolean;
}

interface IGetUserByTokenResponse extends IBaseResponse {
    userEntity?: IUserEntity;
}

interface IGetUserInfoResponse extends IBaseResponse {
    data?: any;
}

interface IGetUserSecurityQuestionResponse extends IBaseResponse {
    securityQuestion?: ISecurityQuestion;
    canProceed?: boolean;
}

interface IKeepAliveResponse extends IBaseResponse {
}

interface ILoginResponse extends IBaseResponse {
    userToken?: string;
}

interface ILogoutUserResponse extends IBaseResponse {
}

interface IRegisterUserResponse extends IBaseResponse {
}

interface IResendActivationLinkResponse extends IBaseResponse {
}

interface IResetPasswordResponse extends IBaseResponse {
    isValid?: boolean;
    resetPasswordSucceed?: boolean;
}

interface IUpdateUserResponse extends IBaseResponse {
}

interface IGetBetTypesTemplateResponse extends IBaseResponse {
    betTypesSchema?: IBetTypeTemplate[];
}

interface IGetCountriesResponse extends IBaseResponse {
    countries?: ICountry[];
}

interface IGetSecurityQuestionsResponse extends IBaseResponse {
    securityQuestions?: ISecurityQuestion[];
}

interface IGetUserCountriesResponse extends IBaseResponse {
    countries?: IUserCountry[];
}

interface IGetUserCurrenciesResponse extends IBaseResponse {
    currencies?: ICurrency[];
}

interface ICancelWithdrawResponse extends IBaseResponse {
}

interface IDepositResponse extends IBaseResponse {
}

interface IGetTransactionResponse extends IBaseResponse {
    transactions?: ITransactionsEntity[];
}

interface IGetTransferHistoryResponse extends IBaseResponse {
    transfers?: ITransferHistory[];
}

interface ITransferHistory {
    date?: string; //Date
    transactionType?: ITransferType;
    responseType?: ITransferReason;
    amount?: number;
    comments?: string;
    id?: number;
}

interface ITransferReason {
    codeAttribute?: string;
    name?: string;
}

interface ITransferType {
    codeAttribute?: string;
    name?: string;
}

interface ISendWithdrawCodeResponse extends IBaseResponse {
    isSent?: boolean;
}

interface IWithdrawResponse extends IBaseResponse {
    code?: string;
}

interface IGetEventsResponse extends IBaseResponse {
    events?: IEvent[];
    lastUpdateTime?: string; //Date
    eventCount?: number;
}

interface IGetSportsTreeResponse extends IBaseResponse {
    sportsTree?: ITreeNode;
}

interface IExecuteOnlineOrderResponse extends IBaseResponse {
    executedSuccessfully?: boolean;
}

interface IGetBetHistoryResponse extends IBaseResponse {
    orders?: IOrder[];
}

interface IPlaceBetsResponse extends IBaseResponse {
    placedSuccessfully?: boolean;
    timeoutGuid?: string;
    timeout?: number;
}

export enum eErrorCode {
    success = 0,
    databaseError = 1,
    internalServerError = 2,
    badRequest = 3,
    badOdds = 4,
    eventColosedForBetting = 5,
    eventEnded = 6,
    eventDosntExsist = 7,
    noPermission = 8,
    duplicateData = 9,
    emptyResultData = 10,
    userTokenInvalid = 100,
    terminalTokenInvalid = 101,
    terminalTokenAlreadyInUse = 102,
    wrongCredetials = 103,
    noOpenShiftForTerminalUser = 104,
    userNameAlreadyExists = 120,
    emailAlreadyExists = 121,
    emailNotFound = 122,
    notMatchSecurityAnswer = 130,
    orderValidationError = 200,
    orderNotFound = 201,
    orderCanotPayout = 202,
    eventDataNotFound = 240,
    oddsPriceChanged = 241,
    limitationFailed = 242,
    minBetLimit = 250,
    maxBetLimit = 251,
    overCrditLimit = 252,
    eventStatusDisabled = 253,
    betTypeStatusDisabled = 254,
    oddStatusDisabled = 255,
    executeTimeIncorrect = 260,
    terminalNotFound = 300,
    terminalAlreadyRegister = 301,
    terminalIsNotActive = 302,
    notEnoughMoney = 400,
    insertWithdrawFailed = 410,
    commitWithdrawFailed = 411,
    alreadyActivated = 500,
    updateInfoFailed = 501,
    noneCountry = 502,
    eventsNotReady = 1000,
    apiError = 1001,
    gerneralApi = 1000,
    passwordCantBeNull = 1010,
    passwordMinPasswordLength = 1011,
    passwordMustContainsSpecialChar = 1012,
    passwordCantStartSpecialChar = 1013,
    passwordAtLeatOneDigit = 1014,
    passwordAtLeastOneLetter = 1015,
    passwordCombination = 1016,
    passwordSequence = 1017,
}

export enum eResultCode {
    success = 0,
    failure = 1,
}

interface IResult {
    errorDescription?: string;
    additionalInfo?: any;
    errorCode?: eErrorCode;
    resultCode?: eResultCode;
    errorCodeDescription?: string;
}

interface IBaseRequest {
    userToken?: string;
}

interface IIAuthenticatedRequest {
    token?: string;
}

interface IILanguage {
    language?: string;
}

interface IActivateAccountRequest extends IBaseRequest {
    code?: string;
}

interface IChangePasswordRequest extends IBaseRequest {
    oldPassword?: string;
    newPassword?: string;
    confirmedNewPassword?: string;
}

interface IForgotLoginDetailsRequest extends IBaseRequest {
    email?: string;
    securityQuestionAnswer?: string;
}

interface IGetUserByTokenRequest extends IBaseRequest {
}

interface IGetUserInfoRequest extends IBaseRequest {
}

interface IGetUserSecurityQuestionRequest extends IBaseRequest {
    email?: string;
}

interface IKeepAliveRequest extends IBaseRequest {
}

interface ILoginRequest extends IBaseRequest {
    username: string;
    password: string;
    IP?: string;
}

interface ILogoutUserRequest extends IBaseRequest {
}

interface IRegisterUserRequest extends IBaseRequest {
    email?: string;
    userName?: string;
    password?: string;
}

interface IResendActivationLinkRequest extends IBaseRequest {
    userId?: number;
}

interface IResetPasswordRequest extends IBaseRequest {
    guid?: string;
    password?: string;
    confirmPassword?: string;
}

interface IUpdateUserRequest extends IBaseRequest {
    email?: string;
    gender?: eGender;
    firstName?: string;
    lastName?: string;
    birthdate?: string;
    currency?: eCurrency;
    address?: string;
    phoneNumber?: string;
    oddPriceView?: eOddsDisplay;
    countryId?: number;
    acceptNewsLetter?: boolean;
    securityQuestion?: ISecurityQuestion;
}

interface IGetBetTypesTemplateRequest extends IBaseRequest {
}

interface IGetCountriesRequest extends IBaseRequest {
}

interface IGetSecurityQuestionsRequest extends IBaseRequest {
}

interface IGetUserCountriesRequest extends IBaseRequest {
}

interface IGetUserCurrenciesRequest extends IBaseRequest {
}

interface ICancelWithdrawRequest extends IBaseRequest {
    transferId?: number;
}

interface IDepositRequest extends IBaseRequest {
    depositCode?: string;
}

interface IGetTransactionRequest extends IBaseRequest {
    fromDate?: string; //Date
    toDate?: string; //Date
    transactionTypeCode?: string;
    transactionReasonCode?: string;
}

interface IGetTransferHistoryRequest extends IBaseRequest {
    fromDate?: string;
    toDate?: string;
    openOnly?: boolean;
    shiftId?: number;
    transferId?: number;
    userId?: number;
    transferTypeCode?: string;
}

interface ISendWithdrawCodeRequest extends IBaseRequest {
    withdrawId?: number;
}

interface IWithdrawRequest extends IBaseRequest {
    amount?: number;
    email?: string;
    password?: string;
}

interface IGetEventsRequest extends IBaseRequest {
    language?: string;
    eventIds?: number[];
    betTypeIds?: number[];
}

interface IGetSportsTreeRequest extends IBaseRequest {
    language?: string;
}

interface IExecuteOnlineOrderRequest extends IBaseRequest {
    timeoutGuid?: string;
}

interface IGetBetHistoryOrderDataRequest extends IBaseRequest {
    orderId?: number;
    barcode?: string;
}

interface IGetBetHistoryRequest extends IBaseRequest {
    fromDate?: string; //Date
    toDate?: string; //Date
    orderNumber?: string;
    winStatusIds?: eWinStatus[];
}

interface IPlaceBetsRequest extends IBaseRequest {
    selections?: ISelection[];
    rows?: IRequestOrderRow[];
}

interface IRequestOrderRow {
    amount?: number;
    selectionKeys?: string[];
}

interface ISelection {
    key?: string;
    eventId?: number;
    betTypeId?: number;
    oddName?: string;
    oddLine?: string;
    oddPrice?: number;
}

export enum eCurrency {
    USD = 1,
    UGX = 2,
    CDF = 3,
    EUR = 4,
    TZS = 5,
}

export enum eGender {
    male = 0,
    female = 1,
}

export enum eLogoutType {
    unknown = 0,
    logout = 1,
    relogin = 2,
    system = 3,
    forcedLogout = 4,
}

export enum eOrderStatus {
    unknown = 0,
    draft = 1,
    sold = 3,
    paid = 4,
    blocked = 5,
    cancelled = 6,
    expired = 7,
}

export enum eOddsDisplay {
    decimal = 0,
    american = 1,
    fractional = 2,
}

interface IBetTypeTemplate {
    id?: number;
    sportTypeId?: number;
    forDisplay?: boolean;
    isLineDisplay?: boolean;
    displayLine?: string;
    isFilter?: boolean;
    name?: string;
    isLive?: boolean;
    odds?: IOddTemplate[][];
}

interface IOddTemplate {
    name?: string;
}

interface IBranch {
    id?: number;
    name?: string;
}

interface ICancelReasonType {
    id?: number;
    name?: string;
    desc?: string;
}

interface ICountry {
    id?: number;
    displayName?: string;
}

interface ICurrency {
    id?: number;
    name?: string;
}

interface ITransactionsEntity {
    createTime?: string; //Date
    currentBalance?: number;
    amount?: number;
    transactionReason?: ITransactionReason;
    transcationType?: ITransactionType;
    comments?: string;
    addressedObjectId?: number;
    objectType?: string;
}

interface ITransactionReason {
    codeAttribute?: string;
    name?: string;
}

interface ITransactionType {
    codeAttribute?: string;
}

interface IOrderInfo {
    id?: number;
    orderNumber?: string;
    externalId?: string;
    transactionId?: string;
    barcode?: string;
    payout?: number;
    maxPayout?: number;
    requestGuid?: string;
    creationTime?: string; //Date
    amount?: number;
    currencyId?: number;
    currencyName?: string;
    orderProd?: eOrderProd;
    settledTime?: string;
    soldTime?: string;
    expiryDate?: string; //Date
    userId?: number;
    userName?: string;
    status?: eOrderStatus;
    winStatus?: eWinStatus;
    urlKey?: string;
    totalBonus?: number;
    bonusDesc?: string;
    totalTax?: number;
    taxDesc?: string;
    totalSelections?: number;
    totalLines?: number;
}

interface IOrder extends IOrderInfo {
    orderRows?: IOrderRow[];
}

interface IOrderRow {
    id?: number;
    amount?: number;
    bets?: IOrderBet[];
    orderId?: number;
    winStatus?: eWinStatus;
    totalRatio?: number;
    payout?: number;
    bonus?: number;
}

interface IOrderBet {
    id?: number;
    orderRowId?: number;
    orderId?: number;
    winStatus?: eWinStatus;
    event?: IEvent;
    betInfo?: string;
    liveInfo?: string;
}

export enum eWinStatus {
    pending = 0,
    loser = 1,
    winner = 2,
    moneyBack = 3,
    halfWin = 4,
    halfLose = 5,
    unknown = -1,
}

export enum eOrderProd {
    unknown = 0,
    prematch = 1,
    live = 2,
}

interface IOrderChange {
    eventId?: number;
    eventStatus?: eEventStatus;
    betTypeId?: number;
    betTypeStatus?: eBetStatus;
    oddName?: string;
    betTypeLine?: string;
    oddPrice?: number;
    oddStatus?: eOddStatus;
}

interface ISecurityQuestion {
    questionId?: number;
    question?: string;
    answer?: string;
}

interface ITreeNode {
    id?: string;
    name?: string;
    count?: number;
    children?: ITreeNode[];
}

interface IUserEntity {
    userId?: number;
    isActivated?: boolean;
    token?: string;
    accountId?: number;
    firstName?: string;
    lastName?: string;
    userName?: string;
    email?: string;
    country?: ICountry;
    gender?: eGender;
    language?: string;
    birthday?: string; //Date
    gMTOffset?: number;
    oddsView?: eOddsDisplay;
    isFullProfile?: boolean;
    currency?: ICurrency;
    balance?: number;
    holding?: number;
    address?: string;
    phone?: string;
    acceptNewsletter?: boolean;
    minBet?: number;
    maxBet?: number;
}

interface IUserCountry {
    name?: string;
    id?: number;
    phoneCode?: number;
}

interface IPropertyNames {
}

interface IAppConfig {
    pushServerURL?: string;
    systemUser?: string;
    systemPass?: string;
    isCacheMaster?: boolean;
    channelName?: string;
    isDailyCouponOnly?: boolean;
    aPIToken?: string;
    originsUrls?: string;
}

interface IDisplayBetTypes {
    items?: IItem[];
}

interface IItem {
    id?: number;
    live?: IData[];
    prematch?: IData[];
}

interface IData {
    id?: number;
    lines?: string[];
    isLineDisplay?: boolean;
}

interface IIDiffCompare {
    ck?: string;
}

interface IBetType {
    data?: IBetTypeData;
    ck?: string;
    odds?: IOdd[];
}

interface IBetTypeData {
    name?: string;
    status?: eBetStatus;
    line?: string;
    id?: number;
    order?: number;
    md?: string;
}

interface IEventCountry {
    id?: number;
    displayName?: string;
}

interface IEvent {
    data?: IEventData;
    bts?: IBetType[];
    btCount?: number;
    ck?: string;
    gn?: string;
}

interface IEventData {
    id?: number;
    couponId?: number;
    sportName?: string;
    sportId?: number;
    state?: eEventState;
    status?: eEventStatus;
    leagueName?: string;
    leagueId?: number;
    countryName?: string;
    countryId?: number;
    home?: string;
    away?: string;
    time?: string; //Date
    book?: boolean;
    topevent?: number;
    mtd?: IEventMetaData;
    live?: ILiveData;
}

interface ISimpleTwoSidesScore {
    home?: number;
    away?: number;
}

interface ILiveData {
    time?: string;
    score?: ISimpleTwoSidesScore;
    homeRedCards?: number;
    awayRedCards?: number;
    setScore?: ISimpleTwoSidesScore[];
    whoServes?: eHomeAway;
    clockPaused?: boolean;
    remainingTime?: number;
}

interface IEventMetaData {
    so?: number;
    co?: number;
    lo?: number;
}

interface ILeague {
    id?: number;
    displayName?: string;
}

interface ISportType {
    id?: number;
    displayName?: string;
}

interface ITeam {
    id?: number;
    displayName?: string;
}

interface IUpdateMessage {
    key?: string;
    value?: any;
    messageId?: number;
    time?: string; //Date
}

interface IOdd {
    ck?: string;
    name?: string;
    price?: string;
    status?: eOddStatus;
    shortcut?: string;
    orderRow?: number;
    orderCol?: number;
}

export enum eBetStatus {
    open = 0,
    suspended = 1,
    closed = 2,
    deleted = 3,
    unknown = -1,
    canceled = 4,
}

export enum eEventState {
    UNDEFINED = 0,
    NOT_STARTED = 1,
    STARTED = 2,
    ITEM1P = 3,
    ITEM2P = 4,
    ITEM3P = 5,
    ITEM4P = 6,
    ITEM5P = 7,
    ITEM1SET = 8,
    ITEM2SET = 9,
    ITEM3SET = 10,
    ITEM4SET = 11,
    ITEM5SET = 12,
    ITEM1Q = 13,
    ITEM2Q = 14,
    ITEM3Q = 15,
    ITEM4Q = 16,
    PAUSED = 17,
    PAUSE1 = 18,
    PAUSE2 = 19,
    PAUSE3 = 20,
    PAUSE4 = 21,
    OT = 22,
    AWAITING_OT = 23,
    ITEM1P_OT = 24,
    OT_HT = 25,
    ITEM2P_OT = 26,
    AFTER_OT = 27,
    AWAITING_PEN = 28,
    PEN = 29,
    AFTER_PEN = 30,
    ENDED = 31,
    POSTPONED = 32,
    DELAYED = 33,
    CANCELED = 34,
    INTERRUPTED = 35,
    ABANDONED = 36,
    WALKOVER = 37,
    WALKOVER1 = 38,
    WALKOVER2 = 39,
    RETIRED = 40,
    RETIRED1 = 41,
    RETIRED2 = 42,
    ITEM1IT = 43,
    ITEM1IB = 44,
    ITEM2IT = 45,
    ITEM2IB = 46,
    ITEM3IT = 47,
    ITEM3IB = 48,
    ITEM4IT = 49,
    ITEM4IB = 50,
    ITEM5IT = 51,
    ITEM5IB = 52,
    ITEM6IT = 53,
    ITEM6IB = 54,
    ITEM7IT = 55,
    ITEM7IB = 56,
    ITEM8IT = 57,
    ITEM8IB = 58,
    ITEM9IT = 59,
    ITEM9IB = 60,
    EIT = 61,
    EIB = 62,
    BT1B1 = 63,
    BT2B1 = 64,
    BT2B2 = 65,
    BT3B2 = 66,
    BT3B3 = 67,
    BT4B3 = 68,
    BT4B4 = 69,
    BT5B4 = 70,
    BT5B5 = 71,
    BT6B5 = 72,
    BT6B6 = 73,
    BT7B6 = 74,
    BT7B7 = 75,
    BT8B7 = 76,
    BT8B8 = 77,
    BT9B8 = 78,
    BT9B9 = 79,
    BTEIB9 = 80,
    BTEIBEI = 81,
    GSET = 82,
    SD = 83,
    IN_PROGRESS = 84,
    SESSION_BREAK = 85,
    REMOVED = 5000,
}

export enum eEventStatus {
    unknown = -1,
    prematch = 0,
    live = 1,
    closed = 2,
    canceled = 3,
    interrupted = 4,
    void = 5,
    awaitingLive = 6,
}

export enum eHomeAway {
    UNDEFINED = 0,
    AWAY = 1,
    HOME = 2,
    NONE = 3,
}

export enum eOddStatus {
    unknown = -1,
    open = 0,
    suspended = 1,
    closed = 2,
}


