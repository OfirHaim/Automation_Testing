﻿
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
export enum eErrorCode {
	success = 0,
	databaseError = 1,
	internalServerError = 2,
	badRequest = 3,
	badOdds = 4,
	eventColosedForBetting = 5,
	eventEnded = 6,
	eventDosntExsist = 7,
	noPermission = 8,
	duplicateData = 9,
	emptyResultData = 10,
	userTokenInvalid = 100,
	terminalTokenInvalid = 101,
	terminalTokenAlreadyInUse = 102,
	wrongCredetials = 103,
	noOpenShiftForTerminalUser = 104,
	userNameAlreadyExists = 120,
	emailAlreadyExists = 121,
	orderValidationError = 200,
	orderNotFound = 201,
	orderCanotPayout = 202,
	eventDataNotFound = 240,
	oddsPriceChanged = 241,
	limitationFailed = 242,
	minBetLimit = 250,
	maxBetLimit = 251,
	overCrditLimit = 252,
	eventStatusDisabled = 253,
	betTypeStatusDisabled = 254,
	oddStatusDisabled = 255,
	executeTimeIncorrect = 260,
	terminalNotFound = 300,
	terminalAlreadyRegister = 301,
	terminalIsNotActive = 302,
	notEnoughMoney = 400,
	insertWithdrawFailed = 410,
	commitWithdrawFailed = 411,
	alreadyActivated = 500,
	updateInfoFailed = 501,
	noneCountry = 502,
	eventsNotReady = 1000,
	apiError = 1001,
	gerneralApi = 1000,
	passwordCantBeNull = 1010,
	passwordMinPasswordLength = 1011,
	passwordMustContainsSpecialChar = 1012,
	passwordCantStartSpecialChar = 1013,
	passwordAtLeatOneDigit = 1014,
	passwordAtLeastOneLetter = 1015,
	passwordCombination = 1016,
}
 
export enum eResultCode {
	success = 0,
	failure = 1,
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
export enum eCurrency {
	USD = 0,
	TZS = 1,
	UGX = 2,
}
 
export enum eGender {
	male = 0,
	female = 1,
}
 
export enum eLogoutType {
	unknown = 0,
	logout = 1,
	relogin = 2,
	system = 3,
	forcedLogout = 4,
}
 
export enum eOrderStatus {
	unknown = 0,
	draft = 1,
	sold = 3,
	paid = 4,
	blocked = 5,
	cancelled = 6,
	expired = 7,
}
 
export enum eOddsView {
	decimal = 0,
	american = 1,
	fractional = 2,
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
export enum eWinStatus {
	pending = 0,
	loser = 1,
	winner = 2,
	moneyBack = 3,
	halfWin = 4,
	halfLose = 5,
	unknown = -1,
}
 
export enum eOrderProd {
	unknown = 0,
	prematch = 1,
	live = 2,
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
export enum eBetStatus {
	open = 0,
	suspended = 1,
	closed = 2,
	deleted = 3,
	unknown = -1,
	canceled = 4,
}
 
export enum eEventState {
	UNDEFINED = 0,
	NOT_STARTED = 1,
	STARTED = 2,
	ITEM1P = 3,
	ITEM2P = 4,
	ITEM3P = 5,
	ITEM4P = 6,
	ITEM5P = 7,
	ITEM1SET = 8,
	ITEM2SET = 9,
	ITEM3SET = 10,
	ITEM4SET = 11,
	ITEM5SET = 12,
	ITEM1Q = 13,
	ITEM2Q = 14,
	ITEM3Q = 15,
	ITEM4Q = 16,
	PAUSED = 17,
	PAUSE1 = 18,
	PAUSE2 = 19,
	PAUSE3 = 20,
	PAUSE4 = 21,
	OT = 22,
	AWAITING_OT = 23,
	ITEM1P_OT = 24,
	OT_HT = 25,
	ITEM2P_OT = 26,
	AFTER_OT = 27,
	AWAITING_PEN = 28,
	PEN = 29,
	AFTER_PEN = 30,
	ENDED = 31,
	POSTPONED = 32,
	DELAYED = 33,
	CANCELED = 34,
	INTERRUPTED = 35,
	ABANDONED = 36,
	WALKOVER = 37,
	WALKOVER1 = 38,
	WALKOVER2 = 39,
	RETIRED = 40,
	RETIRED1 = 41,
	RETIRED2 = 42,
	ITEM1IT = 43,
	ITEM1IB = 44,
	ITEM2IT = 45,
	ITEM2IB = 46,
	ITEM3IT = 47,
	ITEM3IB = 48,
	ITEM4IT = 49,
	ITEM4IB = 50,
	ITEM5IT = 51,
	ITEM5IB = 52,
	ITEM6IT = 53,
	ITEM6IB = 54,
	ITEM7IT = 55,
	ITEM7IB = 56,
	ITEM8IT = 57,
	ITEM8IB = 58,
	ITEM9IT = 59,
	ITEM9IB = 60,
	EIT = 61,
	EIB = 62,
	BT1B1 = 63,
	BT2B1 = 64,
	BT2B2 = 65,
	BT3B2 = 66,
	BT3B3 = 67,
	BT4B3 = 68,
	BT4B4 = 69,
	BT5B4 = 70,
	BT5B5 = 71,
	BT6B5 = 72,
	BT6B6 = 73,
	BT7B6 = 74,
	BT7B7 = 75,
	BT8B7 = 76,
	BT8B8 = 77,
	BT9B8 = 78,
	BT9B9 = 79,
	BTEIB9 = 80,
	BTEIBEI = 81,
	GSET = 82,
	SD = 83,
	IN_PROGRESS = 84,
	SESSION_BREAK = 85,
	REMOVED = 5000,
}
 
export enum eEventStatus {
	unknown = -1,
	prematch = 0,
	live = 1,
	closed = 2,
	canceled = 3,
	interrupted = 4,
	void = 5,
	awaitingLive = 6,
}
 
export enum eHomeAway {
	UNDEFINED = 0,
	AWAY = 1,
	HOME = 2,
	NONE = 3,
}
 
export enum eOddStatus {
	unknown = -1,
	open = 0,
	suspended = 1,
	closed = 2,
}
 
