﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GSports.CashBox.Contracts;
using GSports.CashBox.Model.Request.UserService;
using GSports.CashBox.Model.Response.UserService;
using GSports.CashBox.Model.Response.Shifts;
using GSports.CashBox.Model.Request.Shifts;
using GSports.CashBoxApi.BL;
using GSports.CashBox.Model.Consts;
using Gsports.CashBoxApi.BL;


// For more information on enabling Web API for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace GSports.CashBoxApi.Controllers
{
    [Route("[controller]/[action]")]
    public class UserController : GSBaseController, IUserContext
    {
        private readonly IUserContext _userChannel;

        public UserController(IUserContext userContext)
        {
            _userChannel = userContext;

        }
        [HttpGet]
        [UserInfoFilter]
        public GetUsersResponse GetUsers(GetUsersRequest request)
        {
            GetUsersResponse retVal = new GetUsersResponse();
            try
            {
                retVal = _userChannel.GetUsers(request); 
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
        //[HttpGet]
        //public GetBranchUsersResponse GetBranchUsers(GetBranchUsersRequest request)
        //{
        //    return _userChannel.GetBranchUsers(request);
        //}

        [HttpPost]
        [LogFilterAtrribute]
        public StartShiftResponse StartShift([FromBody] StartShiftRequest request)
        {
            StartShiftResponse retVal = new StartShiftResponse();
            try
            {
                retVal = _userChannel.StartShift(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public StartUserShiftResponse StartUserShift([FromBody] StartUserShiftRequest request)
        {
            StartUserShiftResponse retVal = new StartUserShiftResponse();
            try
            {
                retVal = _userChannel.StartUserShift(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public StopUserShiftResponse StopUserShift([FromBody] StopUserShiftRequest request)
        {
            StopUserShiftResponse retVal = new StopUserShiftResponse();
            try
            {
                retVal = _userChannel.StopUserShift(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public StopShiftResponse StopShift([FromBody] StopShiftRequest request)
        {
            StopShiftResponse retVal = new StopShiftResponse();
            try
            {
                retVal = _userChannel.StopShift(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        public GetCurrentShiftResponse GetUserShiftsData([FromBody]GetUserShiftsDataRequest request)
        {
            GetCurrentShiftResponse retVal = new GetCurrentShiftResponse();
            try
            {
                retVal = _userChannel.GetUserShiftsData(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }       
        [HttpGet]
        public GetAllowedContactsResponse GetAllowedContacts(GetAllowedContactsRequest request)
        {
            GetAllowedContactsResponse retVal = new GetAllowedContactsResponse();
            try
            {
                retVal = _userChannel.GetAllowedContacts(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

     
    }
}
