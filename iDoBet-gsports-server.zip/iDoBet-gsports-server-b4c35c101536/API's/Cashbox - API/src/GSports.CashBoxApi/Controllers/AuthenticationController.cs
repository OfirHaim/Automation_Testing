﻿using GSports.CashBox.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Request.AuthenticationService;
using GSports.CashBox.Model.Response.AuthenticationService;
using GSports.CashBoxApi.BL;
using GSports.CashBox.Model.Consts;
using Gsports.CashBoxApi.BL;

namespace GSports.CashBoxApi.Controllers
{
    [Route("[controller]/[action]")]
    public class AuthenticationController : GSBaseController, IAuthenticationContext
    {
        private readonly IAuthenticationContext _authenticationContext;
         
        public AuthenticationController(IAuthenticationContext authenticationContext)
        {
            _authenticationContext = authenticationContext;
        }
        [HttpPost]
        [LogFilterAtrribute]
        public TerminalStatusResponse GetTerminalStatus([FromBody]TerminalStatusRequest request)
        {
            TerminalStatusResponse retVal = new TerminalStatusResponse();
            try
            {
                retVal = _authenticationContext.GetTerminalStatus(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
        [HttpPost]      
        [LogFilterAtrribute] 
        public LoginResponse LoginUser([FromBody]LoginRequest request)
        {
            LoginResponse retVal = new LoginResponse();
            try
            {
                retVal = _authenticationContext.LoginUser(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
        [HttpPost]
        [LogFilterAtrribute]
        public LogoutResponse LogoutUser([FromBody]LogoutRequest request)
        {
            LogoutResponse retVal = new LogoutResponse();
            try
            {
                retVal = _authenticationContext.LogoutUser(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
        [HttpPost]
        [LogFilterAtrribute]
        public RegisterTerminalResponse RegisterTerminal([FromBody]RegisterTerminalRequest request)
        {
            RegisterTerminalResponse retVal = new RegisterTerminalResponse();
            try
            {
                retVal = _authenticationContext.RegisterTerminal(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
       

    }
}
