﻿using GSports.CashBox.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Request.FinanceService;
using GSports.CashBox.Model.Response.FinanceService;
using GSports.CashBoxApi.BL;
using Microsoft.Extensions.Options;
using GSports.CashBox.Model.Config;
using GSports.Model.Consts;
using GSports.CashBox.Model.Consts;
using Gsports.CashBoxApi.BL;

namespace GSports.CashBoxApi.Controllers
{
    [Route("[controller]/[action]")]
    public class FinanceController : GSBaseController, IFinanceContext
    {
        private readonly IFinanceContext _financeContext;
        private readonly string _WithdrawPrintTemplate;
        private readonly string _DepositPrintTemplate;

        public FinanceController(IFinanceContext financeContext, IOptions<App> appConfig)
        {
            _financeContext = financeContext;
            _WithdrawPrintTemplate = appConfig.Value.WithdrawPrintTemplate;
            _DepositPrintTemplate = appConfig.Value.DepositPrintTemplate;

        }
        [HttpPost]
        [LogFilterAtrribute]
        [UserInfoFilter]
        public DepositResponse CreateDeposit([FromBody] DepositRequest request)
        {
            DepositResponse retVal = new DepositResponse();
            try
            {
                request.DepositPrintTemplate = this._DepositPrintTemplate;
                retVal = _financeContext.CreateDeposit(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public CreateTransferResponse CreateTransfer([FromBody] CreateTransferRequest request)
        {
            CreateTransferResponse retVal = new CreateTransferResponse();
            try
            {
                retVal = _financeContext.CreateTransfer(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        public GetTransactionsResponse GetTransactions([FromBody]GetTransactionsRequest request)
        {
            GetTransactionsResponse retVal = new GetTransactionsResponse();
            try
            {
                retVal = _financeContext.GetTransactions(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }


        [HttpPost]
        public GetTransfersResponse GetTransfers([FromBody]GetTransfersRequest request)
        {
            GetTransfersResponse retVal = new GetTransfersResponse();
            try
            {
                retVal = _financeContext.GetTransfers(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;

        }

        [HttpPost]
        [UserInfoFilter]
        public UpdateTransferResponse UpdateTransfer([FromBody] UpdateTransferRequest request)
        {
            UpdateTransferResponse retVal = new UpdateTransferResponse();
            try
            {
                retVal = _financeContext.UpdateTransfer(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        [UserInfoFilter]
        public UpdateWithdrawResponse UpdateWithdraw([FromBody] UpdateWithdrawRequest request)
        {
            UpdateWithdrawResponse retVal = new UpdateWithdrawResponse();
            request.WithdrawPrintTemplate = this._WithdrawPrintTemplate;
            try
            {
                retVal = _financeContext.UpdateWithdraw(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        public GetReportsResponse GetReports ([FromBody]GetReportsRequest request)
        {
            GetReportsResponse retVal = new GetReportsResponse();
            try
            {
                retVal = _financeContext.GetReports(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
    }
}
