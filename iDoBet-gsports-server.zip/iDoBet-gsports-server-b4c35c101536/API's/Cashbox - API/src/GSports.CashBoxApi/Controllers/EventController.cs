﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using GSports.CashBox.Contracts;
using GSports.CashBox.Model.Response.EventService;
using GSports.CashBox.Model.Consts;
using GSports.CashBox.Model.Request.EventService;

namespace GSports.CashBoxApi.Controllers
{
    [Route("[controller]/[action]")]
    public class EventController: GSBaseController, IEventContext
    {
        private readonly IEventContext _eventContext;
        public EventController(IEventContext channel, ILogger<EventController> logger)
        {
            _eventContext = channel;
            logger.LogInformation("events controller");
        }

      
        [HttpGet]
        public GetEventsResponse GetEvents(GetEventsRequest reqeust)
        {
            GetEventsResponse retVal = new GetEventsResponse();
            try
            {
                retVal = _eventContext.GetEvents(reqeust);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
        [HttpGet]
        public GetEventsUpdatesResponse GetEventsUpdates(GetEventsUpdatesRequest reqeust)
        {
            GetEventsUpdatesResponse retVal = new GetEventsUpdatesResponse();
            try
            {
                retVal = _eventContext.GetEventsUpdates(reqeust);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
    }

  
}
