﻿using GSports.CashBox.Contracts;
using GSports.CashBox.Model.Config;
using GSports.CashBox.Model.Consts;
using GSports.CashBox.Model.Entities;
using GSports.CashBox.Model.Request.MetadataService;
using GSports.CashBox.Model.Response.MetadataService;
using GSports.CashBoxApi.BL;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBoxApi.Controllers
{
    [Route("[controller]/[action]")]
    public class MetadataController : GSBaseController, IMetadataContext
    {
        private readonly IMetadataContext _metadataContext;
        private readonly List<Item> btTemplate;
        private readonly IMemoryCache _cache;
        private const string GET_BETTYPE_TEMPLATE_RESPONSE  = "GET_BETTYPE_TEMPLATE_RESPONSE";

        public MetadataController(IMetadataContext metadataChannel, IOptions<DisplayBetTypes> displayBetTypesConfig, IMemoryCache cache)
        {
            _metadataContext = metadataChannel;
            btTemplate = displayBetTypesConfig.Value.Items;
            _cache = cache;
        }
        [HttpGet]
        public GetBetTypesTemplateResponse GetBetTypeTemplate(GetBetTypesTemplateRequest request)
        {
            GetBetTypesTemplateResponse retVal = new GetBetTypesTemplateResponse();
            try
            {
                if (!_cache.TryGetValue(GET_BETTYPE_TEMPLATE_RESPONSE, out retVal))
                {
                    retVal = _metadataContext.GetBetTypeTemplate(request);
                    if (retVal.IsSuccessfull)
                    {
                        var joined = btTemplate.SelectMany(s => s.Live).Union(btTemplate.SelectMany(s => s.Prematch));

                        joined.ToList().ForEach(x =>
                        {
                            if (x.Lines != null && x.Lines.Count > 1)
                            {
                                var corrBt = retVal.BetTypesSchema.FirstOrDefault(f => f.Id == x.Id);
                                retVal.BetTypesSchema.Remove(corrBt);
                                x.Lines.ForEach(f =>
                                {
                                    var copy = Newtonsoft.Json.JsonConvert.DeserializeObject<BetTypeTemplate>(Newtonsoft.Json.JsonConvert.SerializeObject(corrBt), new JsonSerializerSettings { ObjectCreationHandling = ObjectCreationHandling.Replace });
                                    copy.DisplayLine = f;
                                    copy.ForDisplay = true;
                                    retVal.BetTypesSchema.Add(copy);
                                });
                            }
                            else
                            {
                                var bt = retVal.BetTypesSchema.FirstOrDefault(f => f.Id == x.Id);
                                if (bt != null)
                                {
                                    bt.ForDisplay = true;
                                    bt.DisplayLine = x.Lines?.FirstOrDefault();
                                }
                            }
                        });
                    }
                    _cache.Set(GET_BETTYPE_TEMPLATE_RESPONSE, retVal, new MemoryCacheEntryOptions().SetAbsoluteExpiration(relative: TimeSpan.FromHours(1)));
                }
            }
            catch(Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
        [HttpGet]
        public GetCancelReasonTypeResponse GetCancelReasonTypes(GetCancelReasonTypeRequest request)
        {
            GetCancelReasonTypeResponse retVal = new GetCancelReasonTypeResponse();
            try
            {
                retVal = _metadataContext.GetCancelReasonTypes(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpGet]
        public FileStreamResult DownloadCoupon(DownloadCouponRequest request)
        {
            FileStreamResult retVal;
            try
            {
                retVal = _metadataContext.DownloadCoupon(request);
            }
            catch (Exception ex)
            {
                return null;
            }
            return retVal;
        }

        [HttpPost]
        public GetCouponsResponse GetCoupons([FromBody] GetCouponsRequest request)
        {
            GetCouponsResponse retVal = new GetCouponsResponse();
            try
            {
                retVal = _metadataContext.GetCoupons(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        [UserInfoFilter]
        public KeepAliveResponse KeepAliveTerminal([FromBody] KeepAliveRequest request)
        {
            KeepAliveResponse retVal = new KeepAliveResponse();
            try
            {
                retVal = _metadataContext.KeepAliveTerminal(request);
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
    }
}
