﻿using GSports.CashBox.Contracts;
using Microsoft.AspNetCore.Mvc;
using System;
using GSports.CashBox.Model.Request.BetService;
using GSports.CashBox.Model.Response.BetService;
using GSports.CashBox.Model.Config;
using GSports.CashBoxApi.BL;
using Microsoft.Extensions.Options;
using GSports.CashBox.Model.Consts;
using Gsports.CashBoxApi.BL;

namespace GSports.CashBoxApi.Controllers
{
    [Route("[controller]/[action]")]
    public class BetController : GSBaseController, IBetContext
    {
        private readonly IBetContext _betContext;

        private readonly string _orderPrintTemplate;

        public BetController(IBetContext betContext, IOptions<App> appConfig)
        {
            _betContext = betContext;
            _orderPrintTemplate = appConfig.Value.OrderPrintTemplate;
        }
        [HttpPost]
        [LogFilterAtrribute]
        [UserInfoFilter]        
        public CancelOrderResponse CancelOrder([FromBody] CancelOrderRequest request)
        {
            CancelOrderResponse retVal = new CancelOrderResponse();
            try
            {
                retVal = _betContext.CancelOrder(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;

        }
        [HttpPost]
        [LogFilterAtrribute]
        [UserInfoFilter]
        public DoPayoutResponse DoPayout([FromBody] DoPayoutRequest request)
        {
            DoPayoutResponse retVal = new DoPayoutResponse();
            try
            {
                retVal = _betContext.DoPayout(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpPost]
        [LogFilterAtrribute]
        [UserInfoFilter]        
        public ExecuteOrderResponse ExecuteOrder([FromBody] ExecuteOrderRequest request)
        {
            request.OrderPrintTemplate = _orderPrintTemplate;
            ExecuteOrderResponse retVal = new ExecuteOrderResponse();
            try
            {
                retVal = _betContext.ExecuteOrder(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }

        [HttpGet]
        [LogFilterAtrribute]
        [UserInfoFilter]        
        public GetOrderDataResponse GetBetOrderData(GetOrderDataRequest request)
        {
            request.OrderPrintTemplate = _orderPrintTemplate;
            GetOrderDataResponse retVal = new GetOrderDataResponse();
            try
            {
                retVal = _betContext.GetBetOrderData(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
        [HttpPost]
        [LogFilterAtrribute]
        public PlaceBetsResponse PlaceBets([FromBody] PlaceBetsRequest request)
        {
            request.OrderPrintTemplate = _orderPrintTemplate;
            PlaceBetsResponse retVal = new PlaceBetsResponse();
            try
            {
                retVal = _betContext.PlaceBets(request);

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(ex.Message, (int)eApiErrorCode.APIError);
            }
            return retVal;
        }
    }
}
