﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using GSports.CashBoxApi.BL;
using GSports.CashBox.Model.Config;
using GSports.CashBox.Model.Request.AuthenticationService;
using GSports.CashBox.Context.Implementations;
using Microsoft.AspNetCore.Builder;
using GSports.Clients.EventsManager;
using System.IO.Compression;
using GSports.GLogger;

namespace Gsports.CashBoxApi
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            Logger.WriteLog(eLogLevel.Info, "Service Starting");
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile("displayBetTypes.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true);
                

            if (env.IsEnvironment("Development"))
            {
                // This will push telemetry data through Application Insights pipeline faster, allowing you to view results immediately.
                builder.AddApplicationInsightsSettings(developerMode: true);
            }

            builder.AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public void ConfigureServices(IServiceCollection services)
        {
            ServicesConfiguration.ConfigureGeneralServices(services);
            DiRegistration.RegisterServices(services);
            services.Configure<App>(Configuration.GetSection("App"));
            services.Configure<DisplayBetTypes>(Configuration.GetSection("DisplayBetTypes"));
            services.Configure<EventManager>(Configuration.GetSection("EventManager"));
        }

        public IConfigurationRoot Configuration { get; }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, IOptions<App> appConfig, IOptions<EventManager> eventManagerConfig)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();
            app.UseCors(builder =>
                builder.WithOrigins(appConfig.Value.OriginsUrls.Split(','))
                           .AllowAnyHeader().AllowAnyMethod().AllowCredentials()
                    );
            app.UseGsGzipCompression();
            app.UseMvc();
            //app.UseFileServer();
            //app.UseStaticFiles();
            AuthenticationContext context = new AuthenticationContext();
            LoginRequest request = new LoginRequest() { Username = appConfig.Value.User, Password = appConfig.Value.Password };
            var res = context.LoginUser(request);
            string token = res.Token;
            Task.Run(() =>

            EventSingleton.InitEventSingelton(eventManagerConfig.Value.PushServerURL, 
                                              token,
                                              eventManagerConfig.Value.IsCacheMaster,
                                              eventManagerConfig.Value.ChannelName,                                              
                                              eventManagerConfig.Value.OnlyActiveCoupon,
                                              eventManagerConfig.Value.UpdateMessagesLifeTimeMinutes,
                                              eventManagerConfig.Value.CheckForChangesEveryMilliseconds,
                                              eventManagerConfig.Value.ProviderIds == "*"? null: eventManagerConfig.Value.ProviderIds,
                                              eventManagerConfig.Value.SportIds == "*" ? null : eventManagerConfig.Value.SportIds,
                                              eventManagerConfig.Value.BetTypeIds == "*"? null : eventManagerConfig.Value.BetTypeIds
                                              )
            );
            Logger.WriteLog(eLogLevel.Info, "Service Started");
        }
    }
}
