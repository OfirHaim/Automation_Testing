﻿using GSports.CashBox.Context.Implementations;
using GSports.CashBox.Contracts;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBoxApi.BL
{
    public class DiRegistration
    {
        public static void RegisterServices(IServiceCollection services)
        {
            services.AddTransient<IUserContext, UserContext>();
            services.AddTransient<IAuthenticationContext, AuthenticationContext>();
            services.AddTransient<IEventContext, EventContext>();
            services.AddTransient<IMetadataContext, MetadataContext>();
            services.AddTransient<IBetContext, BetContext>();
            services.AddTransient<IFinanceContext, FinanceContext>();
        }
    }
}
