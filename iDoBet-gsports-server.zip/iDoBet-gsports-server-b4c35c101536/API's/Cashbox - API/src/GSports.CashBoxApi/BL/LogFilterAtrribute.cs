﻿using GSports.CashBox.Context.Channel;
using GSports.CashBox.Model.Request.Base;
using GSports.CashBox.Model.Response.Base;
using GSports.GLogger;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Gsports.CashBoxApi.BL
{
    public class LogFilterAtrribute : ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            try

            {
                var res = ((Microsoft.AspNetCore.Mvc.ObjectResult)context.Result).Value as BaseResponse;
                if (res != null)
                {
                    var descriptor = context.ActionDescriptor;
                    var actionName = ((Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor)descriptor).ActionName;
                    var ControllerName = ((Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor)descriptor).ControllerName;
                    Logger.WriteLog(eLogLevel.Debug, string.Format("Response (IP : {3}) -> {0} -> {1} -> {2}", ControllerName, actionName, JsonConvert.SerializeObject(res), context.HttpContext.Connection.RemoteIpAddress));


                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, "", ex);
            }

        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            try
            {
                var req = context.ActionArguments.FirstOrDefault(x => x.Value is BaseRequest).Value;
                if (req != null)
                {
                    var descriptor = context.ActionDescriptor;
                    var actionName = ((Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor)descriptor).ActionName;
                    var ControllerName = ((Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor)descriptor).ControllerName;
                    Logger.WriteLog(eLogLevel.Debug, string.Format("Request (IP : {3}) -> {0} -> {1} -> {2}", ControllerName, actionName, JsonConvert.SerializeObject(req), context.HttpContext.Connection.RemoteIpAddress));
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, "", ex);
            }
        }
    }
}
