﻿using GSports.CashBox.Context.Channel;
using GSports.CashBox.Contracts;
using GSports.CashBox.Model.Consts;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Request.UserService;
using GSports.CashBox.Model.Response.UserService;
using GSports.CashBox.Context.Convertors;
using GSports.CashBox.Model.Response.Shifts;
using GSports.CashBox.Model.Request.Shifts;

namespace GSports.CashBox.Context.Implementations
{
    public class UserContext : IUserContext
    {
        public GetUsersResponse GetUsers(GetUsersRequest request)
        {
            var retVal = new GetUsersResponse();
            var res = UserChannel.GetUser(RequestConvertor.ToGetUsersRequest(request));
            var user = res.Users.FirstOrDefault(u=>((GSports.Model.Entities.User.OperatorUser)u).CurrentShift !=null);
            
            GSports.Model.Responses.Shifts.GetShiftDataResponse resShiftData = null;
            if (user != null)
                resShiftData = UserChannel.GetShiftData(new GSports.Model.Requests.Shifts.GetShiftDataRequest() {   UserToken = request.UserToken, UserIds = res.Users.Select(u => u.Id).ToList() , ShiftId = ((GSports.Model.Entities.User.OperatorUser)user).CurrentShift.ShiftId } );
                               
            retVal = ResponseConvertor.ToGetUsersResponse(res ,resShiftData);
            return retVal;
        }

        public StartShiftResponse StartShift(StartShiftRequest request)
        {
            var retVal = new StartShiftResponse();
            var resStartShift = UserChannel.StartShift(RequestConvertor.ToStartShiftRequest(request));
          
            retVal = ResponseConvertor.ToStartShiftResponnse(resStartShift);
            return retVal;
        }

        public StartUserShiftResponse StartUserShift(StartUserShiftRequest request)
        {
            var retVal = new StartUserShiftResponse();
            var res = UserChannel.StartUserShift(RequestConvertor.ToStartUserShiftRequest(request));
            retVal = ResponseConvertor.ToStartUserShiftResponse(res);
            return retVal;
        }

        public StopUserShiftResponse StopUserShift(StopUserShiftRequest request)
        {
            var retVal = new StopUserShiftResponse();
            var res = UserChannel.StopUserShift(RequestConvertor.ToStopUserShiftRequest(request));
            retVal = ResponseConvertor.ToStopUserShiftResponse(res);
            return retVal;
        }

        public StopShiftResponse StopShift(StopShiftRequest request)
        {
            var retVal = new StopShiftResponse();
            var res = UserChannel.StopShift(RequestConvertor.ToStopShiftRequest(request));
          
            retVal = ResponseConvertor.ToStopShiftResponse(res);
            return retVal;
        }

        public GetCurrentShiftResponse GetUserShiftsData(GetUserShiftsDataRequest request)
        {
            var retVal = new GetCurrentShiftResponse();
            var res = UserChannel.GetShiftData(RequestConvertor.ToGetShiftDataRequest(request));
            retVal = ResponseConvertor.ToGetShiftDataResponse(res);
            return retVal;
        }

        //public GetBranchUsersResponse GetBranchUsers(GetBranchUsersRequest request)
        //{
        //    var retVal = new GetBranchUsersResponse();
        //    GSports.Model.Responses.Shifts.GetShiftDataResponse resShiftData = null;
        //    //Get all users in branch
        //    var getBranchUsersReq = RequestConvertor.ToGetBranchUsers(request);
        //    getBranchUsersReq.Filter.LoadCurrentShift = true;
        //    getBranchUsersReq.Filter.LoadOpenTransfers = true;
        //    var resBranchUsers = UserChannel.GetBranchUsers(getBranchUsersReq);
        //    //  Get Shift 

        //    GSports.Model.Entities.User.OperatorUser user = ((GSports.Model.Entities.User.OperatorUser) resBranchUsers.Users.FirstOrDefault(u => u is GSports.Model.Entities.User.OperatorUser));
        //    GSports.Model.Entities.Shifts.ShiftUser currentsift = null;
        //    if (user != null)
        //        currentsift = user.CurrentShift;

        //             ////Initialize get shift request to get the right shift for the current branch id
        //             //var getShiftsRequest = new GSports.Model.Requests.Shifts.GetShiftsRequest();
        //             //getShiftsRequest.Filter = new GSports.Model.Filter.ShiftFilter();
        //             //getShiftsRequest.Filter.BranchId = request.BranchId;
        //             //getShiftsRequest.Filter.CurrentOnly = true;
        //             //getShiftsRequest.UserToken = request.UserToken;
        //             //var resCurrentShifts = UserChannel.GetShifts(getShiftsRequest);
        //             //if (resCurrentShifts != null && resCurrentShifts.Shifts.Count > 0)
        //             //{
        //             //Initialize get shift data request.
        //        var getShiftDataRequest = new GSports.Model.Requests.Shifts.GetShiftDataRequest();
        //        getShiftDataRequest.UserToken = request.UserToken;
        //        getShiftDataRequest.UserIds = new List<int>();

        //        // Add userid for get Shift data request
        //        resBranchUsers.Users.ForEach(x => getShiftDataRequest.UserIds.Add(x.Id));

        //    // Set current shift id to getShiftDataRequest

        //     getShiftDataRequest.ShiftId = currentsift.ShiftId;
        //     resShiftData = UserChannel.GetShiftData(getShiftDataRequest);
        //    //}
        //    //Combine User shifts and shift data to client response
        //    retVal = ResponseConvertor.ToGetBranchUsersResponse(resBranchUsers, resShiftData);
        //    return retVal;
        //}

        public GetAllowedContactsResponse GetAllowedContacts(GetAllowedContactsRequest request)
        {
            var retVal = new GetAllowedContactsResponse();
            var res = UserChannel.GetAllowedUsers(RequestConvertor.GetAllowedContactsRequest(request));
            retVal = ResponseConvertor.GetAllowedContactsRequest(res);
            return retVal;
        }

       
    }
}
