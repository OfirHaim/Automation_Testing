﻿using GSports.CashBox.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Request.BetService;
using GSports.CashBox.Model.Response.BetService;
using GSports.CashBox.Context.Convertors;
using GSports.CashBox.Context.Channel;
using System.Threading;
using GSports.CashBox.Model.Consts;
using GSports.GLogger;
using GSports.Common.RecieptHelper;
using GSports.CashBox.Model.Request.UserService;
using GSports.CashBox.Model.Entities.Order;
using GSports.Clients.EventsManager;

namespace GSports.CashBox.Context.Implementations
{
    public class BetContext : IBetContext
    {
        public CancelOrderResponse CancelOrder(CancelOrderRequest request)
        {
            var retVal = new CancelOrderResponse();
            UserContext userContext = new UserContext();
            GetUsersRequest getUserRequest = new GetUsersRequest()
            {
                UserToken = request.UserToken,
                FilterToken = request.UserToken
            };
            var resUsers = userContext.GetUsers(getUserRequest);
            var res = BetChannel.CancelOrder(RequestConvertor.ToCancelOrderRequest(request, int.Parse(resUsers.Users.SingleOrDefault().Data.Id)));
            retVal = ResponseConvertor.ToCancelOrderResponse(res);
            return retVal;
        }

        public DoPayoutResponse DoPayout(DoPayoutRequest request)
        {
            var retVal = new DoPayoutResponse();
            var res = BetChannel.DoPayout(RequestConvertor.ToDoPayoutRequest(request));
            retVal = ResponseConvertor.ToDoPayoutResponse(res);
            return retVal;
        }

        public GetOrderDataResponse GetBetOrderData(GetOrderDataRequest request)
        {
            var retVal = new GetOrderDataResponse();
            var res = BetChannel.GetBetOrderData(RequestConvertor.ToGetBetOrderDataRequest(request));
            retVal = ResponseConvertor.ToGetOrderDataResponse(res, request.UserToken, request.OrderPrintTemplate, request.Width,request.Language, ((request.ForPrint.HasValue && request.ForPrint.Value)?true:false));
            return retVal;
        }

        public ExecuteOrderResponse ExecuteOrder(ExecuteOrderRequest request)
        {
            var retVal = new ExecuteOrderResponse();
            var res = BetChannel.ExecuteOrder(new GSports.Model.Requests.Order.ExecuteOrderRequest()
            {
                TimeoutGuid = request.TimeoutGuid,
                UserToken = request.UserToken
            });
            if (res.IsSuccessfull())
            {
                retVal = ResponseConvertor.ToExecuteOrderResponse(res, request.UserToken, request.OrderPrintTemplate, request.Width,request.Language);

            }
            else
            {
                retVal.Result = new Model.Response.Base.Result();
                if (res.ValidationResult != null && res.ValidationResult.Count() > 0 && res.ValidationResult[0].OrderBetValidationResults.Count() > 0)
                {
                    var vResult = res.ValidationResult.FirstOrDefault().OrderBetValidationResults.FirstOrDefault();
                    retVal.SetErrorResult(string.Format("Execute bet failed, error message = {0}", vResult.Message), (int)vResult.ValidationResult, vResult.Event);
                }
                else
                {
                    retVal.SetErrorResult("Execute bet failed", (int)res.Result.ErrorCode);
                }
            }            
            return retVal;
        }
        public PlaceBetsResponse PlaceBets(PlaceBetsRequest request)
        {
            var retVal = new PlaceBetsResponse();
            try
            {
                var serverResponse = BetChannel.RequestForOrder(RequestConvertor.ToOrderRequest(request));
                if (serverResponse.IsSuccessfull())
                {
                    // if timout == 0 call to execute order automaticly 
                    //if (serverResponse.Timeout == 0)
                    //{
                    //        retVal.ExecuteOrder =  ExecuteOrder(new ExecuteOrderRequest()
                    //        {
                    //            UserToken = request.UserToken,
                    //            OrderPrintTemplate = request.OrderPrintTemplate,
                    //            TerminalSecurityCode = request.TerminalSecurityCode,
                    //            TimeoutGuid = serverResponse.TimeoutGuid
                    //        }
                    //    );
                    //}
                    //else
                    //{
                    //    retVal = ResponseConvertor.ToPlaceBetsResponse(serverResponse);
                    //}
                    retVal = ResponseConvertor.ToPlaceBetsResponse(serverResponse);
                }
                else
                {
                    retVal.Result = new Model.Response.Base.Result();
                    if (serverResponse.ValidationResult != null && serverResponse.ValidationResult.Count() > 0 && serverResponse.ValidationResult[0].OrderBetValidationResults.Count() > 0)
                    {
                        var Changes = new List<OrderChange>();
                        foreach (var sel in request.Selections)
                        {

                            var eve = EventSingleton.Instance.GetEventByCk(sel.EventId.ToString());
                            if (eve != null && eve.BetTypes != null)
                            {
                                var betType = eve.BetTypes.FirstOrDefault(bt => bt.BetTypeData.Id == sel.BetTypeId && (bt.BetTypeData.Line ?? "") == (sel.OddLine ?? ""));
                                if (betType != null && betType.Odds != null)
                                {
                                    var odd = betType.Odds.FirstOrDefault(o => o.Name == sel.OddName);

                                    OrderChange change = new OrderChange(eve.EventData.Id, eve.EventData.EventStatus, betType.BetTypeData.Id, betType.BetTypeData.Status, betType.BetTypeData.Line, odd.Name, odd.Price,odd.Status);
                                    Changes.Add(change);
                                }
                            }
                            else// event not found
                            {
                                OrderChange change = new OrderChange(sel.EventId, Clients.EventsManager.Model.Entities.Enums.eEventStatus.Closed,sel.BetTypeId, Clients.EventsManager.Model.Entities.Enums.eBetStatus.Closed ,sel.OddLine, sel.OddName,sel.OddPrice, Clients.EventsManager.Model.Entities.Enums.eOddStatus.Closed);
                                Changes.Add(change);
                            }

                        }
                        var vResult = serverResponse.ValidationResult.FirstOrDefault().OrderBetValidationResults.FirstOrDefault();
                        retVal.SetErrorResult(string.Format("Place bet failed, error message = {0}", vResult.Message), (int)vResult.ValidationResult, Changes );

                    }
                    else
                        retVal.SetErrorResult(serverResponse.Result.ErrorDescription,(int)serverResponse.Result.ErrorCode);

                }

            }
            catch (Exception ex)
            {
                retVal.SetErrorResult("Request for order failed");
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;



        }
    }    
}
