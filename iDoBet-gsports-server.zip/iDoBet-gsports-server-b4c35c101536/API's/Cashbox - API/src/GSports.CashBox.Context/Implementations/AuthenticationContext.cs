﻿using GSports.CashBox.Context.Channel;
using GSports.CashBox.Context.Convertors;
using GSports.CashBox.Contracts;
using GSports.CashBox.Model.Request.AuthenticationService;
using GSports.CashBox.Model.Response.AuthenticationService;

namespace GSports.CashBox.Context.Implementations
{
    public class AuthenticationContext: IAuthenticationContext
    {

 
        public  LoginResponse LoginUser(LoginRequest request)
        {            
            var retVal = new LoginResponse();            
            var res = AuthenticationChannel.LoginUser(RequestConvertor.ToLoginRequest(request));
            retVal = ResponseConvertor.ToLoginUserResponse(res);
            return retVal;
        }

        public LogoutResponse LogoutUser(LogoutRequest request)
        { 
            var retVal = new LogoutResponse();
            var res = AuthenticationChannel.LogoutUser(RequestConvertor.ToLogoutRequest(request));
            //if (!res.IsSuccessfull())
            //    retVal.SetErrorResult(string.Format("Could not logout for token {0}", request.UserToken));
            retVal = ResponseConvertor.ToLogoutUseResponse(res);            
            return retVal;
        }

        public TerminalStatusResponse GetTerminalStatus(TerminalStatusRequest request)
        {
            var retVal = new TerminalStatusResponse();
            var res = AuthenticationChannel.GetTerminalStatus(RequestConvertor.ToTerminalStatusRequest(request));
            //if (!res.IsSuccessfull())
            //    retVal.SetErrorResult(string.Format("Could not get terminal status for terminal token {0}", request.TerminalSecurityCode));

            retVal = ResponseConvertor.ToTerminalStatusResponse(res);
            return retVal;
        }
        internal static TerminalStatusResponse ToClientResponse(GSports.Model.Responses.Authentication.TerminalStatusResponse res)
        {
            var retVal = new TerminalStatusResponse();
            // retVal.Branch = res.Branch;
            return retVal;

        }


        public RegisterTerminalResponse RegisterTerminal(RegisterTerminalRequest request)
        {
            var retVal = new RegisterTerminalResponse();
            var res = AuthenticationChannel.RegisterTerminal(RequestConvertor.ToRegisterTerminalRequest(request));
           
            if (!res.IsSuccessfull())
                retVal.SetErrorResult(res.Result.ErrorDescription,(int) res.Result.ErrorCode);
            return retVal;
        }

    
    }
}
