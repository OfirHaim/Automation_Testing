﻿using GSports.CashBox.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Response.EventService;
using GSports.Clients.EventsManager;
using GSports.Model.Consts;
using GSports.CashBox.Context.Helpers;
using GSports.CashBox.Model.Request.EventService;

namespace GSports.CashBox.Context.Implementations
{

   
    public class EventContext : IEventContext
    {      
        public GetEventsResponse GetEvents(GetEventsRequest reqeust)
        {
            GetEventsResponse retVal = new GetEventsResponse();

            if (EventSingleton.Instance != null)
            {
                DateTime? LastUpdate = null;
                if (reqeust.LastTimestamp.HasValue)
                     LastUpdate = DateTimeHelper.FromUnixTime(reqeust.LastTimestamp.Value);               
                retVal.LastTimestamp = DateTimeHelper.ToUnixTime(EventSingleton.Instance.LastUpdate);
                //retVal.ActiveCoupinIds = EventSingleton.Instance.ac
                var res = EventSingleton.Instance.GetEvents(LastUpdate, 
                                                            reqeust.ActiveCoupon, 
                                                            reqeust.CoupinIds, 
                                                            reqeust.EventIds,
                                                            reqeust.Skip,
                                                            reqeust.Take,
                                                            reqeust.BetTypeIds);
                if (res != null)
                {
                    retVal.ActiveCoupinIds = EventSingleton.Instance.ActiveCouponIds.ToList();
                    retVal.Events = res.ToList();
                    retVal.TotalEventCount = EventSingleton.Instance.EvnetCount;
                }
                else
                    retVal.SetErrorResult("Event cache is not ready!!!", (int)eErrorCode.CacheNotReady);                
            }
            else retVal.SetErrorResult("Event cache is not ready!!!", (int)eErrorCode.CacheNotReady);

            return retVal;
            
        }

        public GetEventsUpdatesResponse GetEventsUpdates(GetEventsUpdatesRequest reqeust)
        {
            GetEventsUpdatesResponse retVal = new GetEventsUpdatesResponse();

            if (EventSingleton.Instance != null)
            {
                DateTime? LastUpdate = null;
                if (reqeust.LastTimestamp.HasValue)
                    LastUpdate = DateTimeHelper.FromUnixTime(reqeust.LastTimestamp.Value);
                retVal.LastTimestamp = DateTimeHelper.ToUnixTime(EventSingleton.Instance.LastUpdate);
                //retVal.ActiveCoupinIds = EventSingleton.Instance.ac
                var res = EventSingleton.Instance.GetEventsUpdates(LastUpdate);
                if (res != null)
                {
                    if(EventSingleton.Instance.ActiveCouponIds!=null)
                        retVal.ActiveCoupinIds = EventSingleton.Instance.ActiveCouponIds.ToList();                   
                    retVal.UpdateMessages = res.ToList();
                }
                else
                    retVal.SetErrorResult("Event cache is not ready!!!", (int)eErrorCode.CacheNotReady);
            }
            else retVal.SetErrorResult("Event cache is not ready!!!", (int)eErrorCode.CacheNotReady);

            return retVal;
        }
    }
}
