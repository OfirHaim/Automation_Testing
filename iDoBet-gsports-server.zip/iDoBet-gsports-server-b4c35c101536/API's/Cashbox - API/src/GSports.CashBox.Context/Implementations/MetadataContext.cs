﻿using GSports.CashBox.Context.Channel;
using GSports.CashBox.Context.Convertors;
using GSports.CashBox.Contracts;
using GSports.CashBox.Model.Request.MetadataService;
using GSports.CashBox.Model.Response.MetadataService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace GSports.CashBox.Context.Implementations
{
    public class MetadataContext : IMetadataContext
    {
        public FileStreamResult DownloadCoupon(DownloadCouponRequest request)
        {
            FileStreamResult retVal = null;
            var stream = BetChannel.DownloadCoupon(RequestConvertor.ToDownloadRequest(request));
            if (stream != null)
                retVal = new FileStreamResult(stream, "application/ms-excel") { FileDownloadName = string.Format("coupon|{0}.xlsx", DateTime.Now.ToString("dd-MM")) };
            return retVal;
        }

        public GetBetTypesTemplateResponse GetBetTypeTemplate(GetBetTypesTemplateRequest request)
        {
            var retVal = new GetBetTypesTemplateResponse();
            var res = MetadataChannel.GetItems(RequestConvertor.ToGetItemsRequest(request));
            //if (!res.IsSuccessfull())
            //    retVal.SetErrorResult(string.Format("Could not get bet type template"));
            retVal = ResponseConvertor.ToGetBetTypesTemplateResponse(res);
            return retVal;
        }

        public GetCancelReasonTypeResponse GetCancelReasonTypes(GetCancelReasonTypeRequest request)
        {
            var retVal = new GetCancelReasonTypeResponse();
            var res = MetadataChannel.GetItems(RequestConvertor.ToGetItemsRequest(request));
            //if (!res.IsSuccessfull())
            //    retVal.SetErrorResult(string.Format("Could not get bet type template"));
            retVal = ResponseConvertor.ToGetCancelReasonTypeResponse(res);
            return retVal;
        }

        public GetCouponsResponse GetCoupons(GetCouponsRequest request)
        {
            var retVal = new GetCouponsResponse();
            var res = BetChannel.GetCoupon(RequestConvertor.ToGetCouponsRequest(request));
            retVal.CouponNames = res;
            return retVal;
        }

        public KeepAliveResponse KeepAliveTerminal(KeepAliveRequest request)
        {
            KeepAliveResponse retVal = new KeepAliveResponse();
            var res = MetadataChannel.KeepAliveTerminal(RequestConvertor.ToKeepAliveTerminalRequest(request));
            if (res.Result.ErrorCode == GSports.Model.Consts.eErrorCode.Success)
                retVal.KeepAlive = true;
            else
                retVal.KeepAlive = false;
            return retVal;
        }
    }
}
