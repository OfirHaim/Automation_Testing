﻿using GSports.CashBox.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Request.FinanceService;
using GSports.CashBox.Model.Request.AuthenticationService;
using GSports.CashBox.Model.Response.FinanceService;
using GSports.CashBox.Context.Channel;
using GSports.CashBox.Context.Convertors;
using GSports.CashBox.Model.Consts;

namespace GSports.CashBox.Context.Implementations
{
    public class FinanceContext : IFinanceContext
    {
        public DepositResponse CreateDeposit(DepositRequest request)
        {
            var retVal = new DepositResponse();
            var res = FinanceChannel.InsertDeposit(RequestConvertor.ToInsertDepositRequest(request));
            //if (!res.IsSuccessfull())
            //    retVal.SetErrorResult(string.Format("Could not get order data"));

            //// Get Terminal name and Brnach name from user token and Terminal security code to get data for deposit reciept
            ////--------------------------------------------------------------------------------
            //TerminalStatusRequest terminalStatusRequest = new TerminalStatusRequest();
            //terminalStatusRequest.TerminalSecurityCode = request.TerminalSecurityCode;
            //terminalStatusRequest.UserToken = request.UserToken;
            //AuthenticationContext bl = new AuthenticationContext();
            //var terminalStatusResponse =  bl.GetTerminalStatus(terminalStatusRequest);
            //// -------------------------------------------------------------------------------

            retVal = ResponseConvertor.ToDepositResponse(res, request);
            return retVal;
        }

        public GetTransactionsResponse GetTransactions(GetTransactionsRequest request)
        {
            var retVal = new GetTransactionsResponse();
            var res = FinanceChannel.GetTransactions(RequestConvertor.ToGetTransactionsRequest(request));
            retVal = ResponseConvertor.ToGetTransactionResponse(res);
            return retVal;
        }

        public UpdateWithdrawResponse UpdateWithdraw(UpdateWithdrawRequest request)
        {
            var retVal = new UpdateWithdrawResponse();
            var GetTransfersResponse = FinanceChannel.GetTransfers(new GSports.Model.Requests.Finance.GetTransfersRequest() { Filter = new GSports.Model.Filter.TransferFilter() { TransferCode = request.Code }, UserToken = request.UserToken });
            if (!(GetTransfersResponse.Transfers != null && GetTransfersResponse.Transfers.Count == 1))
            {
                retVal.SetErrorResult("Withdraw code not found", (int)eApiErrorCode.WithdrawCodeNotFound);

            }
            else if (GetTransfersResponse.Transfers[0].FromAccount.User.Id != request.ToUserId)
            {
                retVal.SetErrorResult("User id not match to code", (int)eApiErrorCode.WithdrawUserIdNotMatchToCode);
            }
            else
            {
                var res = FinanceChannel.CommitWithdraw(RequestConvertor.ToCommitWithdrawRequest(request));
                retVal = ResponseConvertor.ToUpdateWithdrawResponse(res, request);
            }
            return retVal;
        }

        public GetTransfersResponse GetTransfers(GetTransfersRequest request)
        {
            var retVal = new GetTransfersResponse();
            var res = FinanceChannel.GetTransfers(RequestConvertor.ToGetTransfersRequest(request));
            retVal = ResponseConvertor.ToGetTransfersResponse(res);
            return retVal;
        }

        public CreateTransferResponse CreateTransfer(CreateTransferRequest request)
        {
            var retVal = new CreateTransferResponse();
            var res = FinanceChannel.InsertTransfer(RequestConvertor.ToCreateTransfersRequest(request));
            retVal = ResponseConvertor.ToGetTransfersResponse(res);
            return retVal;
        }

        public UpdateTransferResponse UpdateTransfer(UpdateTransferRequest request)
        {
            var retVal = new UpdateTransferResponse();
            var res = FinanceChannel.UpdateTransfer(RequestConvertor.ToUpdateTransfersRequest(request));
            retVal = ResponseConvertor.ToGetTransfersResponse(res);
            return retVal;
        }

        public GetReportsResponse GetReports(GetReportsRequest request)
        {
            GetReportsResponse retVal = new GetReportsResponse();
            var res = FinanceChannel.GetReports(RequestConvertor.ToGetReports(request));
            retVal = ResponseConvertor.ToGetReports(res);
            return retVal;
        }
    }
}
