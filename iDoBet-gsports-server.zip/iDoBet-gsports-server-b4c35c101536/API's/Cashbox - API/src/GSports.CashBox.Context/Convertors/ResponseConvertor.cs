﻿using GSports.Common.RecieptHelper;
using GSports.GLogger;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Response.FinanceService;
using GSports.Model.Responses.Reports;

namespace GSports.CashBox.Context.Convertors
{
    public static  class ResponseConvertor
    {
        #region UserService

      
        internal static GSports.CashBox.Model.Response.UserService.GetUsersResponse ToGetUsersResponse(GSports.Model.Responses.UserService.GetUsersResponse res, GSports.Model.Responses.Shifts.GetShiftDataResponse resShiftData)
        {
            var retVal = new GSports.CashBox.Model.Response.UserService.GetUsersResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Users = ModelConvertor.ToClientUsers(res.Users.Select(u=>(GSports.Model.Entities.User.OperatorUser)u).ToList(), resShiftData !=null ? resShiftData.ShiftData :null);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To Get User Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

    
        internal static GSports.CashBox.Model.Response.Shifts.StartShiftResponse ToStartShiftResponnse(GSports.Model.Responses.Shifts.StartShiftResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.Shifts.StartShiftResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Shift = ModelConvertor.ToClientShift(res.Shift);                                       
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To Start Shift Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

       
        internal static GSports.CashBox.Model.Response.Shifts.StartUserShiftResponse ToStartUserShiftResponse(GSports.Model.Responses.Shifts.StartUserShiftResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.Shifts.StartUserShiftResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.UserShiftId = res.UserShiftId;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To Start User Shift Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

     

        internal static GSports.CashBox.Model.Response.Shifts.StopUserShiftResponse ToStopUserShiftResponse
            (GSports.Model.Responses.Shifts.StopUserShiftResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.Shifts.StopUserShiftResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    if (res.ShiftResult == GSports.Model.Consts.Shift.eShiftResponseResult.Success)
                        return retVal;
                    else
                    {
                        retVal.SetErrorResult(res.ShiftResult.ToString());
                        return retVal;
                    }

                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To Stop User Shift Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

        internal static GetReportsResponse ToGetReports(GetAccountReportSummaryResponse res)
        {
            var retVal = new GetReportsResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Reports = ModelConvertor.ToClientAccountReports(res);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To Get Reports Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }



        //internal static GSports.CashBox.Model.Response.UserService.GetBranchUsersResponse ToGetBranchUsersResponse(GSports.Model.Responses.UserService.GetUsersResponse resBranchUsers,  GSports.Model.Responses.Shifts.GetShiftDataResponse resShiftData)
        //{
        //    var retVal = new GSports.CashBox.Model.Response.UserService.GetBranchUsersResponse();
        //    try
        //    {                
        //        if (IsServerResponseSuccessfull(retVal, resBranchUsers))
        //        {
        //            retVal.UserShifts = new List<Model.Entities.Shifts.UserShift>();
        //            foreach (var user in resBranchUsers.Users)
        //            {
        //                GSports.Model.Entities.Shifts.ShiftData shiftData = null;
        //                if ( resShiftData  != null && resShiftData.ShiftData !=null)
        //                     shiftData = resShiftData.ShiftData.SingleOrDefault(x => x.UserId == user.Id);                                            
        //                retVal.UserShifts.Add(ModelConvertor.ToClientUserShift(user,null,shiftData));
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //    }
        //    return retVal;
        //}

        internal static Model.Response.UserService.GetAllowedContactsResponse GetAllowedContactsRequest(GSports.Model.Responses.Finance.GetTransferContactResponse res)
        {
            var retVal = new Model.Response.UserService.GetAllowedContactsResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Users = new List<Model.Entities.User.BaseUserData>();
                    res.UserContacts.ForEach(x => retVal.Users.Add(new Model.Entities.User.BaseUserData(x.Id.ToString(), x.FirstName, x.LastName, x.UserName)));
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Get Allowed Contacts Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

        internal static GSports.CashBox.Model.Response.Shifts.StopShiftResponse ToStopShiftResponse
           (GSports.Model.Responses.Shifts.StopShiftResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.Shifts.StopShiftResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    if (res.ShiftResult == GSports.Model.Consts.Shift.eShiftResponseResult.Success)
                        return retVal;
                    else
                    {
                        retVal.SetErrorResult(res.ShiftResult.ToString());
                        return retVal;
                    }

                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To Stop Shift Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

        internal static GSports.CashBox.Model.Response.Shifts.GetCurrentShiftResponse ToGetShiftDataResponse
            (GSports.Model.Responses.Shifts.GetShiftDataResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.Shifts.GetCurrentShiftResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    
                    retVal.UserShiftsData = ModelConvertor.ToClientUserShiftData(res); 
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To Start Shift Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

        #endregion

        #region AuthenticationService
        internal static Model.Response.AuthenticationService.TerminalStatusResponse ToTerminalStatusResponse(GSports.Model.Responses.Authentication.TerminalStatusResponse res)
        {

            var retVal = new Model.Response.AuthenticationService.TerminalStatusResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Branch = ModelConvertor.ToClientBranch(res.Branch);
                    retVal.User = ModelConvertor.ToClientUser(res.User);
                    retVal.Terminal = ModelConvertor.ToClientTerminal(res.Terminal);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Terminal status convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;

        }

        internal static GSports.CashBox.Model.Response.AuthenticationService.LoginResponse ToLoginUserResponse(GSports.Model.Responses.Authentication.LogInResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.AuthenticationService.LoginResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Token = res.Token;
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(string.Format("Login Falied {0}", ex.Message));
            }
            return retVal;
        }

        internal static GSports.CashBox.Model.Response.AuthenticationService.LogoutResponse ToLogoutUseResponse(GSports.Model.Responses.Authentication.LogoutResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.AuthenticationService.LogoutResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {

                }

            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Logout convertor failed, ex = {0}", ex.Message));
            }

            return retVal;
        }
        #endregion

        #region FinanceService
        internal static Model.Response.FinanceService.DepositResponse ToDepositResponse
            (GSports.Model.Responses.Finance.InsertDepositResponse res,
            GSports.CashBox.Model.Request.FinanceService.DepositRequest request)
        {
            var retVal = new Model.Response.FinanceService.DepositResponse();
            try
            {
             
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    if(request.printParams != null && res.DepositData.Code != null)
                    {
                        DepositHTMLRequest depositRequest = new DepositHTMLRequest(request.UserToken, request.printParams.TerminalName, request.printParams.BranchName, 
                            request.printParams.CashierName, request.printParams.CustomerId, res.DepositData.Code, request.Amount.ToString(), res.DepositData.CreateTime, 
                            request.Language, request.printParams.Currency, request.DepositPrintTemplate);
                        retVal.UrlKey = PrintService.GetDepositWithdrawKey(depositRequest);
                    }
                    retVal.DepositCode = res.DepositData.Code;
                    retVal.TransferId = res.DepositData.Id;
                    retVal.Amount = res.DepositData.RequestAmount;
                }

            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Deposit convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

        internal static Model.Response.FinanceService.GetTransactionsResponse ToGetTransactionResponse(GSports.Model.Responses.Finance.GetTransactionsResponse res)
        {
            var retVal = new Model.Response.FinanceService.GetTransactionsResponse();
            retVal.Transactions = new List<Model.Entities.Finance.Transaction>();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Transactions = ModelConvertor.ToClientTransactions(res);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Get Transaction Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

        internal static Model.Response.FinanceService.GetTransfersResponse ToGetTransfersResponse
          (GSports.Model.Responses.Finance.GetTransfersResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.FinanceService.GetTransfersResponse();
            retVal.Transfers = new List<Model.Entities.Finance.Transfer>();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Transfers = ModelConvertor.ToClientTransfers(res.Transfers);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Get Transfers Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

        internal static Model.Response.FinanceService.UpdateTransferResponse ToGetTransfersResponse
  (GSports.Model.Responses.Finance.UpdateTransferResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.FinanceService.UpdateTransferResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Get Transfers Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

        internal static Model.Response.FinanceService.CreateTransferResponse ToGetTransfersResponse
  (GSports.Model.Responses.Finance.InsertTransferResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.FinanceService.CreateTransferResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))                
                    retVal.NewId = res.NewId;
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Get Transfers Response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }

        internal static GSports.CashBox.Model.Response.FinanceService.UpdateWithdrawResponse ToUpdateWithdrawResponse
            (GSports.Model.Responses.Finance.CommitWithdrawResponse res,
            GSports.CashBox.Model.Request.FinanceService.UpdateWithdrawRequest request)
        {
            var retVal = new GSports.CashBox.Model.Response.FinanceService.UpdateWithdrawResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    if (request.printParams != null)
                    {                        
                        WithdrawHTMLRequest withdrawRequest = new WithdrawHTMLRequest(request.UserToken, request.printParams.TerminalName, request.printParams.BranchName, request.printParams.CashierName, request.printParams.CustomerId, res.WithdrawData.ResponseAmount.ToString(), res.WithdrawData.ResponseTime, request.Language, request.printParams.Currency, request.WithdrawPrintTemplate);
                        //retVal.Code = res.WithdrawData.Code;
                        retVal.UrlKey = PrintService.GetDepositWithdrawKey(withdrawRequest);
                    }
                    retVal.TransferId = res.WithdrawData.Id;
                    retVal.Amount = res.WithdrawData.ResponseAmount;


                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To Update Withdraw convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }
        #endregion

        #region MetadataService
        internal static GSports.CashBox.Model.Response.MetadataService.GetCancelReasonTypeResponse ToGetCancelReasonTypeResponse(GSports.Model.Responses.Metadata.GetItemsResponse res)
        {

            var retVal = new Model.Response.MetadataService.GetCancelReasonTypeResponse();
            retVal.CancelReasonTypes = new List<Model.Entities.CancelReasonType>();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    var cancelReasonTypes = res.Items.ConvertAll(x => (GSports.Model.Entities.Order.CancelReasonType)x);
                    foreach (var ct in cancelReasonTypes)
                    {
                        retVal.CancelReasonTypes.Add(new Model.Entities.CancelReasonType(ct.Id, ct.Name) { Desc = ct.Desc });
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("GetCancelReasonType  convertor failed, ex = {0}", ex.Message));
            }
            return retVal;

        }

        internal static Model.Response.MetadataService.GetBetTypesTemplateResponse ToGetBetTypesTemplateResponse(GSports.Model.Responses.Metadata.GetItemsResponse res)
        {
            var retVal = new Model.Response.MetadataService.GetBetTypesTemplateResponse();
            retVal.BetTypesSchema = new List<Model.Entities.BetTypeTemplate>();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    var betTypes = res.Items.ConvertAll(x => (GSports.Model.Entities.BetType)x);

                    foreach (var bt in betTypes.OrderByDescending(x => x.Order.HasValue).ThenBy(x => x.Order))
                    {
                        Model.Entities.BetTypeTemplate btSchema = new Model.Entities.BetTypeTemplate(bt.Id, bt.ToString(), bt.IsLive, bt.SportType.Id, false, false);
                        btSchema.Odds = new List<List<Model.Entities.OddTemplate>>();
                        bt.Odds.OrderBy(x => x.OrderRow).GroupBy(x => x.OrderRow).ToList().ForEach(x =>
                        {
                            var rowOdds = new List<Model.Entities.OddTemplate>();
                            x.OrderBy(o => o.OrderCol).ToList().ForEach(f => rowOdds.Add(new Model.Entities.OddTemplate(f.ToString()) { Shortcut = f.Shortcut }));
                            btSchema.Odds.Add(rowOdds);
                        });
                        retVal.BetTypesSchema.Add(btSchema);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Bet type template convertor failed, ex = {0}", ex.Message));
            }
            return retVal;

        }

       
        #endregion

        #region BetService
        internal static GSports.CashBox.Model.Response.BetService.GetOrderDataResponse ToGetOrderDataResponse(GSports.Model.Responses.Order.GetOrdersDataResponse res, string userToken,
            string template,int? width, string language, bool forPrint)
        {
            var retVal = new GSports.CashBox.Model.Response.BetService.GetOrderDataResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Order = ModelConvertor.ToClientOrders(res.Orders, userToken, template, width,language, forPrint).FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Get order data convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }   
        internal static GSports.CashBox.Model.Response.BetService.PlaceBetsResponse ToPlaceBetsResponse(GSports.Model.Responses.Order.OrderResponse res)
        {
            var retVal = new Model.Response.BetService.PlaceBetsResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    retVal.Timeout = res.Timeout;
                    retVal.TimeoutGuid = res.TimeoutGuid;
                }
                else
                {
                    if (res.ValidationResult != null&& res.ValidationResult.Count()>0 && res.ValidationResult[0].OrderBetValidationResults.Count()>0)
                        retVal.SetErrorResult("Place bet failed", (int)res.ValidationResult.FirstOrDefault().OrderBetValidationResults.FirstOrDefault().ValidationResult);
                }

            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Place bet convertor failed, ex = {0}", ex.Message));
            }

            return retVal;

        }

        internal static GSports.CashBox.Model.Response.BetService.ExecuteOrderResponse ToExecuteOrderResponse(GSports.Model.Responses.Order.ExecuteOrderResponse res, 
            string userToken, string template, int? width,string language)
        {
            var retVal = new Model.Response.BetService.ExecuteOrderResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                    var orderList = new List<GSports.Model.Entities.OrderEntity>();
                    orderList.Add(res.NewOrder);              
                    retVal.Order = ModelConvertor.ToClientOrders(orderList, userToken, template, width,language, true).FirstOrDefault();
                }
                else
                {
                    if (res.ValidationResult != null && res.ValidationResult.Count() > 0 && res.ValidationResult[0].OrderBetValidationResults.Count() > 0)
                        retVal.SetErrorResult("Execute bet failed", (int)res.ValidationResult.FirstOrDefault().OrderBetValidationResults.FirstOrDefault().ValidationResult);
                }

            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("Place bet convertor failed, ex = {0}", ex.Message));
            }

            return retVal;

        }
        //internal static Model.Response.BetService.PlaceBetsResponse ToPlaceBetsResponse(GSports.Model.Responses.Order.OrderResponse res)
        //{

        //    var retVal = new Model.Response.BetService.PlaceBetsResponse();
        //    try
        //    {
        //        if (IsServerResponseSuccessfull(retVal, res))
        //        {
        //            //Will always be an error for this converter 
        //        }
        //        else
        //        {
        //            string validationResult = string.Empty;
        //            if (res.ValidationResult != null)
        //                res.ValidationResult.ForEach(r => r.OrderBetValidationResults.ForEach(vr => validationResult += string.Format("(error:{0} - {1})", vr.ValidationResult.ToString(), vr.Message)));
        //            retVal.Result.ErrorDescription += string.Format("Order execution failed! validationResult = {0}", validationResult);
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
        //        retVal.SetErrorResult(string.Format("Place bet convertor failed, ex = {0}", ex.Message));
        //    }

        //    return retVal;
        //}

        internal static Model.Response.BetService.DoPayoutResponse ToDoPayoutResponse(GSports.Model.Responses.Order.DoPayoutResponse res)
        {
            var retVal = new GSports.CashBox.Model.Response.BetService.DoPayoutResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                   
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To do payout response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }
        internal static Model.Response.BetService.CancelOrderResponse ToCancelOrderResponse(GSports.Model.Responses.Order.CancelOrderResponse res)
        {
            var retVal = new Model.Response.BetService.CancelOrderResponse();
            try
            {
                if (IsServerResponseSuccessfull(retVal, res))
                {
                   
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(string.Format("To cancel order response convertor failed!!!, ex = {0}", ex.Message));
            }
            return retVal;
        }
        #endregion

        #region Halper
        static bool IsServerResponseSuccessfull(GSports.CashBox.Model.Response.Base.BaseResponse clientResponse, GSports.Model.Responses.BaseResponse serverResponse)
        {
            bool retVal = true;
            if (!serverResponse.IsSuccessfull())
            {
                retVal = false;
                clientResponse.SetErrorResult(serverResponse.Result.ErrorDescription,(int) serverResponse.Result.ErrorCode);
            }
            return retVal;
        }
        #endregion















    }
}
