﻿using GSports.CashBox.Model.Consts;
using GSports.CashBox.Model.Entities;
using GSports.CashBox.Model.Entities.Bet;
using GSports.CashBox.Model.Entities.Order;
using GSports.CashBox.Model.Response.Base;
using GSports.Clients.EventsManager.Model.Entities;
using GSports.Clients.EventsManager.Model.Entities.Enums;
using GSports.Common.RecieptHelper;
using System;
using System.Collections.Generic;
using System.Linq;
using GSports.CashBox.Model.Entities.Shifts;
using GSports.Model.Responses.Shifts;
using GSports.Model.Responses.Finance;
using GSports.Model.Entities.Finance;
using GSports.CashBox.Model.Entities.User;
using GSports.Common;
using GSports.CashBox.Model.Entities.Finance;
using GSports.Model.Responses.Reports;

namespace GSports.CashBox.Context.Convertors
{
    public static class ModelConvertor
    {
        #region To Clients         

        #region User       
        public static List<UserEntity> ToClientUsers(List<GSports.Model.Entities.User.OperatorUser> users, List<GSports.Model.Entities.Shifts.ShiftData> shiftsData )
        {
            List<UserEntity> retVal = null;
            try
            {
                retVal = new List<UserEntity>();
                foreach (GSports.Model.Entities.User.OperatorUser user in users)
                {
                    var tempUser = new UserEntity();
                    tempUser.Data = ToClientUserData(user);
                    GSports.Model.Entities.Shifts.ShiftData shiftData = null;
                    if (shiftsData != null)
                    {
                        shiftData = shiftsData.FirstOrDefault(s => s.UserId == user.Id);
                    }
                   
                    tempUser.CurrentShift = ToClientUserShift(user.CurrentShift, shiftData);
                    if(tempUser.CurrentShift!=null &&  user.Transfers!=null && user.Transfers.Count >0)
                        tempUser.CurrentShift.HasCloseShiftRequest = user.Transfers.Any(t =>t.ToAccount.User.Id == int.Parse(tempUser.Data.Id) 
                                                                                        && t.ResponseType.CodeAttribute == Common.CodeAttribute.TransferResponseType.Pending
                                                                                        && t.RequestType.CodeAttribute == Common.CodeAttribute.TransferRequestType.CloseShift);
                    tempUser.Permissions = ToClientPermissionMatrix(user.PermissionMatrix);
                    retVal.Add(tempUser);
                }
            }
            catch { }
            return retVal;
        }
       
        public static BaseUserData ToClientUser(GSports.Model.Entities.User.BasicUser userEnitity)
        {
            BaseUserData retVal = null;
            try
            {
                retVal = new BaseUserData(userEnitity.Id.ToString(), userEnitity.UserName, userEnitity.FirstName, userEnitity.LastName);

            }
            catch { }
            return retVal;
        }

        public static UserData ToClientUserData(GSports.Model.Entities.User.SystemUser userEnitity)
        {
            UserData retVal = null;
            try
            {                
                if (userEnitity is GSports.Model.Entities.User.OperatorUser)
                {
                    
                    var operatorUser = userEnitity as GSports.Model.Entities.User.OperatorUser;
                    retVal = new UserData(operatorUser.Id.ToString(), operatorUser.UserName, operatorUser.FirstName, operatorUser.LastName);
                    retVal.IsActivated = operatorUser.Enabled;                 
                    retVal.Address = operatorUser.Address;
                    retVal.Email = operatorUser.Email;
                    retVal.Phone = operatorUser.Phone;                    
                    retVal.Currency = ToClientCurrency(operatorUser.GetCurrency());
                    retVal.AccountId = operatorUser.AccountId;
                    retVal.Balance = operatorUser.Balance;
                    retVal.Commission = operatorUser.Commission;
                    retVal.Holding = operatorUser.Holding;
                    retVal.CreditLimit = operatorUser.ActualCreditLimit;
                    retVal.MinBet = operatorUser.MinBet;
                    retVal.MaxBet = operatorUser.MaxBet;
                    retVal.MaxPayout = operatorUser.MaxPayout;
                    retVal.BranchBalance = operatorUser.BranchBalance;
                    if (operatorUser.Roles!=null)
                    {
                        retVal.Roles = new List<eRole>();
                        foreach (var role in operatorUser.Roles)
                        {
                            if (Enum.IsDefined(typeof(eRole), role.Id))
                                retVal.Roles.Add((eRole)role.Id);

                        }

                    }
                         
                    if (operatorUser.LastAccess != null && operatorUser.LastAccess.Token != null)
                         retVal.Token = operatorUser.LastAccess.Token.ToString();
                   
                }

            }
            catch { }

            return retVal;
        }

   

        internal static ShiftEntity ToClientShift(GSports.Model.Entities.Shifts.ShiftEntity res)
        {
            ShiftEntity retVal = null;
            try
            {
                if (res.ManagerId.HasValue)
                {                    
                    retVal = new ShiftEntity(res.ManagerId.Value, res.Name);
                    retVal.StartTime = res.StartTime;
                    List<UserShift> userShiftList = new List<UserShift>();
                    res.UsersInShift.ForEach(x => userShiftList.Add(ToClientUserShift(userShift:x)));
                    retVal.UserInShift = userShiftList;
                    retVal.Name = res.Name;
                    retVal.BranchId = res.BranchId;
                    retVal.Id = res.Id.ToString();                    
                    retVal.ManagerId = res.ManagerId;
              
                }

            }
            catch { }
            return retVal;
        }

        private static UserShift ToClientUserShift(GSports.Model.Entities.Shifts.ShiftUser userShift , GSports.Model.Entities.Shifts.ShiftData dataShift = null)
        {
            UserShift retVal = null;
        
            try
            {
                retVal = new UserShift(userShift.ShiftId, userShift.User.UserName);                       
                retVal.FirstName =userShift.User.FirstName;
                retVal.LastName =  userShift.User.LastName;
                retVal.UserId =  userShift.User.Id;               
                retVal.AccessId = userShift.AccessId;
                retVal.StartTime = userShift.StartTime;
                retVal.EndTime = userShift.EndTime;                 
                //retVal.OrderCount = userShift.OrderCount;
                retVal.OpenBalance = userShift.OpenBalance;
                retVal.OpenHoldings = userShift.OpenHoldings;
                retVal.CloseBalance = userShift.CloseBalance;
                retVal.CloseHoldings = userShift.CloseHoldings;
                retVal.ShiftId = userShift.ShiftId;


                if (dataShift != null)
                {
                    retVal.ShiftData = new UserShiftData();
                    retVal.ShiftData.OrderCanceledCount = dataShift.OrderCanceledCount;
                    retVal.ShiftData.OrderCount = dataShift.OrderCount;
                    retVal.ShiftData.PayoutCount = dataShift.PayoutCount;
                    retVal.ShiftData.ShiftId = dataShift.ShiftId;
                    retVal.ShiftData.TotalCanceled = dataShift.TotalCanceled;
                    retVal.ShiftData.TotalOrdersCount = dataShift.TotalOrdersCount;
                    retVal.ShiftData.TotalSale = dataShift.TotalSale;
                    retVal.ShiftData.UserId = dataShift.UserId;
                    retVal.ShiftData.TotalPayout = dataShift.TotalPayout;
                }
                // id data shift is null collect the data from shift
                else
                {
                    retVal.ShiftData = new UserShiftData();
                    retVal.ShiftData.OrderCount = userShift.OrderCount;
                    retVal.ShiftData.ShiftId = userShift.ShiftId;
                    retVal.ShiftData.UserId = userShift.User.Id;



                }
            }
            catch { }
            return retVal;
        }

        internal static List<UserShiftData> ToClientUserShiftData(GetShiftDataResponse res)
        {
            List<UserShiftData> UserShiftsData = new List<UserShiftData>();
            try
            {
                res.ShiftData.ForEach(x => UserShiftsData.Add(new UserShiftData()
                {
                    OrderCanceledCount = x.OrderCanceledCount,
                    OrderCount = x.OrderCount,
                    PayoutCount = x.PayoutCount,
                    ShiftId = x.ShiftId,
                    TotalCanceled = x.TotalCanceled,
                    TotalOrdersCount = x.TotalOrdersCount,
                    TotalPayout = x.TotalPayout,
                    TotalSale = x.TotalSale,
                    UserId = x.UserId
                }));
            }
            catch { }
            return UserShiftsData;
        }

        internal static List<Permission> ToClientPermissionMatrix(Dictionary<string, GSports.Model.Consts.Security.ePermissionsLevel> permissions)
        {
            List<Permission> retVal = null;
            try
            {
                if (permissions != null)
                {
                    retVal = new List<Permission>();

                    foreach (var permission in permissions)
                    {
                        Permission p = new Permission(permission.Key, (ePermissionsLevel)permission.Value);
                        retVal.Add(p);
                    }
                }
                

            }
            catch { }
            return retVal;
        }
        #endregion

        #region Branch
        public static Branch ToClientBranch(GSports.Model.Entities.LocalSystemMetaData.Branch branch)
        {
            Branch retVal = null;
            try
            {
                retVal = new Branch(branch.Id, branch.Name);
                retVal.Currency = ToClientCurrency(branch.Currency);
            }
            catch { }
            return retVal;
        }
        #endregion

        #region Terminal 
        public static Terminal ToClientTerminal(GSports.Model.Entities.LocalSystem.Terminal terminal)
        {
            Terminal retVal = null;
            try
            {
                retVal = new Terminal(terminal.Id, terminal.Name);
                retVal.IsActive = terminal.IsActive;
                retVal.IsDeleted = terminal.IsDeleted;
            }
            catch { }
            return retVal;
        }

       
        #endregion

        #region Currency
        public static Currency ToClientCurrency(GSports.Model.Entities.LocalSystem.Currency currency)
        {
            Currency retVal = null;
            try
            {
                retVal = new Currency(currency.Id, currency.Name);
            }
            catch { }

            return retVal;
        }
        #endregion

        #region Order

        public static List<Order> ToClientOrders(List<GSports.Model.Entities.OrderEntity> orders, string userToken, string template = null, int? width = null, string language = "",  bool forprint = false)
        {
            List<Order> retVal = null;
            try
            {
                retVal = new List<Order>();

                orders.ToList().ForEach(x => retVal.Add(new Order()
                {
                    Id = x.Id,
                    Amount = x.Amount,
                    Barcode = x.Barcode,
                    CreationTime = x.CreateTime,
                    CurrencyId = x.OrderCurrency.Id,
                    CurrencyName = x.OrderCurrency.Name,
                    ExpiryDate = x.ExpiryDate,
                    ExternalId = x.ExternalId,                    
                    MaxPayout = x.NakedPayout,                   
                    NetPayout = x.NakedPayout + (x.TotalBonus??0)- (x.TotalTax??0),
                    OrderNumber = x.OrderNumber,
                    OrderProd = (eOrderProd)x.OrderProd,
                    OrderRows = ToClientOrderRows(x.OrderRows),
                    RequestGuid = x.RequestGuid,
                    SettledTime = x.SettledTime,
                    SoldTime = x.SoldTime,
                    Status = (eOrderStatus)x.Status,
                    TransactionId = x.TransactionId,
                    UserId = (int)x.Id,
                    UserName = x.Name,
                    WinStatus = (eWinStatus)x.WinStatus,
                    Payout = x.ActualPayout,                  
                    UrlKey = PrintService.GetOrderKey(userToken, x.RequestGuid, forprint, width: width, template: template,language: language),
                    CancelTimePossibile = x.CancelTimePossibile,
                    IsPayoutPossibile = x.IsPayoutPossibile,
                    TotalTax = x.TotalTax,
                    TotalBonus = x.TotalBonus,
                    TotalBonusDescription = x.BonusDesc,
                    TotalTaxDescription = x.TaxDesc,
                    TotalSelections =x.TotlaSelection,
                    TotalLines = x.TotlaLines

                }));
            }
            catch { }

            return retVal;
        }

        private static List<OrderRow> ToClientOrderRows(List<GSports.Model.Entities.Order.OrderRowEntity> orderRows)
        {
            var retVal = new List<OrderRow>();

            if (orderRows != null)
            {
                orderRows.ForEach(x => retVal.Add(new OrderRow()
                {
                    Amount = x.Amount,
                    Id = x.Id,
                    OrderId = x.OrderId,
                    WinStatus = (eWinStatus)x.WinStatus,
                    Bets = ToClientOrderBet(x.Bets),
                    BonusAmount = x.BonusAmount,
                    TaxAmount = x.TaxAmount,
                }));
            }
            return retVal;
        }

       

        private static List<OrderBet> ToClientOrderBet(List<GSports.Model.Entities.OrderBet> bets)
        {
            var retVal = new List<OrderBet>();
            var listOfSportEvent = new List<GSports.Model.Entities.Event.SportGame>();
            bets.ForEach(x => listOfSportEvent.Add(x.Event));
            var eventList = ToClientEvents(listOfSportEvent);
            string scoreTxt = string.Empty;
            bets.ForEach(x => retVal.Add(new OrderBet()
            {
               
                Id = x.Id,
                OrderId = x.OrderId,
                OrderRowId = x.OrderRowId,
                LiveInfo = x.LiveInfo,
                BetInfo = x.BetInfo + " " + ((x.Event.Scores == null) ? "" : string.Join(" ", x.Event.Scores.ToList().Select(e => (e.Value == null) ? "" : string.Format("{0}: {1}-{2} ", e.Key.ToEnumString(), e.Value.HomeScore, e.Value.AwayScore)))),
                WinStatus =(eWinStatus)x.Odd.WinStatus
                
            }));
            for (int i = 0; i < bets.Count; i++)
            {
                retVal[i].Event = eventList[i];
            }
            return retVal;
        }





        #endregion

        #region Event
        public static List<Event> ToClientEvents(List<GSports.Model.Entities.Event.SportGame> sportGames)
        {
            List<Event> retVal = new List<Event>();

            sportGames.ForEach(x =>
            {
                var betTypes = new List<BetType>();
                x.BetTypes.ForEach(bt =>
                {
                    bt.Odds.GroupBy(g => g.Line).ToList().ForEach(gbt =>
                    {
                        var odds = new List<Odd>();
                        gbt.ToList().ForEach(od =>
                        {
                            odds.Add(new Odd()
                            {
                                Name = od.Name,
                                ShortName = od.ShortName,
                                Price = od.CurrentPrice,
                                Status = (eOddStatus)od.status,
                                BettingTypeId = od.BettingTypeId,
                                Shortcut = od.Shortcut,
                                LastUpdate = od.LastUpdate,
                            });
                        });
                        betTypes.Add(new BetType()
                        {
                            BetTypeData = new BetTypeData()
                            {
                                Id = bt.Id,
                                Name = bt.Name,
                                ShortName = bt.ShortName,
                                Status = odds.All(a => a.Status == eOddStatus.Closed) ? eBetStatus.Closed : (eBetStatus)bt.BetStatus,
                                Line = gbt.First().Line,
                                LastUpdate = bt.LastUpdate,
                            },
                            Odds = odds
                        });
                    });
                });
                retVal.Add(new Event()
                {
                    EventData = new EventData()
                    {
                        Id = x.Id,
                        LastUpdate = x.LastUpdate,
                        Country = new EventCountry() { Id = x.Country.Id, Name = x.Country.Name, ShortName = x.Country.ShortName },
                        League = new League() { Id = x.League.Id, Name = x.League.Name, ShortName = x.League.ShortName },
                        HomeTeam = x.HomeTeam == null? null: new Team() { Id = x.HomeTeam.Id, Name = x.HomeTeam.Name, ShortName = x.HomeTeam.ShortName },
                        AwayTeam = x.AwayTeam == null ? null :  new Team() { Id = x.AwayTeam.Id, Name = x.AwayTeam.Name, ShortName = x.AwayTeam.ShortName },
                        EventState = (eEventState)x.CurrentState,
                        EventStatus = (eEventStatus)x.EventStatus,
                        GameTime = x.EventDate,
                        GameNumber = x.GameNumber.ToString(),
                        SportType = new SportType() { Id = x.SportType.Id, Name = x.SportType.Name },
                        CouponId = x.CurrentCouponId,
                        IsBookedForLive = x.IsBooked,  
                        IsActive = x.IsActive,                                                             
                        Live = x.EventStatus == GSports.Model.Consts.eEventStatus.Live ? new LiveData()
                        {
                            Score = new SimpleTwoSidesScore()
                            {
                                HomeScore = x.LiveProps.CurrentScore.HomeScore,
                                AwayScore = x.LiveProps.CurrentScore.AwayScore
                            },
                            CurrentTime = x.LiveProps is GSports.Model.Entities.Event.Live.ITimeBased ? ((GSports.Model.Entities.Event.Live.ITimeBased)x.LiveProps).CurrentTime.ToString() : x.LiveProps.CurrentState.ToString()
                        } : null
                    },
                    BetTypes = betTypes
                });
            });

            return retVal;
        }
        #endregion

        #region Finance

        internal static List<GSports.CashBox.Model.Entities.Finance.Transaction> ToClientTransactions(GetTransactionsResponse res)
        {
            List<GSports.CashBox.Model.Entities.Finance.Transaction> retVal = new List<GSports.CashBox.Model.Entities.Finance.Transaction>();
            res.Transactions.ForEach(x => retVal.Add(new GSports.CashBox.Model.Entities.Finance.Transaction(x.Account.User.Id.ToString(), x.Account.User.UserName)
            {
                Amount = x.Amount,
                CreateTime = x.CreateTime,
                OpenBalance = x.OpenBalance,
                UserID = x.Account.User.Id,
                FirstName = x.Account.User.FirstName,
                LastName = x.Account.User.LastName,
                Name = x.Name,
                ReferenceId = string.Format("{0}", (x.ObjectType == CodeAttribute.ObjectType.Order) ? x.AddressedObjectId : x.Id) ,
                TransactionType = ToClientTransactionType(x.TransactionType),
                TransactionReason = ToClientTransactionReason(x.TransactionReason),
                Commission = x.Commission,
                OpenCommission =x.OpenCommission,
                Id =x.Id.ToString()
            }));
            return retVal;
        }
        internal static List<GSports.CashBox.Model.Entities.Finance.Transfer> ToClientTransfers(List<GSports.Model.Entities.Finance.Transfer> transfers)
        {
            List<GSports.CashBox.Model.Entities.Finance.Transfer> retVal = new List<GSports.CashBox.Model.Entities.Finance.Transfer>();
            transfers.ForEach(x => retVal.Add(new GSports.CashBox.Model.Entities.Finance.Transfer()
            {
                CancelTime = x.CancelTime,
                CreateTime = x.CreateTime,
                FromUser = ToClientUser(x.FromAccount.User),
                RequestAmount = x.RequestAmount,
                RequestComments = x.RequestComments,
                RequestTime = x.RequestTime,
                ResponseTime = x.ResponseTime,
                RequestCodeAttribute = x.RequestType.CodeAttribute,
                ToUser = ToClientUser(x.ToAccount.User),
                MustApprove = x.MustApprove,
                ResponseCodeAttribute = x.ResponseType.CodeAttribute,
                Id = x.Id.ToString()
            }));
            return retVal;
        }

  

        private static Model.Entities.Finance.TransactionReason ToClientTransactionReason(GSports.Model.Entities.Finance.TransactionReason transactionReason)
        {
            var retVal = new Model.Entities.Finance.TransactionReason();
            retVal.CodeAttribute = transactionReason.CodeAttribute;
            return retVal;
        }

        private static Model.Entities.Finance.TransactionType ToClientTransactionType(GSports.Model.Entities.Finance.TransactionType transactionType)
        {
            var retVal = new Model.Entities.Finance.TransactionType();
            retVal.CodeAttribute = transactionType.CodeAttribute;
            return retVal;
        }

        internal static List<Reports> ToClientAccountReports(GetAccountReportSummaryResponse res)
        {
            var retVal = new List<Reports>();
            foreach (GSports.Model.Entities.Reports.AccountReportSummary item in res.AccountReport)
            {
                retVal.Add(new Reports()
                {
                    ReportDate = item.ReportDate,
                    CountDeposit = item.CountDeposit,
                    CountPayout = item.CountPayout,
                    CountWithdraw = item.CountWithdraw,
                    Deposit = item.Deposit,
                    NetCash = item.NetCash,
                    Payout = item.Payout,
                    Withdraw = item.Withdraw,
                    Bonus = item.BonusCash,
                    Commission = item.Commission,
                    CountSales = item.CountSales,
                    NetProfit = item.NetProfit,
                    Sales = item.Sales,
                    Tax = item.Tax
                });
            }
            return retVal;
        }
        #endregion


        #endregion

        #region To Server     

        #region Bet

        public static List<GSports.Model.Requests.Order.Selection> ToServerSelections(List<SelectionBet> list)
        {
            var retVal = new List<GSports.Model.Requests.Order.Selection>();

            list.ForEach(x => retVal.Add(new GSports.Model.Requests.Order.Selection()
            {
                BetTypeId = x.BetTypeId,
                EventId = x.EventId,
                Key = x.Key,
                OddLine = x.OddLine,
                OddName = x.OddName,
                OddPrice = x.OddPrice
            }));

            return retVal;
        }

        public static List<GSports.Model.Requests.Order.RequestOrderRow> ToServerServerRows(List<RowBet> list)
        {
            var retVal = new List<GSports.Model.Requests.Order.RequestOrderRow>();

            list.ForEach(x => retVal.Add(new GSports.Model.Requests.Order.RequestOrderRow()
            {
                Amount = x.Amount,
                SelectionKeys = x.SelectionKeys
            }));

            return retVal;
        }
        #endregion

        #endregion

    }
}
