﻿using GSports.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Response.MetadataService;
using GSports.Model.Responses.Metadata;
using GSports.CashBox.Model.Request.FinanceService;

namespace GSports.CashBox.Context.Convertors
{
    public static class RequestConvertor
    {

        #region AuthenticationService
        public static GSports.Model.Requests.Authentication.LoginRequest ToLoginRequest(CashBox.Model.Request.AuthenticationService.LoginRequest request)
        {
            var retVal = new GSports.Model.Requests.Authentication.LoginRequest();
            retVal.LoginFrom = ((GSports.Model.Security.eLoginFrom)request.LoginFrom);
            retVal.IP = request.IP;
            retVal.Password = request.Password;
            retVal.UserName = request.Username;
            retVal.TerminalSecurityCode = request.TerminalSecurityCode;
            return retVal;
        }
      
        public static GSports.Model.Requests.Authentication.LogoutRequest ToLogoutRequest(CashBox.Model.Request.AuthenticationService.LogoutRequest request)
        {
            var retVal = new GSports.Model.Requests.Authentication.LogoutRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.logoutType = ((GSports.Model.Security.eLogoutType)request.logoutType);
            return retVal;
        }

        

        public static GSports.Model.Requests.Authentication.RegisterTerminalRequest ToRegisterTerminalRequest(Model.Request.AuthenticationService.RegisterTerminalRequest request)
        {
            var retVal = new GSports.Model.Requests.Authentication.RegisterTerminalRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.IPAddress = request.IP;
            retVal.MACAddress = request.MACAddress;
            retVal.TerminalSecureCode = request.TerminalSecureCode;
            return retVal;
        }

      

        public static GSports.Model.Requests.Authentication.TerminalStatusRequest ToTerminalStatusRequest(CashBox.Model.Request.AuthenticationService.TerminalStatusRequest request)
        {
            var retVal = new GSports.Model.Requests.Authentication.TerminalStatusRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.TerminalSecureCode = request.TerminalSecurityCode;
            return retVal;
        }

     



        #endregion

        #region FinanceService


        internal static GSports.Model.Requests.Finance.InsertDepositRequest ToInsertDepositRequest(Model.Request.FinanceService.DepositRequest request)
        {
            var retVal = new GSports.Model.Requests.Finance.InsertDepositRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.Amount = request.Amount;
            retVal.ToUserId = request.ToUserId;
            retVal.Password = request.Password;
            retVal.PaymentMethod = GSports.Model.Consts.ePaymentMethod.Shop;
            return retVal;
        }

       

        internal static GSports.Model.Requests.Finance.CommitWithdrawRequest ToCommitWithdrawRequest(GSports.CashBox.Model.Request.FinanceService.UpdateWithdrawRequest request)
        {
            var retVal = new GSports.Model.Requests.Finance.CommitWithdrawRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.ResponseComments = request.Comments;            
            retVal.TransferCode = request.Code;
            retVal.ResponseTypeCodeAttr = Common.CodeAttribute.TransferResponseType.Approved;
            retVal.Password = request.Password;
            return retVal;

        }

        internal static GSports.Model.Requests.Finance.GetTransactionsRequest ToGetTransactionsRequest
            (GSports.CashBox.Model.Request.FinanceService.GetTransactionsRequest request)
        {
            var retVal = new GSports.Model.Requests.Finance.GetTransactionsRequest();
            retVal.Filter = new GSports.Model.Filter.TransactionFilter();
            retVal.UserToken = request.UserToken;
            retVal.Filter.AccountId = request.Filter.AccountId;
            retVal.Filter.BranchId = request.Filter.BranchId;
            retVal.Filter.FromDate = request.Filter.FromDate;
            retVal.Filter.ShiftId = request.Filter.ShiftId;
            retVal.Filter.ToDate = request.Filter.ToDate;
            retVal.Filter.TransactionId = request.Filter.TransactionId;
            retVal.Filter.UserId = request.Filter.UserId;
            return retVal;
        }


     

        internal static GSports.Model.Requests.Finance.GetTransfersRequest ToGetTransfersRequest
            (GSports.CashBox.Model.Request.FinanceService.GetTransfersRequest request)
        {
            var retVal = new GSports.Model.Requests.Finance.GetTransfersRequest();
            retVal.Filter = new GSports.Model.Filter.TransferFilter();
            retVal.UserToken = request.UserToken;
            retVal.Filter.FromDate = request.Filter.FromDate;
            retVal.Filter.ToDate = request.Filter.ToDate;
            retVal.Filter.ShiftId = request.Filter.ShiftId;
            retVal.Filter.TransferId = request.Filter.TransferId;
            retVal.Filter.TransferRequestTypes = request.Filter.TransferRequestTypes;
            retVal.Filter.TransferResponseTypes = request.Filter.TransferResponseTypes;
            retVal.Filter.UserId = request.Filter.UserId;
            retVal.Filter.TransferCode = request.Filter.TransferCode;
            return retVal;
        }


        internal static GSports.Model.Requests.Finance.UpdateTransferRequest ToUpdateTransfersRequest
            (GSports.CashBox.Model.Request.FinanceService.UpdateTransferRequest request)
        {
            var retVal = new GSports.Model.Requests.Finance.UpdateTransferRequest();
            retVal.UserToken = request.UserToken;
            retVal.ResponseAmount = request.ResponseAmount;
            retVal.ResponseComments = request.ResponseComments;
            retVal.ResponseTypeCodeAttr = request.ResponseCodeAttribute;
            //retVal.TransferCode = request.TransferCode;
            retVal.TransferId = request.TransferId;
            return retVal;
        }

        internal static GSports.Model.Requests.Finance.InsertTransferRequest ToCreateTransfersRequest
    (GSports.CashBox.Model.Request.FinanceService.CreateTransferRequest request)
        {
            var retVal = new GSports.Model.Requests.Finance.InsertTransferRequest();
            retVal.UserToken = request.UserToken;
            retVal.Transfer = new GSports.Model.Entities.Finance.Transfer()
            {                                 
                FromAccount = new GSports.Model.Entities.Finance.Account() { User = new GSports.Model.Entities.User.BasicUser() { Id = request.FromUserId } },
                RequestType = new GSports.Model.Entities.Finance.TransferRequestType() { CodeAttribute = request.RequestCodeAttribute},
                RequestComments = request.RequestComments,
                RequestAmount = request.RequestAmount,
                ToAccount = new GSports.Model.Entities.Finance.Account() { User = new GSports.Model.Entities.User.BasicUser() { Id = request.ToUserId } },
                ResponseType = new GSports.Model.Entities.Finance.TransferResponseType() { CodeAttribute = CodeAttribute.TransferResponseType.Pending },
                MustApprove = (request.RequestCodeAttribute == CodeAttribute.TransferRequestType.CloseShift)
            };
            return retVal;
        }


        internal static GSports.Model.Requests.Reports.GetAccountReportSummmaryRequest ToGetReports(GetReportsRequest request)
        {
            var retVal = new GSports.Model.Requests.Reports.GetAccountReportSummmaryRequest();
            retVal.UserToken = request.UserToken;
            retVal.Filter = new GSports.Model.Filter.AccountReportSummaryFilter();
            retVal.Filter.DateFrom = request.Filter.DateFrom;
            retVal.Filter.ToDate = request.Filter.DateTo;
            retVal.Filter.ReportType = (GSports.Model.Filter.eReportType)request.Filter.TimePeriod;
            return retVal;
        }
        #endregion

        #region MetadataService
        internal static GSports.Model.Requests.Metadata.GetItemsRequest ToGetItemsRequest(GSports.CashBox.Model.Request.MetadataService.GetCancelReasonTypeRequest request)
        {
            var retVal = new GSports.Model.Requests.Metadata.GetItemsRequest();
            retVal.Type = GSports.Model.Requests.Metadata.MetadataType.CancelReasonType;
            retVal.Language = request.Language;
            retVal.UserToken = request.UserToken;
            return retVal;
        }

        internal static GSports.Model.Requests.Event.GetCouponRequest ToGetCouponsRequest(CashBox.Model.Request.MetadataService.GetCouponsRequest request)
        {
            return new GSports.Model.Requests.Event.GetCouponRequest() { UserToken = request.UserToken, CouponId = request.CouponId, IsActive = request.ActiveOnly };
        }

        internal static GSports.Model.Requests.Event.ExportCouponRequest ToDownloadRequest(CashBox.Model.Request.MetadataService.DownloadCouponRequest req)
        {
            return new GSports.Model.Requests.Event.ExportCouponRequest() { UserToken = req.UserToken, CouponId = new List<int>() { req.CouponId } ,Language=req.Language};
        }

        public static GSports.Model.Requests.Metadata.GetItemsRequest ToGetItemsRequest(CashBox.Model.Request.MetadataService.GetBetTypesTemplateRequest request)
        {
            var retVal = new GSports.Model.Requests.Metadata.GetItemsRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.Type = GSports.Model.Requests.Metadata.MetadataType.BetType;
            retVal.Filter = new GSports.Model.Filter.BetTypeFilter() { All = true };            
            return retVal;
        }

        internal static GSports.Model.Requests.Metadata.KeepAliveTerminalRequest ToKeepAliveTerminalRequest(CashBox.Model.Request.MetadataService.KeepAliveRequest request)
        {
            var retVal = new GSports.Model.Requests.Metadata.KeepAliveTerminalRequest();
            retVal.AppVersion = request.AppVersion;
            retVal.UserToken = request.UserToken;
            retVal.TerminalSecurityCode = request.TerminalSecurityCode;
            return retVal;
        }

        #endregion

        #region BetService

        public static GSports.Model.Requests.Order.GetOrdersDataRequest ToGetBetOrderDataRequest(Model.Request.BetService.GetOrderDataRequest request)
        {
            var retVal = new GSports.Model.Requests.Order.GetOrdersDataRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.Barcod =  request.Barcode;
            retVal.Number = request.BookingCode;
            retVal.LastTicket =  request.LastTicket;           
            if(!string.IsNullOrEmpty(request.RequestGuid))
                retVal.RequestGuid =Guid.Parse(request.RequestGuid);
            retVal.LastTicketUserIds = request.LastTicketUserId.HasValue ? new List<int>() { request.LastTicketUserId.Value } : null;
            return retVal;
        }

        public static GSports.Model.Requests.Order.OrderRequest ToOrderRequest(Model.Request.BetService.PlaceBetsRequest request)
        {
            var retVal = new GSports.Model.Requests.Order.OrderRequest();
            retVal.ExternalID = request.ExternalID;
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.TerminalSecurityCode = request.TerminalSecurityCode;
            retVal.Selections = ModelConvertor.ToServerSelections(request.Selections);
            retVal.Rows = ModelConvertor.ToServerServerRows(request.Rows);
            retVal.PreviousOrderGuid = request.PreviousOrderGuid;
            return retVal;
        }

        internal static GSports.Model.Requests.Order.DoPayoutRequest ToDoPayoutRequest(Model.Request.BetService.DoPayoutRequest request)
        {
            var retVal = new GSports.Model.Requests.Order.DoPayoutRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.Barcode = request.Barcode;
            retVal.TerminalSecurityCode = request.TerminalSecurityCode;
            
            return retVal;
        }

        internal static GSports.Model.Requests.Order.CancelOrderRequest ToCancelOrderRequest(Model.Request.BetService.CancelOrderRequest request, int cancelBy)
        {
            var retVal = new GSports.Model.Requests.Order.CancelOrderRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.cancelReason  = request.CancelReason;
            retVal.cancelReasonTypeId = request.CancelReasonTypeId;
            retVal.cancelBy = cancelBy;
            retVal.orderId = request.OrderId;
            return retVal;
        }
        #endregion

        #region UserService

        internal static GSports.Model.Requests.UserService.GetUsersRequest ToGetUsersRequest(GSports.CashBox.Model.Request.UserService.GetUsersRequest request)
        {

            var retVal = new GSports.Model.Requests.UserService.GetUsersRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.Filter = new GSports.Model.Filter.UserFilter()
            {
                FilterToken = request.FilterToken,                                  
                LoadCurrentShift = true,
                LoadOpenTransfers = true
            };
            if (!string.IsNullOrEmpty(request.FilterToken))
                retVal.Filter.LoadMatrix = true;
            if (request.BranchId != null)
            {
                retVal.Filter.Branches = new List<int>();
                retVal.Filter.Branches.Add(request.BranchId.Value);
            }
            if (request.UserId != null)
            {
                retVal.Filter.UserId = request.UserId.Value;                
            }
            return retVal;
        }

        internal static GSports.Model.Requests.Shifts.StartShiftRequest ToStartShiftRequest
            (GSports.CashBox.Model.Request.Shifts.StartShiftRequest request)
        {
            var retVal = new GSports.Model.Requests.Shifts.StartShiftRequest();         
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.BranchId = request.BranchId;
            return retVal;
        }
        internal static GSports.Model.Requests.Shifts.StartUserShiftRequest ToStartUserShiftRequest
            (GSports.CashBox.Model.Request.Shifts.StartUserShiftRequest request)
        {
            var retVal = new GSports.Model.Requests.Shifts.StartUserShiftRequest();
            retVal.UserToken = request.UserToken;
            retVal.Language = request.Language;
            retVal.ShiftId = request.ShiftId;
            retVal.CreditLimit = request.CreditLimit;
            retVal.UserId = request.UserId;
            return retVal;
        }

        internal static GSports.Model.Requests.Shifts.StopUserShiftRequest ToStopUserShiftRequest
            (GSports.CashBox.Model.Request.Shifts.StopUserShiftRequest request)
        {
            var retVal = new GSports.Model.Requests.Shifts.StopUserShiftRequest();
            retVal.UserToken = request.UserToken;
            retVal.UserId = request.UserId;
            retVal.ShiftId = request.ShiftId;
            return retVal;
        }

        internal static GSports.Model.Requests.Shifts.StopShiftRequest ToStopShiftRequest
            (GSports.CashBox.Model.Request.Shifts.StopShiftRequest request)
        {
            var retVal = new GSports.Model.Requests.Shifts.StopShiftRequest();
            retVal.UserToken = request.UserToken;
            retVal.ShiftId = request.ShiftId;
            return retVal;
        }

        internal static GSports.Model.Requests.Shifts.GetShiftDataRequest ToGetShiftDataRequest
            (GSports.CashBox.Model.Request.Shifts.GetUserShiftsDataRequest request)
        {
            var retVal = new GSports.Model.Requests.Shifts.GetShiftDataRequest();
            retVal.UserToken = request.UserToken;
            retVal.ShiftId = request.ShiftId;
            retVal.UserIds = request.UserIds;
            return retVal;
        }

        internal static GSports.Model.Requests.Finance.GetTransferContactsRequest GetAllowedContactsRequest
    (GSports.CashBox.Model.Request.UserService.GetAllowedContactsRequest request)
        {
            var retVal = new GSports.Model.Requests.Finance.GetTransferContactsRequest();
            retVal.UserToken = request.UserToken;
            retVal.UserId = request.UserId;
            return retVal;
        }

        internal static GSports.Model.Requests.UserService.GetUsersRequest ToGetBranchUsers(GSports.CashBox.Model.Request.UserService.GetBranchUsersRequest request)
        {
            var retVal = new GSports.Model.Requests.UserService.GetUsersRequest();
            retVal.UserToken = request.UserToken;
            retVal.Filter = new GSports.Model.Filter.UserFilter();
            retVal.Filter.Branches = new List<int>();          
            retVal.Filter.Branches.Add(request.BranchId);
            return retVal;
        }
        #endregion

    }

}
