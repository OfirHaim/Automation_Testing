﻿using GSports.CashBox.Model.Response.MetadataService;
using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using GSports.Model.Requests.Order;
using GSports.Model.Responses.Order;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Context.Channel
{
    public class BetChannel
    {
        public static MemoryStream DownloadCoupon(GSports.Model.Requests.Event.ExportCouponRequest request)
        {
            MemoryStream retVal = null;

            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.ExportCoupon(request)?.CouponFile;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        public static IEnumerable<Coupon> GetCoupon(GSports.Model.Requests.Event.GetCouponRequest request)
        {
            IEnumerable<Coupon> retVal = null;

            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetAvailableCoupons(request)?.Coupons.Select(x => new Coupon() { Id = x.Id, Name = x.Name });
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static OrderResponse RequestForOrder(OrderRequest request)
        {
            OrderResponse retVal = new OrderResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.RequestForOrder(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static ExecuteOrderResponse ExecuteOrder(ExecuteOrderRequest request)
        {
            ExecuteOrderResponse retVal = new ExecuteOrderResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal =  service.ExecuteOrder(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static GetOrdersDataResponse GetBetOrderData(GetOrdersDataRequest request)
        {
            GetOrdersDataResponse retVal = new GetOrdersDataResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {                  
                    var service = factory.CreateChannel();
                    retVal = service.GetOrdersData(request);                 
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);                
            }
            return retVal;
        }

        public static CancelOrderResponse CancelOrder(CancelOrderRequest request)
        {
            CancelOrderResponse retVal = new CancelOrderResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.CancelOrder(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static DoPayoutResponse DoPayout(DoPayoutRequest request)
        {
            DoPayoutResponse retVal = new DoPayoutResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.DoPayout(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

    }
    
}
