﻿using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using GSports.Model.Entities.User;
using GSports.Model.Filter;
using GSports.Model.Requests.Authentication;
using GSports.Model.Requests.UserService;
using GSports.Model.Responses.Authentication;
using GSports.Model.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Context.Channel
{
    public static class AuthenticationChannel
    {
      internal static LogInResponse LoginUser(LoginRequest request)
        {
            LogInResponse retVal = new LogInResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>(ServiceConsts.AUTHENTICATION_SERVICE))
                {                  
                    var service = factory.CreateChannel();
                     retVal = service.LoginUser(request);
                  
                    //if (!string.IsNullOrEmpty(res.Token))
                    //{
                    //    using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE, res.Token, res.Token))
                    //    {
                    //        var userService = userFactory.CreateChannel();
                    //        var getUsersRequest = new GetUsersRequest()
                    //        {
                    //            UserToken = res.Token,
                    //            Filter = new UserFilter(res.Token)
                    //            {
                    //                LoadMatrix = true,
                    //                LoadCurrentShift = true                                                                   
                    //            }
                    //        };

                    //        retVal = userService.GetUsers(getUsersRequest)?.Users?.SingleOrDefault();
                    //        retVal.LastAccess = new Access() { Token = Guid.Parse(res.Token) };
                    //    }
                    //}
                    //else
                    //    return null;
                }
            }
            catch (Exception ex)
            {
                 Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            } 
            return retVal;
        }


        internal static LogoutResponse LogoutUser(LogoutRequest request)
        {
            LogoutResponse retVal = null;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>(ServiceConsts.AUTHENTICATION_SERVICE))
                {                    
                    var service = factory.CreateChannel();
                    retVal = service.LogoutUser(request);                 
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);                                    
            }
            return retVal;             
        }

        internal static TerminalStatusResponse GetTerminalStatus(TerminalStatusRequest request)
        {
            TerminalStatusResponse retVal = null;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>(ServiceConsts.AUTHENTICATION_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetTerminalStatus(request);                    
                   
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
            }
            return retVal;
        }

        internal static RegisterTerminalResponse RegisterTerminal(RegisterTerminalRequest request)
        {
            RegisterTerminalResponse retVal = null;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>(ServiceConsts.AUTHENTICATION_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.RegisterTerminal(request);

                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
            }
            return retVal;
        }



    }
}
