﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;

namespace GSports.CashBox.Context.Channel
{
    class GSportsChannelFactory<T> : ChannelFactory<T>
    {
        public GSportsChannelFactory(string endpointConfigurationName,string user, string pass)
            : base(endpointConfigurationName)
        {          
            this.Credentials.UserName.UserName = user;
            this.Credentials.UserName.Password = pass;

#if DEBUG
            //TODO: remove on production! danger! [Trust all SSL certificates]
            System.Net.ServicePointManager.ServerCertificateValidationCallback = ((sender, certificate, chain, sslPolicyErrors) => true);
#endif
        }
        public GSportsChannelFactory(string endpointConfigurationName)
         : base(endpointConfigurationName)
        {
            this.Credentials.UserName.UserName = "a";
            this.Credentials.UserName.Password = "b";

#if DEBUG
            //TODO: remove on production! danger! [Trust all SSL certificates]
            System.Net.ServicePointManager.ServerCertificateValidationCallback = ((sender, certificate, chain, sslPolicyErrors) => true);
#endif
        }
    }
}
