﻿using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using System;


namespace GSports.CashBox.Context.Channel
{
    public class MetadataChannel
    {
        public static GSports.Model.Responses.Metadata.GetItemsResponse GetItems(GSports.Model.Requests.Metadata.GetItemsRequest request)
        {
            GSports.Model.Responses.Metadata.GetItemsResponse retVal = null;
            try
            {
                using (var factory = new GSportsChannelFactory<IBetMetadata>(ServiceConsts.BET_METADATA_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetItems(request);
                    
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }        

            return retVal;
        }

        internal static GSports.Model.Responses.Metadata.KeepAliveTerminalResponse KeepAliveTerminal(GSports.Model.Requests.Metadata.KeepAliveTerminalRequest request)
        {
            GSports.Model.Responses.Metadata.KeepAliveTerminalResponse retVal = new GSports.Model.Responses.Metadata.KeepAliveTerminalResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetMetadata>(ServiceConsts.BET_METADATA_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.KeepAliveTerminal(request);
                }
            }
            catch(Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);

            }
            return retVal;
        }
    }
}
