﻿using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using GSports.Model.Requests.Finance;
using GSports.Model.Responses.Finance;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Context.Channel
{
    public class FinanceChannel
    {
        public static InsertDepositResponse InsertDeposit(InsertDepositRequest request)
        {
            InsertDepositResponse retVal = new InsertDepositResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.InsertDeposit(request);                                  
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
         
            return retVal;
        }

        internal static GetTransactionsResponse GetTransactions(GetTransactionsRequest request)
        {
            GetTransactionsResponse retVal = new GetTransactionsResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetTransactions(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        internal static GetTransfersResponse GetTransfers(GetTransfersRequest request)
        {
            GetTransfersResponse retVal = new GetTransfersResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetTransfers(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        internal static InsertTransferResponse InsertTransfer(InsertTransferRequest request)
        {
            InsertTransferResponse retVal = new InsertTransferResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.InsertTransfer(request);

                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        internal static UpdateTransferResponse UpdateTransfer(UpdateTransferRequest request)
        {
            UpdateTransferResponse retVal = new UpdateTransferResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.UpdateTransfer(request);

                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        public static CommitWithdrawResponse CommitWithdraw(CommitWithdrawRequest request)
        {
            CommitWithdrawResponse retVal = new CommitWithdrawResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.CommitWithdraw(request);

                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        public static GSports.Model.Responses.Reports.GetAccountReportSummaryResponse GetReports(GSports.Model.Requests.Reports.GetAccountReportSummmaryRequest request)
        {
            GSports.Model.Responses.Reports.GetAccountReportSummaryResponse retVal = new GSports.Model.Responses.Reports.GetAccountReportSummaryResponse();
            try
            {
                using (var factory = new GSportsChannelFactory<IBetService>(ServiceConsts.BET_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetAccountReportSummary(request);
                }
            }
            catch(Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }
    }
}
