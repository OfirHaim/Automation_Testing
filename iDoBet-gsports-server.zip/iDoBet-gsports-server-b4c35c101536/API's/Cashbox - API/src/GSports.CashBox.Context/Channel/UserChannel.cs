﻿using GSports.Model.Entities.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ServiceModel;
using GSports.Contracts;
using GSports.Common;
using GSports.Model.Security;
using GSports.Model.Requests.UserService;
using GSports.Model.Filter;
using GSports.GLogger;
using GSports.Model.Responses.UserService;
using GSports.Model.Responses.Shifts;
using GSports.Model.Requests.Shifts;
using GSports.Model.Requests.Finance;
using GSports.Model.Responses.Finance;

namespace GSports.CashBox.Context.Channel
{
    public static class UserChannel
    {
        internal static GetUsersResponse GetUser(GetUsersRequest request)
        {
            GetUsersResponse retVal = new GetUsersResponse();
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE, request.UserToken, request.UserToken))
                {
                    var userService = userFactory.CreateChannel();
                    retVal = userService.GetUsers(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static string GetUserInfo(string token)
        {
            var retVal = string.Empty;
            try
            {
                using (var factory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE))
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetUserInfo(token);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static StartShiftResponse StartShift(StartShiftRequest request)
        {
            var retVal = new StartShiftResponse();
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE, request.UserToken, request.UserToken))
                {
                    var userService = userFactory.CreateChannel();
                    retVal = userService.StartShift(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static StartUserShiftResponse StartUserShift(StartUserShiftRequest request)
        {
            var retVal = new StartUserShiftResponse();
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE, request.UserToken, request.UserToken))
                {
                    var userService = userFactory.CreateChannel();
                    retVal = userService.StartUserShift(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }


        public static StopUserShiftResponse StopUserShift(StopUserShiftRequest request)
        {
            var retVal = new StopUserShiftResponse();
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE, request.UserToken, request.UserToken))
                {
                    var userService = userFactory.CreateChannel();
                    retVal = userService.StopUserShift(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static StopShiftResponse StopShift(StopShiftRequest request)
        {
            var retVal = new StopShiftResponse();
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE, request.UserToken, request.UserToken))
                {
                    var userService = userFactory.CreateChannel();
                    retVal = userService.StopShift(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        internal static GetShiftsResponse GetShifts(GetShiftsRequest request)
        {
            var retVal = new GetShiftsResponse();
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE, request.UserToken, request.UserToken))
                {
                    var userService = userFactory.CreateChannel();
                    retVal = userService.GetShifts(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }


        internal static GetShiftDataResponse GetShiftData(GetShiftDataRequest request)
        {
            var retVal = new GetShiftDataResponse();
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE, request.UserToken, request.UserToken))
                {
                    var userService = userFactory.CreateChannel();
                    retVal = userService.GetShiftData(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        internal static GetTransferContactResponse GetAllowedUsers(GetTransferContactsRequest request)
        {
            var retVal = new GetTransferContactResponse();
            try
            {
                using (var userFactory = new GSportsChannelFactory<IFinanceService>(ServiceConsts.FINANCE_SERVICE, request.UserToken, request.UserToken))
                {
                    var userService = userFactory.CreateChannel();
                    retVal = userService.GetTransferContacts(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        internal static GetUsersResponse GetBranchUsers(GetUsersRequest request)
        {
            var retVal = new GetUsersResponse();
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>(ServiceConsts.USER_SERVICE, request.UserToken, request.UserToken))
                {
                    var userService = userFactory.CreateChannel();
                    retVal = userService.GetUsers(request);
                }
            }
            catch (Exception ex)
            {
                retVal.SetErrorResult(GSports.Model.Consts.eErrorCode.InternalServerError, ex.Message);
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

    }
}
