﻿using GSports.CashBox.Model.Request.EventService;
using GSports.CashBox.Model.Response.EventService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Contracts
{
    public interface IEventContext
    {
         GetEventsResponse GetEvents(GetEventsRequest request);
        GetEventsUpdatesResponse GetEventsUpdates(GetEventsUpdatesRequest reqeust);
    }
}
