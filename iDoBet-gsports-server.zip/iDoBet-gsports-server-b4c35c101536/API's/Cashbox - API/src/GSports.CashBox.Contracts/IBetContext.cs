﻿using GSports.CashBox.Model.Request.BetService;
using GSports.CashBox.Model.Response.BetService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Contracts
{
    public interface IBetContext
    {
        PlaceBetsResponse PlaceBets(PlaceBetsRequest request);
        ExecuteOrderResponse ExecuteOrder(ExecuteOrderRequest request);
        GetOrderDataResponse GetBetOrderData(GetOrderDataRequest request);
        CancelOrderResponse CancelOrder(CancelOrderRequest request);
        DoPayoutResponse DoPayout(DoPayoutRequest request);
        
    }
}
