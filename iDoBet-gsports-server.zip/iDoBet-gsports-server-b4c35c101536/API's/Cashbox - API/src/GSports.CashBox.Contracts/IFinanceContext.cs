﻿using GSports.CashBox.Model.Request.FinanceService;
using GSports.CashBox.Model.Response.FinanceService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Contracts
{
    public interface IFinanceContext
    {
        DepositResponse CreateDeposit(DepositRequest request);
        UpdateWithdrawResponse UpdateWithdraw(UpdateWithdrawRequest request);
        GetTransactionsResponse GetTransactions(GetTransactionsRequest request);
        GetTransfersResponse GetTransfers(GetTransfersRequest request);
        CreateTransferResponse CreateTransfer(CreateTransferRequest request);
        UpdateTransferResponse UpdateTransfer(UpdateTransferRequest request);
        GetReportsResponse GetReports(GetReportsRequest request);
    }
}
