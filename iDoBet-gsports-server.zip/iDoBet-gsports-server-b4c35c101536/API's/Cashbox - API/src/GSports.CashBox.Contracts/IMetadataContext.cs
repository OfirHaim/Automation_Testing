﻿using GSports.CashBox.Model.Request.MetadataService;
using GSports.CashBox.Model.Response.MetadataService;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Contracts
{
    public interface IMetadataContext
    {
        GetBetTypesTemplateResponse GetBetTypeTemplate(GetBetTypesTemplateRequest request);
        GetCancelReasonTypeResponse GetCancelReasonTypes(GetCancelReasonTypeRequest request);
        FileStreamResult DownloadCoupon(DownloadCouponRequest request);
        GetCouponsResponse GetCoupons(GetCouponsRequest request);
        KeepAliveResponse KeepAliveTerminal(KeepAliveRequest request);
    }
}
