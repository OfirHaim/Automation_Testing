﻿using GSports.CashBox.Model.Request.Shifts;
using GSports.CashBox.Model.Request.UserService;
using GSports.CashBox.Model.Response.Shifts;
using GSports.CashBox.Model.Response.UserService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Contracts
{
    public interface IUserContext
    {
        GetUsersResponse GetUsers(GetUsersRequest request);

        StartShiftResponse StartShift(StartShiftRequest request);

        StartUserShiftResponse StartUserShift(StartUserShiftRequest request);

        StopUserShiftResponse StopUserShift(StopUserShiftRequest request);

        StopShiftResponse StopShift(StopShiftRequest request);

        GetCurrentShiftResponse GetUserShiftsData(GetUserShiftsDataRequest request);

        //GetBranchUsersResponse GetBranchUsers(GetBranchUsersRequest request);

        GetAllowedContactsResponse GetAllowedContacts(GetAllowedContactsRequest request);
      
    }
}
