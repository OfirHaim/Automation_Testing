﻿using GSports.CashBox.Model.Request.AuthenticationService;
using GSports.CashBox.Model.Response.AuthenticationService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Contracts
{
    public interface IAuthenticationContext
    {
        LoginResponse LoginUser(LoginRequest request);
        LogoutResponse LogoutUser(LogoutRequest request);
        TerminalStatusResponse GetTerminalStatus(TerminalStatusRequest request);
        RegisterTerminalResponse RegisterTerminal(RegisterTerminalRequest request);
    }
}
