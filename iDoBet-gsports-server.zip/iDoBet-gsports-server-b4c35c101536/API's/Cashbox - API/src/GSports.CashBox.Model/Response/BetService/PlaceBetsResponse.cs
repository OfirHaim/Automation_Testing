﻿using GSports.CashBox.Model.Consts;
using GSports.CashBox.Model.Entities.Order;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.BetService
{
    public class PlaceBetsResponse : BaseResponse
    {
        public string TimeoutGuid { get; set; }
        public int? Timeout { get; set; }

        public long? OrderId { get; set; }
        public override bool IsResponseDataValid()
        {
            return (Timeout != null && TimeoutGuid != null) || OrderId != null;
        }
    }

    
}