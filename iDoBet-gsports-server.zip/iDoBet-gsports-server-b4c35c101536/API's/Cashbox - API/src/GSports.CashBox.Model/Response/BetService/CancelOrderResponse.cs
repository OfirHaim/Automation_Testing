﻿using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.BetService
{
    public class CancelOrderResponse: BaseResponse
    {
        public override bool IsResponseDataValid()
        {
            return true;

        }
    }
}
