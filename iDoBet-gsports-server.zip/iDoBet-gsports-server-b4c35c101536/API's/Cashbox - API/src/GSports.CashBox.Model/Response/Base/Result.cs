﻿using GSports.CashBox.Model.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.Base
{
    public class Result
    {
        public string ErrorDescription { get; set; }
        public object AdditionalInfo { get; set; }
        public int ErrorCode { get; set; }
        public eResultCode ResultCode { get; set; }
        public string ErrorCodeDescription { get; set; }
    }
}
