﻿using GSports.CashBox.Model.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.Base
{
    public abstract class BaseResponse
    {
        public BaseResponse() { }

        private Result mResult;
        public object UserInfo { get; set; }
        public Result Result
        {
            get { return mResult; }
            set { mResult = value; }
        }

        public abstract bool IsResponseDataValid();

        public void SetErrorResult(string errorDescription, int errorCode = (int)eApiErrorCode.APIError, object additionalInfo = null)
        {
            if (mResult == null) mResult = new Result();
            mResult.ErrorCode = errorCode;
            mResult.ErrorDescription = errorDescription;
            mResult.ResultCode = eResultCode.Failure;
            mResult.AdditionalInfo = additionalInfo;
        }

        public bool IsSuccessfull
        {
            get
            {
                if (!IsResponseDataValid())
                {
                    if (Result == null)
                    {
                        Result = new Result();
                        Result.ResultCode = eResultCode.Failure;
                        Result.ErrorCode = (int)eApiErrorCode.DataVlidationError;
                    }
                    
                    return false;
                }
                return Result == null || Result.ResultCode == eResultCode.Success;
            }
        }

    }
}
