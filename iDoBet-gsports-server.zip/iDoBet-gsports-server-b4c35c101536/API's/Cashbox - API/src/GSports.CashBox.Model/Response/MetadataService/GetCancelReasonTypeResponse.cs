﻿using GSports.CashBox.Model.Entities;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.MetadataService
{
    public class GetCancelReasonTypeResponse : BaseResponse
    {
        public List<CancelReasonType> CancelReasonTypes { get; set; }
        public override bool IsResponseDataValid()
        {
            return CancelReasonTypes != null && CancelReasonTypes.Any();
        }
    }
}
