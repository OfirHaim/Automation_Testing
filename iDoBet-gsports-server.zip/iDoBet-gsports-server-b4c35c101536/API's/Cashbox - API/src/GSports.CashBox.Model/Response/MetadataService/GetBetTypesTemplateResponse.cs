﻿using GSports.CashBox.Model.Entities;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.MetadataService
{
    public class GetBetTypesTemplateResponse : BaseResponse
    {
        public List<BetTypeTemplate> BetTypesSchema { get; set; }

        public override bool IsResponseDataValid()
        {
            return BetTypesSchema != null && BetTypesSchema.Any();
        }
    }
}
