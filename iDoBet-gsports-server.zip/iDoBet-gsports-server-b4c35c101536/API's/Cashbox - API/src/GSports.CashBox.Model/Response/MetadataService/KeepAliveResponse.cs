﻿using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.MetadataService
{
    public class KeepAliveResponse : BaseResponse
    {
        public bool KeepAlive { get; set; }
        public override bool IsResponseDataValid()
        {
            return KeepAlive;
        }
    }
}
