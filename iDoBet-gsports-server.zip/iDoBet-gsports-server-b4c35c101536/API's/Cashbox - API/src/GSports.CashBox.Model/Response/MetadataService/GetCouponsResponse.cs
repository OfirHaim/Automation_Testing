﻿using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.MetadataService
{
    public class GetCouponsResponse : BaseResponse
    {
        public IEnumerable<Coupon> CouponNames { get; set; }

        public override bool IsResponseDataValid()
        {
            return CouponNames != null;
        }
    }

    public class Coupon
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
