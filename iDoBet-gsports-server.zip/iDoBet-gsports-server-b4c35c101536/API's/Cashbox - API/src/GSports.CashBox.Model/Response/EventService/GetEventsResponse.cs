﻿using GSports.Clients.EventsManager.Model.Entities;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.EventService
{
    public class GetEventsResponse : BaseResponse
    {
        public List<Event> Events { get; set; }
        public int EventCount
        {
            get { return (this.Events == null) ? 0 : this.Events.Count; }
        }
        public int TotalEventCount { get; set; }
        
        public long LastTimestamp { get; set; }
        public List<int> ActiveCoupinIds { get; set; }
        public override bool IsResponseDataValid()
        {
            return Events != null;
        }
    }
}
