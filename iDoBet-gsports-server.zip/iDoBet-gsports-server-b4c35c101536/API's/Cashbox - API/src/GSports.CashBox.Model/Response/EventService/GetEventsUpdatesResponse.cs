﻿using GSports.CashBox.Model.Response.Base;
using GSports.Clients.EventsManager.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.EventService
{
    public class GetEventsUpdatesResponse: BaseResponse
    {
        public List<UpdateMessage> UpdateMessages { get; set; }

        public long LastTimestamp { get; set; }

        public List<int> ActiveCoupinIds { get; set; }

        public override bool IsResponseDataValid()
        {
            return UpdateMessages != null;
        }
    }
}
