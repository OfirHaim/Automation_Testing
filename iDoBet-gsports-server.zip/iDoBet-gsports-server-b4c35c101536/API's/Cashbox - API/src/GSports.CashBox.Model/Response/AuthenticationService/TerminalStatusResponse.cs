﻿using GSports.CashBox.Model.Entities;
using GSports.CashBox.Model.Entities.User;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.AuthenticationService
{
    public class TerminalStatusResponse : BaseResponse
    {
        
        public Branch Branch { get; set; }
        
        public Terminal Terminal { get; set; }
        
        public BaseUserData User { get; set; }

        public override bool IsResponseDataValid()
        {
            return true;
        }
    }
}
