﻿using GSports.CashBox.Model.Entities;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.AuthenticationService
{
    public class LoginResponse: BaseResponse
    {       
        public string Token { get; set; }        

        public override bool IsResponseDataValid()
        {
            return Token != null;
        }
    }
}
