﻿using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.FinanceService
{
    public class CreateTransferResponse : BaseResponse
    {
        public int NewId { get; set; }

        public override bool IsResponseDataValid()
        {
            return NewId > 0;
        }
    }
}
