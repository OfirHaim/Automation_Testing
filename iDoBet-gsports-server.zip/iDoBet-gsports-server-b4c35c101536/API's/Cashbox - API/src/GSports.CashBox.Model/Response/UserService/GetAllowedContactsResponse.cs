﻿using GSports.CashBox.Model.Entities;
using GSports.CashBox.Model.Entities.User;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.UserService
{
    public class GetAllowedContactsResponse : BaseResponse
    {
        public List<BaseUserData> Users { get; set; }

        public override bool IsResponseDataValid()
        {
            return Users != null;
        }

    }
}
