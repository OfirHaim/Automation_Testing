﻿using GSports.CashBox.Model.Entities.Shifts;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.UserService
{
    public class GetBranchUsersResponse : BaseResponse
    {
        public List<UserShift> UserShifts { get; set; }

        public override bool IsResponseDataValid()
        {
            return UserShifts != null; 
        }
    }
}
