﻿using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.Shifts
{
    public class StopUserShiftResponse : BaseResponse
    {
        public override bool IsResponseDataValid()
        {
            return true;
        }
    }
}
