﻿using GSports.CashBox.Model.Entities.Shifts;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Response.Shifts
{
    public class StartShiftResponse :BaseResponse
    {
        public ShiftEntity Shift { get; set; }
        public override bool IsResponseDataValid()
        {
            return Shift != null;
        }
    }
}
