﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.Shifts
{
    public class StopShiftRequest : BaseRequest
    {
        public long ShiftId { get; set; }
    }
}
