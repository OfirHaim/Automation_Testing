﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.UserService
{
    public class GetAllowedContactsRequest : BaseRequest
    {
        public int UserId { get; set; }
    }
}
