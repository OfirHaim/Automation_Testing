﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.Base
{
    public class GetOrderBaseRequest: BaseRequest
    {
        [JsonIgnore]
        public string OrderPrintTemplate { get; set; }
    }
}
