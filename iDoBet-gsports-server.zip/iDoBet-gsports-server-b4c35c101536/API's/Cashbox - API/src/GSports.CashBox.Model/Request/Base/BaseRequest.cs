﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.Base
{
    public class BaseRequest
    {
        /// <summary>
        /// Use Language format like this: en-GB, fr-FR
        /// </summary>        
        public string Language { get; set; }

        public string UserToken { get; set; }

        public string TerminalSecurityCode { get; set; }

    }
}
