﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.MetadataService
{
    public class DownloadCouponRequest : BaseRequest
    {
        public int CouponId { get; set; }
    }
}
