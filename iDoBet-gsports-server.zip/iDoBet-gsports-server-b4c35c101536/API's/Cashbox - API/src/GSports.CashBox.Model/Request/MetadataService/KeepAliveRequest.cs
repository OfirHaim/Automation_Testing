﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.MetadataService
{
    public class KeepAliveRequest:BaseRequest
    {
        public string AppVersion { get; set; }
        public GeoLocation Location { get; set; }
    }

    public class GeoLocation
    {   
        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
    }
}
