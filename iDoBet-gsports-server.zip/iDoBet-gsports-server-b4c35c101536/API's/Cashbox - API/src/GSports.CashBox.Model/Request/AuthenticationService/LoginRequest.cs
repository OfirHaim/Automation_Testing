﻿using GSports.CashBox.Model.Consts;
using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.AuthenticationService
{
    public class LoginRequest : BaseRequest
    {     
        public string Username { get; set; }      
        public string Password { get; set; }
        public string IP { get; set; }        
        public eLoginFrom LoginFrom { get; set; }
    }
}
