﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.AuthenticationService
{
    public class TerminalStatusRequest : BaseRequest 
    {
        public string TerminalSecurityCode { get; set; }
    }
}
