﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.AuthenticationService
{
    public class RegisterTerminalRequest : BaseRequest
    {
        public string IP { get; set; }
        public string MACAddress { get; set; }
        public string TerminalSecureCode { get; set; }
    }
}
