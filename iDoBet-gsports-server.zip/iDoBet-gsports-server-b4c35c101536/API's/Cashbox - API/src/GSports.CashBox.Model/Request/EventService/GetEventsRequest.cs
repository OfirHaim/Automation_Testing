﻿using GSports.Clients.EventsManager.Model.Entities;
using GSports.CashBox.Model.Response.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Request.Base;

namespace GSports.CashBox.Model.Request.EventService
{
    public class GetEventsRequest : BaseRequest
    {
       // public int? Top  { get; set; }
        public bool? ActiveCoupon { get; set; }
        public List<int> CoupinIds { get; set; }
        public List<long> EventIds { get; set; }
        public List<long> BetTypeIds { get; set; }
        public long? LastTimestamp { get; set; }
        public int? Skip { get; set; }
        public int? Take { get; set; }        
    }
}
