﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.EventService
{
    public class GetEventsUpdatesRequest: BaseRequest
    {
        public long? LastTimestamp { get; set; }
    }
}
