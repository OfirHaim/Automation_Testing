﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.BetService
{
    public class ExecuteOrderRequest: GetOrderBaseRequest
    {
        public string TimeoutGuid { get; set; }
        public int? Width { get; set; }

    }
}
