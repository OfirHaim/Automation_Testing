﻿using GSports.CashBox.Model.Request.Base;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.BetService
{
    public class CancelOrderRequest: BaseRequest
    {                
        public string CancelReason { get; set; }
        public byte? CancelReasonTypeId { get; set; } 
        public long OrderId { get; set; }        
    }
}
