﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.BetService
{
    public class GetOrderDataRequest: GetOrderBaseRequest
    {        
        public string Barcode { get; set; }
        public string BookingCode { get; set; }
        public string RequestGuid { get; set; }
        public bool? LastTicket { get; set; }
        public int? LastTicketUserId { get; set; }
        public int? Width { get; set; }
        public bool? ForPrint { get; set; }
    }
}
