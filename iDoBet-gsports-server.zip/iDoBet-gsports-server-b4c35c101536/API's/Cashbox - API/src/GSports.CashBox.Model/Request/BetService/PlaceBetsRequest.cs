﻿using GSports.CashBox.Model.Entities.Bet;
using GSports.CashBox.Model.Request.Base;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.BetService
{
    public class PlaceBetsRequest: GetOrderBaseRequest
    {
        public List<SelectionBet> Selections { get; set; }

        public List<RowBet> Rows { get; set; }
        public string ExternalID { get; set; }
        public string PreviousOrderGuid { get; set; }

    }

   
}
