﻿using GSports.CashBox.Model.Entities;
using GSports.CashBox.Model.Entities.Helpers;
using GSports.CashBox.Model.Request.Base;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.FinanceService
{
    public class DepositRequest: BaseRequest
    {
        public double Amount { get; set; }
        public int ToUserId { get; set; }
        public string Password { get; set; }
        public string Comments { get; set; }
        [JsonIgnore]
        public string DepositPrintTemplate { get; set; } 
        public string BranchName { get; set; }
        public DepositPrintParams printParams { get; set; }
    }
}
