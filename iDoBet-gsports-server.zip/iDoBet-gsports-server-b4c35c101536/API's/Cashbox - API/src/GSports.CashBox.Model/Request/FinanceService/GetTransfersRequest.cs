﻿using GSports.CashBox.Model.Entities.Filter;
using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.FinanceService
{
    public class GetTransfersRequest : BaseRequest
    {
        public TransferFilter Filter { get; set; }
    }
}
