﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.FinanceService
{
    public class UpdateTransferRequest : BaseRequest
    {
        public long TransferId { get; set; }
        //public string TransferCode { get; set; }
        public string ResponseCodeAttribute { get; set; }
        public double ResponseAmount { get; set; }
        public string ResponseComments { get; set; }
    }
}
