﻿using GSports.CashBox.Model.Request.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Request.FinanceService
{
    public class CreateTransferRequest : BaseRequest
    {
        public int FromUserId { get; set; }
        public string RequestCodeAttribute { get; set; }
        public string RequestComments { get; set; }
        public double RequestAmount { get; set; }
        public int ToUserId { get; set; }
    }
}
