﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Consts1
{
    public enum eOrderProd
    {

        Unknown = 0,


        Prematch = 1,


        Live = 2
    }

}
