﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Consts1
{
   
    public enum eRole
    {
        Unknown = 0,
        Cashier = 1,
        BranchManager = 2,
        Agent = 3,
        Operator = 4,
        SuperAdmin = 10,
        Teller = 12
    }
}

