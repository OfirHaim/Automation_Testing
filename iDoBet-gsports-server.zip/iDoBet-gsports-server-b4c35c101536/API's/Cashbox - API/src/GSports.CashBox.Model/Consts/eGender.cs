﻿
namespace GSports.CashBox.Model.Consts1
{
    public enum eGender
    {        
        Male = 0,
        Female = 1        
    }
}
