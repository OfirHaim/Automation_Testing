﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Consts1
{
    public enum eWinStatus
    {
        Pending = 0,

        Loser = 1,

        Winner = 2,

        MoneyBack = 3,

        HalfWin = 4,

        HalfLose = 5,

        Unknown = -1,
    }
}
