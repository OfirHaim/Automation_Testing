﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Consts1
{
    public enum eLoginFrom
    {
       
       // Unknown = 0,
       
       // BackOffice = 1,
       
        Terminal = 2,
       
        Server = 3,
       
        MobileTerminal = 4
    }
}
