﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Config
{
    public class App
    {
        public string User { get; set; }
        public string Password { get; set; }
        public string ApiPath { get; set; }
        public string OriginsUrls { get; set; }
        public string OrderPrintTemplate { get; set; }
        public string WithdrawPrintTemplate { get; set; }
        public string DepositPrintTemplate { get; set; }
    }
}

