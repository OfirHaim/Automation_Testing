﻿
namespace GSports.CashBox.Model.Consts
{
    public enum eApiErrorCode
    {
        WithdrawUserIdNotMatchToCode = 1002,
        WithdrawCodeNotFound = 1003,
        DataVlidationError = 1001,
        APIError = 1000
      
    }
}
