﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Consts
{
    public enum ePermissionsLevel
    {
        None = 0,
        Read = 1,
        Update = 3,
        Create = 7,
        Delete = 15
    }
}
