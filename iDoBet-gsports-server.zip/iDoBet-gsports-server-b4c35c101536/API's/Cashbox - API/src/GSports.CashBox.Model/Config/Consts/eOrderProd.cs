﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Consts
{
    public enum eOrderProd
    {

        Unknown = 0,


        Prematch = 1,


        Live = 2,

        Virtual = 3
    }

}
