﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Config
{
    public class EventManager
    {
        public string PushServerURL { get; set; }
        public bool OnlyActiveCoupon { get; set; }
        public bool IsCacheMaster { get; set; }
        public string ChannelName { get; set; }
        public int CheckForChangesEveryMilliseconds { get; set; }
        public int UpdateMessagesLifeTimeMinutes { get; set; }
        public string ProviderIds { get; set; }
        public string SportIds { get; set; }
        public string BetTypeIds { get; set; }    
        
    }
}

