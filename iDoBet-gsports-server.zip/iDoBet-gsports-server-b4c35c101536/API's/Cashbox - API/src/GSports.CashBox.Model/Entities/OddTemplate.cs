﻿using GSports.Clients.EventsManager.Consts;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities
{
    public class OddTemplate
    {
        public OddTemplate() { }

        public OddTemplate(string name)
        {
            Name = name;
        }

        
        public string Name { get; set; }

        public string Shortcut { get; set; }


    }
}
