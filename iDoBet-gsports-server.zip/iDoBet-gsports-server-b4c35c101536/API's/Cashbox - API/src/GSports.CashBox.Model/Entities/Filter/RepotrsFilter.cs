﻿using GSports.CashBox.Model.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace GSports.CashBox.Model.Entities.Filter
{
    public class RepotrsFilter
    {
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public eTimePeriod TimePeriod { get; set; }

    }
}
