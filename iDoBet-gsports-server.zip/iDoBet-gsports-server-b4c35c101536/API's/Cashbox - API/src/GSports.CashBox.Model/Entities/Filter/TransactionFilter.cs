﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Filter
{
    public class TransactionFilter
    {
        public  int? UserId { get; set; }
        public long? ShiftId { get; set; }
        public long? BranchId { get; set; }
        public long? AccountId { get; set; }
        public long? TransactionId { get; set; }
        List<int> TransactionType { get; set; }
        List<int> TransactionReason { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }

    }
}
