﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Filter
{
    public class TransferFilter
    {
        public int? UserId { get; set; }
        public long? ShiftId { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public long? TransferId { get; set; }
        public List<string> TransferRequestTypes { get; set; }
        public List<string> TransferResponseTypes { get; set; }
        public bool? OpenOnly { get; set; }
        public string TransferCode { get; set; }

    }
}
