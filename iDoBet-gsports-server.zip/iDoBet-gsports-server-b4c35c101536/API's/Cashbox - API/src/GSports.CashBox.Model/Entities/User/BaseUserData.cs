﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.User
{
    public class BaseUserData: BaseEntity
    {
        public BaseUserData(string id, string userName,string firstName, string lastName ) : base(id, userName)
        {
            FirstName = firstName;
            LastName = lastName;
            UserName = userName;
        }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string UserName { get; set; }
    }
}
