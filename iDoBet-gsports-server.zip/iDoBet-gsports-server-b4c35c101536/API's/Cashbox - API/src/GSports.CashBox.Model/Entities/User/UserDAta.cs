﻿using GSports.CashBox.Model.Consts;
using GSports.CashBox.Model.Entities.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities
{
    public class UserData: BaseUserData
    {
        public UserData(string id, string userName, string firstName, string lastName) : base(id,userName, firstName, lastName)
        {
        }
        public double? Balance { get; set; }
        public double? Commission { get; set; }
        // public double? ShopBalance { get; set; }

        public double? Holding { get; set; }

        public double? CreditLimit { get; set; }

        public long? AccountId { get; set; }

        public Currency Currency { get; set; }

        public bool IsActivated { get; set; }

        public string Token { get; set; }

        public string Email  { get; set; }

        public Country Country { get; set; }

        public eGender Gender { get; set; }
                
        public string Address { get; set; }

        public string Phone { get; set; }        

        public List<eRole> Roles { get; set; }
        public int? MinBet { get; set; }
        public int? MaxBet { get; set; }
        public int? MaxPayout { get; set; }
        public double? BranchBalance { get; set; }

    }
}

