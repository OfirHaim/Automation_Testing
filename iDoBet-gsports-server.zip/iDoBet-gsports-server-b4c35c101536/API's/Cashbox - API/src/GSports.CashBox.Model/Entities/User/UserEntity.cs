﻿using GSports.CashBox.Model.Consts;
using GSports.CashBox.Model.Entities.Shifts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.User
{
    public class UserEntity
    {
   
        public UserData Data { get; set; }

        public UserShift CurrentShift { get; set; }
   
        public List<Permission> Permissions { get; set; }
    }
}
