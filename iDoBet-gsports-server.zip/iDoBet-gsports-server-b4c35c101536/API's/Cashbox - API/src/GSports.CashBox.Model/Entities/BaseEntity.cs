﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities
{
    public class BaseEntity
    {
        public BaseEntity(string id, string name)
        {
            Id = id;
            Name = name;
        }     
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
