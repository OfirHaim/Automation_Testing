﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.CashBox.Model.Consts;

namespace GSports.CashBox.Model.Entities
{
    public class Permission
    {
        public Permission(string codeAttribute, ePermissionsLevel permissionLevel)
        {
            CodeAttribute = codeAttribute;
            PermissionLevel = permissionLevel;
        }
        public string CodeAttribute { get; set; }
        public ePermissionsLevel PermissionLevel { get; set; }
    }
}
