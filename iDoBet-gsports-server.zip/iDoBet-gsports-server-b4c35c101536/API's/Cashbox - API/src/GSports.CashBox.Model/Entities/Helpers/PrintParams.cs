﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Helpers
{
    // Print class - Client side data
    public class PrintParams
    {
        public DateTime TimeStamp { get; set; }
        public string Currency { get; set; }
        public string TerminalName { get; set; }
        public string BranchName { get; set; }
        public string CashierName { get; set; }
        public string CustomerId { get; set; }

    }

    public class DepositPrintParams : PrintParams
    {
        public string Code { get; set; }
    }

    public class WithdrawPrintParams : PrintParams
    {

    }
}
