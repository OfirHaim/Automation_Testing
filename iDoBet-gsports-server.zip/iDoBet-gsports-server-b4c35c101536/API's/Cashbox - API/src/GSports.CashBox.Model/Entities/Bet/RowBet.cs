﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Bet
{
    public class RowBet
    {
        public double Amount { get; set; }
        public List<string> SelectionKeys { get; set; }
    }
}
