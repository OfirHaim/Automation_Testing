﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Bet
{
    public class SelectionBet
    {
        public string Key { get; set; }

        public long EventId { get; set; }

        public long BetTypeId { get; set; }

        public string OddName { get; set; }

        public string OddLine { get; set; }

        public decimal OddPrice { get; set; }
    }
}
