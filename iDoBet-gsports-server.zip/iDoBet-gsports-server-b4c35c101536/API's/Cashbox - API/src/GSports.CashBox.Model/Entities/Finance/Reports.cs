﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Finance
{
    public class Reports
    {
        public double? Sales { get; set; }

        public int? CountSales { get; set; }

        public double Payout { get; set; }

        public int CountPayout { get; set; }

        public double NetCash { get; set; }
        public DateTime ReportDate { get; set; }

        public double Withdraw { get; set; }

        public int CountWithdraw { get; set; }

        public double Deposit { get; set; }

        public int CountDeposit { get; set; }

        public double Commission { get; set; }
        public double NetProfit { get; set; }
        public double Tax { get; set; }
        public double Bonus { get; set; }
    
    }
}
