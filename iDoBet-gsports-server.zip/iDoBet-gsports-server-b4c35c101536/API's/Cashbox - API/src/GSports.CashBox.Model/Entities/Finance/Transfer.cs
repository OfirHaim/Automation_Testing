﻿using GSports.CashBox.Model.Entities.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Finance
{
    public class Transfer
    {
        public string Id { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime RequestTime { get; set; }
        public DateTime? ResponseTime { get; set; }
        public BaseUserData FromUser { get; set; }
        public BaseUserData ToUser { get; set; }
        public string RequestComments { get; set; }
        public double RequestAmount { get; set; }
        public DateTime? CancelTime { get; set; }
        public string RequestCodeAttribute { get; set; }
        public string ResponseCodeAttribute { get; set; }
        public bool MustApprove { get; set; }

    }
}
