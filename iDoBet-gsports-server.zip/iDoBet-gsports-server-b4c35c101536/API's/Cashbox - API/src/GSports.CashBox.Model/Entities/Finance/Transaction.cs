﻿using GSports.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Finance
{
    public class Transaction : BaseEntity
    {
        public Transaction(string id, string name) : base(id, name)
        {
        }

        public int UserID { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public double Amount { get; set; }
       
        public double CurrentBalance
        {
            get
            {
                return Math.Round(this.OpenBalance + (this.TransactionType.CodeAttribute == CodeAttribute.TransactionType.Credit ? this.Amount : -this.Amount), 2);
            }
        }
        public DateTime CreateTime { get; set; }
        public double OpenBalance { get; set; }
       
        public TransactionReason TransactionReason { get; set; }
        public TransactionType TransactionType { get; set; }

        public double? OpenCommission { get; set; }
        public double? Commission { get; set; }
        public double? CurrentCommission
        {
            get
            {
                if (OpenCommission.HasValue && Commission.HasValue)
                    return Math.Round(this.OpenCommission.Value + (this.TransactionType.CodeAttribute == CodeAttribute.TransactionType.Credit ? this.Commission.Value : -this.Commission.Value), 2);
                else
                    return null;
            }
        }

        public string ReferenceId { get; set; }


    }

    public class TransactionReason
    {
        public string CodeAttribute { get; set; }
    }

    public class TransactionType
    {
        public string CodeAttribute { get; set; }
    }
}
