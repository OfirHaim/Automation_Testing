﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities
{
    public class Terminal : BaseEntity
    {
        public Terminal(int id, string name) : base(id.ToString(), name)
        {
        
        }     
        public bool IsActive { get; set; }     
        public bool IsDeleted { get; set; }

    }
}
