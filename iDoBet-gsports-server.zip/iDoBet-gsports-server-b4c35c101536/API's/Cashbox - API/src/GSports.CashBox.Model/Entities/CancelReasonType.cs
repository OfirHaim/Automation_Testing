﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities
{
    public class CancelReasonType:BaseEntity
    {
        public CancelReasonType(int id, string name) : base(id.ToString(), name)
        {

        }        
        public string Desc { get; set; }
    }
}
