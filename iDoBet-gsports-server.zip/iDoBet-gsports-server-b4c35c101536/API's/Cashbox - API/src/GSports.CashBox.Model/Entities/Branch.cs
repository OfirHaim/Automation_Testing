﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities
{
    public class Branch : BaseEntity
    {
        public Branch(int id, string name) : base(id.ToString(), name)
        {

        }                
        public Currency Currency { get; set; }        
        public int CreditLimit { get; set; }
    }
}
