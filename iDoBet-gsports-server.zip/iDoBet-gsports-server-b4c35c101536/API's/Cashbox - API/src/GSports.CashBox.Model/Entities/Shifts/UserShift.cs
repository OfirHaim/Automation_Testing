﻿using GSports.CashBox.Model.Entities.Finance;
using GSports.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Shifts
{
    public class UserShift : BaseEntity
    {
        public UserShift(long id, string name) : base(id.ToString(), name)
        {

        }
     
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public long ShiftId { get; set; }        
        public long? AccessId { get; set; }
        public double? OpenBalance { get; set; }
        public double? CloseBalance { get; set; }
        public double? OpenHoldings { get; set; }
        public double? CloseHoldings { get; set; }
     
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public bool HasCloseShiftRequest { get; set; }         

        public UserShiftData ShiftData { get; set; }

        public bool IsOpen
        {
            get
            {
                return EndTime == null && ShiftId > 0;
                
            }
        }

   

        
    }
}

