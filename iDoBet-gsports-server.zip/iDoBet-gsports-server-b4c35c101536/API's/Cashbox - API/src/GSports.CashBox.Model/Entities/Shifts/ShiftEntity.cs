﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Shifts
{
    public class ShiftEntity : BaseEntity
    {
        public ShiftEntity(int id,string name) : base(id.ToString(), name)
        {

        }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public int? ManagerId { get; set; }
        public int BranchId { get; set; }
        public List<UserShift> UserInShift { get; set; }
        public bool IsOpen
        {
            get
            {
                return EndTime == null;
            }
        }
    }
}
