﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Shifts
{
    public class UserShiftData
    {
        public long ShiftId { get; set; }
        public int UserId { get; set; }
        public int? OrderCanceledCount { get; set; }
        public int? OrderCount { get; set; }
        public int? PayoutCount { get; set; }      
        public double? TotalCanceled { get; set; }
        public int? TotalOrdersCount { get; set; }
        public double? TotalPayout { get; set; }
        public double? TotalSale { get; set; }     
       
    }
}
