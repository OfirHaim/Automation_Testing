﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace GSports.CashBox.Model.Entities
{

    public class Country : BaseEntity
    {
        public Country(int id, string name) : base(id.ToString(), name)
        {

        }      
    }
}
