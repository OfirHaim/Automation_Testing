﻿using GSports.Clients.EventsManager.Consts;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities
{
    public class BetTypeTemplate
    {
        public BetTypeTemplate() { }

        public BetTypeTemplate(long id, string displayName, bool isLive, long sportTypeId, bool forDisplay, bool isFilter)
        {
            Id = id;
            Name = displayName;
            IsLive = isLive;
            SportTypeId = sportTypeId;
            ForDisplay = forDisplay;
            IsFilter = isFilter;
        }

        public long Id { get; set; }

        public long SportTypeId { get; set; }

        public bool ForDisplay { get; set; }

        public string DisplayLine { get; set; }

        public bool IsFilter { get; set; }
       
        public string Name { get; set; }

        public bool IsLive { get; set; }

        public List<List<OddTemplate>> Odds { get; set; }

    }
}
