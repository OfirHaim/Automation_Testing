﻿using GSports.CashBox.Model.Consts;
using GSports.Clients.EventsManager.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Order
{
    public class OrderBet
    {
        public long Id { get; set; }

        public long OrderRowId { get; set; }

        public long OrderId { get; set; }
        public eWinStatus WinStatus { get; set; }
        public Event Event { get; set; }
    
        public string BetInfo { get; set; }
        public string LiveInfo { get; set; }
        
    }
}
