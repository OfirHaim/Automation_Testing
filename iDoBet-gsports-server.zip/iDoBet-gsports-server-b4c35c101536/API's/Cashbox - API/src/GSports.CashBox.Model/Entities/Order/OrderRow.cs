﻿using GSports.CashBox.Model.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Order
{
    public class OrderRow
    {
        public long Id { get; set; }

        public double Amount { get; set; }

        public List<OrderBet> Bets { get; set; }

        public long OrderId { get; set; }

        public double? TaxAmount { get; set; }
        public double? BonusAmount { get; set; }
        public eWinStatus WinStatus { get; set; }
    }
}
