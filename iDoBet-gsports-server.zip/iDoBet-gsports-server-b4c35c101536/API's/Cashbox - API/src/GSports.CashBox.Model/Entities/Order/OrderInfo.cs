﻿using GSports.CashBox.Model.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.CashBox.Model.Entities.Order
{
    public class OrderInfo
    {
        public long Id { get; set; }

        public string OrderNumber { get; set; }

        public string ExternalId { get; set; }

        public string TransactionId { get; set; }

        public string Barcode { get; set; }
        public double Payout { get; set; }

        public double MaxPayout { get; set; }

        public double NetPayout { get; set; }

        public string RequestGuid { get; set; }

        public DateTime CreationTime { get; set; }

        public double Amount { get; set; }

        public int CurrencyId { get; set; }

        public string CurrencyName { get; set; }

        public eOrderProd OrderProd { get; set; }

        public DateTime? SettledTime { get; set; }

        public DateTime? SoldTime { get; set; }

        public DateTime ExpiryDate { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }

        public eOrderStatus Status { get; set; }

        public eWinStatus WinStatus { get; set; }

        public string UrlKey { get; set; }

        public DateTime? CancelTimePossibile { get; set; }

        public bool IsPayoutPossibile { get; set; }

        public double? TotalTax { get; set; }
        public double? TotalBonus { get; set; }
        public string TotalTaxDescription { get; set; }
        public string TotalBonusDescription { get; set; }
        public int TotalSelections { get; set; }
        public int TotalLines { get; set; }


    }


}
