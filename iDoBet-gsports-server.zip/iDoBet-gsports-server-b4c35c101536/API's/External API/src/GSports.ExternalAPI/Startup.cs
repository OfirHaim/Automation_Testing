﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Routing;
using GSports.Clients.EventsManager;
using Newtonsoft.Json.Serialization;
using GSports.ExternalAPI.Model.ConfigModel;
using Microsoft.Extensions.Options;
using Swashbuckle.SwaggerGen.Generator;
using GSports.GLogger;

namespace GSports.ExternalAPI
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile("clientConfig.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().AddJsonOptions(options =>
            {
                options.SerializerSettings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                options.SerializerSettings.DateFormatHandling = Newtonsoft.Json.DateFormatHandling.IsoDateFormat;
                options.SerializerSettings.DateTimeZoneHandling = Newtonsoft.Json.DateTimeZoneHandling.Utc;
            });
            services.Configure<ClientConfig>(options => Configuration.GetSection("ClientConfig").Bind(options));
            services.AddSwaggerGen(options =>
            {
                options.SingleApiVersion(new Swashbuckle.Swagger.Model.Info { Version = "v1", Title = "My Title" });
                options.DescribeAllEnumsAsStrings();
            });
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, IOptions<ClientConfig> clientConfig)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            //app.UseStaticFiles();

            var routeBuilder = new RouteBuilder(app);
            routeBuilder.Routes.Add(
                new Route(new ClientRouter(),
                "{client}/{controller}/{action}",
                app.ApplicationServices.GetService<IInlineConstraintResolver>()));

            app.UseMvc(x => x.MapRoute("mainRoute", "{client}/{controller}/{action}"));
            app.UseRouter(routeBuilder.Build());
            app.UseMvc(x => x.MapRoute("fallback", "{client}/{controller}/{action}"));

            app.UseSwagger();
            app.UseSwaggerUi();

            app.UseDeveloperExceptionPage();

            var eventManagerConfig = clientConfig.Value.EventManager;
            EventSingleton.InitEventSingelton(eventManagerConfig.PushServerURL,
                                              null,
                                              eventManagerConfig.IsCacheMaster,
                                              eventManagerConfig.ChannelName,
                                              eventManagerConfig.OnlyActiveCoupon,
                                              eventManagerConfig.UpdateMessagesLifeTimeMinutes,
                                              eventManagerConfig.CheckForChangesEveryMilliseconds,
                                              eventManagerConfig.ProviderIds == "*" ? null : eventManagerConfig.ProviderIds,
                                              eventManagerConfig.SportIds == "*" ? null : eventManagerConfig.SportIds,
                                              eventManagerConfig.BetTypeIds == "*" ? null : eventManagerConfig.BetTypeIds
                                              );
            //EventSingleton.InitEventSingelton(null,null,false,null, false,0,4000);
            Logger.WriteLog(eLogLevel.Info, "Service Started");
        }
    }

    public class ClientRouter : IRouter
    {
        public async Task RouteAsync(RouteContext context)
        {
            var name = context.RouteData.Values["client"] as string;
            if (!string.IsNullOrEmpty(name))
                context.HttpContext.Request.Path = context.HttpContext.Request.Path.Value.Replace(name, "shared");
        }

        public VirtualPathData GetVirtualPath(VirtualPathContext context)
        {
            return null;
        }
    }
}
