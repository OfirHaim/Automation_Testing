﻿using GSports.Common;
using GSports.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Context.Channel
{
    class GSportsChannelFactory<T> : ChannelFactory<T>
    {
        Dictionary<Type, string> endpointNames = new Dictionary<Type, string>()
        {
            {typeof(IAlertsService), ServiceConsts.ALERTS_SERVICE },
            {typeof(IAuthenticationService), ServiceConsts.AUTHENTICATION_SERVICE },
            {typeof(IBackOfficeService), ServiceConsts.BACK_OFFICE_SERVICE },
            {typeof(IBetRadarLiveService), ServiceConsts.BETRADAR_LIVE_SERVICE },
            {typeof(IBetMetadata), ServiceConsts.BET_METADATA_SERVICE },
            {typeof(IBetService), ServiceConsts.BET_SERVICE },
            {typeof(ICacheService), ServiceConsts.CACHE_SERVICE },
            {typeof(IEventService), ServiceConsts.EVENT_SERVICE },
            {typeof(IFinanceService), ServiceConsts.FINANCE_SERVICE },
            {typeof(IKeepAlive), ServiceConsts.KEEP_ALIVE_SERVICE },
            {typeof(INotificationService), ServiceConsts.NOTIFICATION_SERVICE },
            {typeof(IOddsArchiver), ServiceConsts.ODDS_ARCHIVER },
            {typeof(IPrematchBroadcastService), ServiceConsts.PREAMATCH_BROADCAST_SERVICE },
            {typeof(IUserService), ServiceConsts.USER_SERVICE },
        };

        public GSportsChannelFactory() : base()
        {
            this.ApplyConfiguration(endpointNames[typeof(T)]);
            //TODO: add user details to Transport
            this.Credentials.UserName.UserName = "a";
            this.Credentials.UserName.Password = "b";

#if DEBUG
            //TODO: remove on production! danger! [Trust all SSL certificates]
            System.Net.ServicePointManager.ServerCertificateValidationCallback = ((sender, certificate, chain, sslPolicyErrors) => true);
#endif
        }
    }
}
