﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Channels
{
    public class HttpChannel
    {
        public static async Task<dynamic> Post(string url, object req)
        {
            dynamic res;

            var httpRequest = WebRequest.CreateHttp(url);
            httpRequest.Method = "POST";
            httpRequest.ContentType = "application/x-www-form-urlencoded";
            httpRequest.Accept = "application/json";

            using (var streamWriter = new StreamWriter(await httpRequest.GetRequestStreamAsync()))
            {
                string json = JsonConvert.SerializeObject(req);
                streamWriter.Write(json);
                streamWriter.Flush();
                streamWriter.Close();
            }
            var response = await httpRequest.GetResponseAsync();
            using (var reader = new StreamReader(response.GetResponseStream(), Encoding.ASCII))
            {
                string responseText = reader.ReadToEnd();
                res = JsonConvert.DeserializeObject<dynamic>(responseText);
            }

            return res;
        }
    }
}
