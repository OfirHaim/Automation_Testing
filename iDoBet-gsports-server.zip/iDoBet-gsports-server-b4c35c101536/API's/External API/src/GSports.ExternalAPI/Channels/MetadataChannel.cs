﻿//using GSports.Common;
//using GSports.Model.Filter;
//using GSports.Contracts;
//using System;
//using GSports.GLogger;
//using GSports.Model.Requests.Metadata;
//using System.Linq;
//using System.Collections.Generic;
//using GSports.Model.Responses.Metadata;

//namespace GSports.ExternalAPI.Context.Channel
//{
//    public class MetadataChannel
//    {
//        public static GetItemsResponse GetBetTypeTemplate(GetItemsRequest request)
//        {
//            GetItemsResponse retVal = new GetItemsResponse();
//            try
//            {
//                using (var factory = new GSportsChannelFactory<IBetMetadata>())
//                {
//                    var service = factory.CreateChannel();
//                    retVal = service.GetItems(new GetItemsRequest() { Type = MetadataType.BetType, Filter = new BetTypeFilter() { All = true } });
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }

//            return retVal;
//        }
//    }
//}
