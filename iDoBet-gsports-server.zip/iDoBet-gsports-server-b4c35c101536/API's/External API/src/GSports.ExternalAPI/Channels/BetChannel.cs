﻿//using GSports.Common;
//using GSports.Contracts;
//using GSports.GLogger;
//using GSports.Model.Requests.Order;
//using GSports.Model.Responses.Order;
//using GSports.ExternalAPI.Model.Request.BetService;
//using GSports.ExternalAPI.Model.Response.BetService;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace GSports.ExternalAPI.Context.Channel
//{
//    public class BetChannel
//    {
//        public static OrderResponse RequestForOrder(OrderRequest request)
//        {
//            try
//            {
//                using (var factory = new GSportsChannelFactory<IBetService>())
//                {
//                    var service = factory.CreateChannel();
//                    return service.RequestForOrder(request);
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }
//            return null;
//        }

//        public static ExecuteOrderResponse ExecuteOrder(ExecuteOrderRequest request)
//        {
//            try
//            {
//                using (var factory = new GSportsChannelFactory<IBetService>())
//                {
//                    var service = factory.CreateChannel();
//                    return service.ExecuteOrder(request);
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }
//            return null;
//        }

//        public static GetBetOrderResponse GetBetOrders(GetBetOrderRequest request)
//        {
//            GetBetOrderResponse retVal = new GetBetOrderResponse();
//            try
//            {
//                using (var factory = new GSportsChannelFactory<IBetService>())
//                {
//                    var service = factory.CreateChannel();
//                    retVal = service.GetBetOrders(request);
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }
//            return retVal;
//        }

//        public static GetOrdersDataResponse GetBetOrderData(GetOrdersDataRequest request)
//        {
//            var retVal = new GetOrdersDataResponse();
//            try
//            {
//                using (var factory = new GSportsChannelFactory<IBetService>())
//                {
//                    var service = factory.CreateChannel();
//                    retVal = service.GetOrdersData(request);
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }
//            return retVal;
//        }

//    }
//}


