﻿using GSports.Contracts;
using GSports.ExternalAPI.Context.Channel;
using GSports.ExternalAPI.Model.Response;
using GSports.GLogger;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace GSports.ExternalAPI.Channels
{
    public class GSportsChannel
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="TResponse">Represents the client response return type</typeparam>
        /// <typeparam name="TRequest">Represents the request type of the server request</typeparam>
        /// <typeparam name="TChannel">Pick a GSports contract</typeparam>
        /// <param name="expr"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        public static TResponse GetAndConvert<TResponse, TRequest, TChannel>(Expression<Func<TChannel, Func<TRequest, object>>> expr, Model.Request.BaseRequest request) 
                                                                    where TResponse : BaseResponse, new() 
                                                                    where TChannel : IServiceContractBase
                                                                    where TRequest : GSports.Model.Requests.BaseRequest
        {
            TResponse retVal = new TResponse();

            try
            {
                if (request == null)
                    retVal.SetErrorResult(Model.Response.Base.eErrorCode.BadRequest, "request is null");
                else
                {
                    if (request.IsValidRequest(retVal))
                    {
                        var serverRequest = request.ConvertToServerRequest();

                        using (var factory = new GSportsChannelFactory<TChannel>())
                        {
                            var unary = (UnaryExpression)expr.Body;
                            var methodCall = (MethodCallExpression)unary.Operand;
                            var obj = (ConstantExpression)methodCall.Object;
                            var method = (MethodInfo)obj.Value;

                            var service = factory.CreateChannel();
                            var res = service.GetType().GetMethod(method.Name).Invoke(service, new[] { serverRequest }) as GSports.Model.Responses.BaseResponse;
                            retVal.ConvertResponseFromServer(res);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

        public static TResponse Get<TResponse, TRequest, TChannel>(Expression<Func<TChannel, Func<TRequest, object>>> expr, TRequest request)
                                                                    where TResponse : GSports.Model.Responses.BaseResponse, new()
                                                                    where TChannel : IServiceContractBase
                                                                    where TRequest : GSports.Model.Requests.BaseRequest
        {
            TResponse retVal = new TResponse();

            try
            {                
                using (var factory = new GSportsChannelFactory<TChannel>())
                {
                    var unary = (UnaryExpression)expr.Body;
                    var methodCall = (MethodCallExpression)unary.Operand;
                    var obj = (ConstantExpression)methodCall.Object;
                    var method = (MethodInfo)obj.Value;

                    var service = factory.CreateChannel();
                    retVal = service.GetType().GetMethod(method.Name).Invoke(service, new[] { request }) as TResponse;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }

    }
}
