﻿using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using GSports.Model.Entities.User;
using GSports.Model.Filter;
using GSports.Model.Requests.Authentication;
using GSports.Model.Requests.UserService;
using GSports.Model.Security;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Context.Channel
{
    public static class UserChannel
    {
        public static ClientUser LoginUser(string userName, string password, string ip)
        {
            SystemUser retVal = null;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>())
                {
                    var req = new LoginRequest()
                    {
                        UserName = userName,
                        Password = password,
                        IP = ip,
                        LoginFrom = eLoginFrom.BackOffice,
                    };
                    var service = factory.CreateChannel();
                    var res = service.LoginUser(req);
                    if (!string.IsNullOrEmpty(res.Token))
                    {
                        retVal = GetUser(res.Token);
                    }
                    else
                        return null;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal as ClientUser;
        }

        public static ClientUser GetUser(string token)
        {
            ClientUser retVal = null;
            try
            {
                using (var userFactory = new GSportsChannelFactory<IUserService>())
                {
                    var userService = userFactory.CreateChannel();
                    var request = new GetUsersRequest()
                    {
                        UserToken = token,
                        Filter = new UserFilter(token)
                        {
                            LoadMatrix = true,
                            LoadLastAccess = true,
                            IncludeServices = true
                        }
                    };
                    retVal = userService.GetUsers(request)?.Users?.SingleOrDefault() as ClientUser;
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static int RegisterUser(ClientUser user, string password)
        {
            int retVal = -1;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>())
                {
                    var service = factory.CreateChannel();
                    retVal = service.CreateUser(user, password);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static bool ActivateAccount(string code)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>())
                {
                    var service = factory.CreateChannel();
                    retVal = service.ActivateOnlineAccount(new ActivateOnlineAccountRequest() { Code = code }).IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static bool ResendActivationLink(int userId)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>())
                {
                    var service = factory.CreateChannel();
                    var user = new ResendActivationCodeRequest() { UserId = userId };
                    retVal = service.ResendActivationCodeToClient(user).IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static bool UpdateUser(ClientUser user)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<IUserService>())
                {
                    var service = factory.CreateChannel();
                    retVal = service.UpdateUser(new UpdateUserRequest() { User = user }).IsSuccessfull();
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }

        public static string GetUserInfo(string token)
        {
            var retVal = string.Empty;
            try
            {
                using (var factory = new GSportsChannelFactory<IUserService>())
                {
                    var service = factory.CreateChannel();
                    retVal = service.GetUserInfo(token);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }
        public static  bool IsValidToken(string token)
        {
            bool retVal = false;
            try
            {
                using (var factory = new GSportsChannelFactory<IAuthenticationService>())
                {

                    var service = factory.CreateChannel();
                    retVal = service.IsTokenValid(token);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }
            return retVal;
        }
    }
 

}
