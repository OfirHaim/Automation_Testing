﻿//using GSports.Common;
//using GSports.Contracts;
//using GSports.GLogger;
//using GSports.Model.Requests;
//using GSports.Model.Requests.Finance;
//using GSports.Model.Requests.Order;
//using GSports.Model.Responses;
//using GSports.Model.Responses.Finance;
//using GSports.Model.Responses.Order;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Linq.Expressions;
//using System.Reflection;
//using System.Threading.Tasks;

//namespace GSports.ExternalAPI.Context.Channel
//{
//    public class FinanceChannel
//    {
//        public static GetTransactionsResponse GetTranscations(GetTransactionsRequest request)
//        {
//            GetTransactionsResponse retVal = new GetTransactionsResponse();
//            try
//            {
//                using (var factory = new GSportsChannelFactory<IFinanceService>())
//                {
//                    var service = factory.CreateChannel();
//                    retVal = service.GetTransactions(request);
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }
//            return retVal;
//        }

//        public static bool Deposit(string token, string code)
//        {
//            bool retVal = false;

//            try
//            {
//                using (var factory = new GSportsChannelFactory<IFinanceService>())
//                {
//                    var service = factory.CreateChannel();
//                    var res = service.UpdateTransfer(new GSports.Model.Requests.Finance.UpdateTransferRequest()
//                    {
//                        UserToken = token,
//                        TransferCode = code,
//                        ResponseTypeCodeAttr = Common.CodeAttribute.TransferResponseType.Approved
//                    });
//                    retVal = res.IsSuccessfull();
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }

//            return retVal;
//        }

//        public static InsertWithdrawResponse Withdraw(InsertWithdrawRequest request)
//        {
//            InsertWithdrawResponse retVal = new InsertWithdrawResponse();

//            try
//            {
//                using (var factory = new GSportsChannelFactory<IFinanceService>())
//                {
//                    var service = factory.CreateChannel();
//                    retVal = service.InsertWithdraw(request);
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }

//            return retVal;
//        }

//        public static bool CancelWithdraw(string token, long transferId)
//        {
//            bool retVal = false;

//            try
//            {
//                using (var factory = new GSportsChannelFactory<IFinanceService>())
//                {
//                    var service = factory.CreateChannel();
//                    var res = service.UpdateTransfer(new GSports.Model.Requests.Finance.UpdateTransferRequest()
//                    {
//                        UserToken = token,
//                        TransferId = transferId,
//                        ResponseTypeCodeAttr = Common.CodeAttribute.TransferResponseType.Cancel
//                    });
//                    retVal = res.IsSuccessfull();
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }

//            return retVal;
//        }

//        public static GetTransfersResponse GetTransferHistory(GetTransfersRequest request)
//        {
//            GetTransfersResponse retVal = new GetTransfersResponse();
//            try
//            {
//                using (var factory = new GSportsChannelFactory<IFinanceService>())
//                {

//                    var service = factory.CreateChannel();
//                    retVal = service.GetTransfers(request);
//                }
//            }
//            catch (Exception ex)
//            {
//                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
//            }

//            return retVal;
//        }
//    }
//}


