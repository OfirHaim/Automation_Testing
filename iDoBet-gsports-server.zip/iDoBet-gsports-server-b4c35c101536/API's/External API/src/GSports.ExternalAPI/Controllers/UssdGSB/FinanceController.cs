﻿using GSports.Common;
using GSports.Contracts;
using GSports.ExternalAPI.BL;
using GSports.ExternalAPI.Channels;
using GSports.ExternalAPI.Model.ConfigModel;
using GSports.ExternalAPI.Model.Request.FinanceService;
using GSports.ExternalAPI.Model.Response.Base;
using GSports.ExternalAPI.Model.Response.FinanceService;
using GSports.Model.Requests.UserService;
using GSports.Model.Responses.UserService;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Controllers.UssdGSB
{
    [Route("ussd-uganda/[controller]/[action]")]
    public class FinanceController : Controller
    {
        private IOptions<ClientConfig> _clientConfig;

        public FinanceController(IOptions<ClientConfig> clientConfig)
        {
            _clientConfig = clientConfig;
        }

        /// <summary>
        /// Creating a deposit transaction
        /// </summary>
        /// <param name="request">Should provide amount and to which user</param>
        /// <returns>Response contains barcode</returns>
        [HttpPost]
        [LogFilterAtrribute]
        public async Task<DepositResponse> Deposit([FromBody] DepositRequest request)
        {
            var retVal = new DepositResponse();
            if (request.IsValidRequest(retVal))
            {
                try
                {
                    // check user token for external API like GSB
                    if (!Context.Channel.UserChannel.IsValidToken(request.UserToken))
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("Token is not valid  {0}", request.UserToken));
                        return retVal;
                    }
                    int externalCode = -1;
                    if (!string.IsNullOrEmpty(request.ExternalID) && !int.TryParse(request.ExternalID, out externalCode))
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("ExternalID must number {0}", request.ExternalID));
                        return retVal;
                    }
                    var req = new
                    {
                        id = request.ToUserId,
                        token = _clientConfig.Value.GsbConnection.SecurityToken,
                        amount = request.Amount,
                        transferCode = externalCode,
                        message = string.IsNullOrEmpty(request.ExternalID) ? "" : string.Format("USSD Code - {0}", request.ExternalID)
                    };

                    var url = _clientConfig.Value.GsbConnection.DepositUrl;
                    var res = await HttpChannel.Post(url, req);

                    if (res.error.ToString() == "0")
                        retVal.Code = res.code.ToString();
                    else
                        retVal.SetErrorResult(eErrorCode.InternalServerError, string.Format("GSB Deposit request has failed! error code:{0} msg: {1}", res.error, res.message));
                }
                catch (Exception ex)
                {
                    retVal.SetErrorResult(eErrorCode.InternalServerError, ex.Message);
                }
            }
            return retVal;
        }

        /// <summary>
        /// creating a withdraw transaction
        /// </summary>
        /// <param name="request">Should provide code</param>
        /// <returns>Response contains the withdrawn amount</returns>
        [HttpPost]
        [LogFilterAtrribute]
        public async Task<WithdrawResponse> Withdraw([FromBody] WithdrawRequest request)
        {

            var retVal = new WithdrawResponse();
            if (request.IsValidRequest(retVal))
            {
                try
                {
                    // check user token for external API like GSB
                    if (!Context.Channel.UserChannel.IsValidToken(request.UserToken))
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("Token is not valid  {0}", request.UserToken));
                        return retVal;
                    }
                    int externalCode = -1;
                    if (!string.IsNullOrEmpty(request.ExternalID) && !int.TryParse(request.ExternalID, out externalCode))
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("ExternalID must number {0}", request.ExternalID));
                        return retVal;
                    }
                    var resTransferInfo = await TransferInfo(new TransferInfoRequest() { UserToken = request.UserToken, CustomerCode = request.Code, Type = CodeAttribute.TransferRequestType.OnlineWithdrawalRequest });
                    if(!resTransferInfo.IsSuccessfull || resTransferInfo.Transfers==null || resTransferInfo.Transfers.Count !=1)
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("transfer not found code {0}", request.Code));
                        return retVal;

                    }
                    else
                    {
                        var transfer = resTransferInfo.Transfers[0];
                        if (transfer.Status != CodeAttribute.TransferResponseType.Pending)
                        {
                            retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("transfer status is not pending, status = {0}", transfer.Status));
                            return retVal;
                        }
                        if (transfer.RequestAmount != request.Amount)
                        {
                            retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("transfer amount does not match to request amount, transfer amount = {0}, Request anount = {1}", transfer.RequestAmount, request.Amount));
                            return retVal;
                        }
                        if (transfer.FromUser.Id != request.UserId.ToString())
                        {
                            retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("transfer user id does not match to request user id"));
                            return retVal;
                        }
                    }
                    //var getUserRequest = new GetUsersRequest() { UserToken = request.UserToken };
                    //var user = GSportsChannel.Get<GetUsersResponse, GetUsersRequest, IUserService>(x => x.GetUsers, getUserRequest);
                    var req = new
                    {
                        id = request.UserId,
                        token = _clientConfig.Value.GsbConnection.SecurityToken,
                        code = request.Code,
                        transferCode = externalCode,
                        message = string.IsNullOrEmpty(request.ExternalID) ? "" : string.Format("USSD Code - {0}", request.ExternalID)

                    };

                    var url = _clientConfig.Value.GsbConnection.WithdrawUrl;
                    var res = await HttpChannel.Post(url, req);

                    if (res.error.ToString() == "0")
                        retVal.Amount = Convert.ToDouble(res.amount);
                    else
                        retVal.SetErrorResult(eErrorCode.InternalServerError, string.Format("GSB Withdraw request has failed! error code:{0} msg: {1}", res.error, res.message));
                }
                catch (Exception ex)
                {
                    retVal.SetErrorResult(eErrorCode.InternalServerError, ex.Message);
                }
            }

            return retVal;
        }


        /// <summary>
        /// Returns info for this transfer such as customer id, amount, status etc.
        /// </summary>    
        [HttpPost]
        [LogFilterAtrribute]
        public async Task<TransferInfoResponse> TransferInfo([FromBody] TransferInfoRequest request)
        {
            var retVal = new TransferInfoResponse();
            if (request.IsValidRequest(retVal))
            {
                try
                {
                    // check user token for external API like GSB
                    if (!Context.Channel.UserChannel.IsValidToken(request.UserToken))
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("Token is not valid  {0}", request.UserToken));
                        return retVal;
                    }
                    string type = ConvertIDoBetTypeToGSBType(request.Type);
                    if (string.IsNullOrEmpty(type))
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("Type request incorrect {0}", request.Type));
                        return retVal;
                    }

                    var req = new
                    {
                        token = _clientConfig.Value.GsbConnection.SecurityToken,                      
                        code = request.CustomerCode,
                        transferType = type
                    };

                    var url = _clientConfig.Value.GsbConnection.TransferInfoUrl;
                    var res = await HttpChannel.Post(url, req);

                    if (res.error.ToString() == "0")
                    {
                        retVal.Transfers = new System.Collections.Generic.List<Model.Entities.Transfer>();
                        retVal.Transfers.Add(new Model.Entities.Transfer()
                        {
                            Id = res.transfer.requestTs,
                            FromUser = new Model.Entities.BaseEntity()
                            {
                                Id = res.transfer.customerId
                            },
                            RequestAmount = res.transfer.amount,
                            CustomerCode = res.transfer.customerCode,

                            ExternalId = res.transfer.transferCode,
                            Status = ConvertGSBStatusToIDoBetStatus(res.transfer.status as string),
                            Type = ConvertGSBTypeToIDoBetType(res.transfer.type as string)
                        }
                        );
                    }
                    else
                        retVal.SetErrorResult(eErrorCode.InternalServerError, string.Format("GSB get transfer info has failed! error code:{0} msg: {1}", res.error, res.message));
                }
                catch (Exception ex)
                {
                    retVal.SetErrorResult(eErrorCode.InternalServerError, ex.Message);
                }
            }
            return retVal;
        }

        private string ConvertIDoBetTypeToGSBType(string type)
        {

            switch (type)
            {
                case CodeAttribute.TransferRequestType.OnlineWithdrawalRequest:
                    return "withdraw";
                case CodeAttribute.TransferRequestType.PrepaidDeposit:
                    return "deposit";
                default:
                    return "";
            }


        }
        private string ConvertGSBTypeToIDoBetType(string type)
        {

            switch (type)
            {
                case "deposit":
                    return CodeAttribute.TransferRequestType.OnlineWithdrawalRequest;
                case "withdraw":
                    return CodeAttribute.TransferRequestType.PrepaidDeposit;
                default:
                    return "";
            }


        }

        string ConvertGSBStatusToIDoBetStatus(string gsbStatus)
        {
            switch (gsbStatus)
            {
                case "pending":
                    return CodeAttribute.TransferResponseType.Pending;
                case "cancelled":
                    return CodeAttribute.TransferResponseType.Cancel;
                case "completed":
                    return CodeAttribute.TransferResponseType.Approved;
                default:
                    return "";
            }

        }
    }
}
