﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GSports.Clients.EventsManager;
using Microsoft.Extensions.Options;
using GSports.ExternalAPI.Model.ConfigModel;
using GSports.Clients.EventsManager.Model.Entities.Enums;
using GSports.ExternalAPI.Model.Request.EventService;
using GSports.ExternalAPI.Model.Response.EventService;
using GSports.ExternalAPI.Model.Helpers;
using GSports.ExternalAPI.Model.Response.Base;

namespace GSports.ExternalAPI.Controllers.Ussd
{
    [Route("ussd/[controller]/[action]")]    
    public class EventController : Controller
    {
        private IOptions<ClientConfig> _clientConfig;
        public EventController(IOptions<ClientConfig> clientConfig)
        {
            _clientConfig = clientConfig;
        }
        /// <summary>
        /// Retrives events for ussd
        /// </summary>
        /// <param name="lastUpdate">Optional. if provided events will be filtered by the last update</param>
        /// <returns></returns>
        public GetEventsResponse GetEvents(GetEventsRequest reqeust)
        {
            
            GetEventsResponse retVal = new GetEventsResponse();
            if (reqeust.IsValidRequest(retVal))
            {
                if (EventSingleton.Instance != null)
                {
                    DateTime? LastUpdate = null;
                    if (reqeust.LastTimestamp.HasValue)
                        LastUpdate = DateTimeHelper.FromUnixTime(reqeust.LastTimestamp.Value);
                    retVal.LastTimestamp = DateTimeHelper.ToUnixTime(EventSingleton.Instance.LastUpdate);
                    //retVal.ActiveCoupinIds = EventSingleton.Instance.ac
                    var res = EventSingleton.Instance.GetEvents(LastUpdate,
                                                                reqeust.ActiveCoupon,
                                                                reqeust.CoupinIds,
                                                                reqeust.EventIds,
                                                                reqeust.Skip,
                                                                reqeust.Take);
                    if (res != null)
                    {
                        var events = res.ToList();
                        // filter for ussd 
                        var settings = _clientConfig?.Value?.Settings?.FirstOrDefault(x => x.Name == "ussd");
                        if (settings != null)
                        {
                            if (events != null)
                            {
                                events = events.Where(x =>
                                                (settings.TopEventsOnly ? x.EventData.TopEventOrder.HasValue && x.EventData.TopEventOrder.Value > 0 : true)
                                                && (settings.Live ? true : !x.IsLive)
                                                && (settings.Prematch ? true : x.IsLive)
                                                && (settings.SportTypeIds.Any() ? settings.SportTypeIds.Contains(x.EventData.SportTypeId) : true)
                                                && (settings.OnlyActiveCoupon ? int.Parse(x.EventData.GameNumber ?? "0") > 0 : true)
                                            ).OrderBy(x => x.EventData.TopEventOrder).ThenBy(x => x.EventData.GameTime).ThenBy(x => x.EventData.HomeTeamName).ToList();

                                if (settings.BetTypeIds.Any())
                                    events.ForEach(x =>
                                    {
                                        x.BetTypes = x.BetTypes.Where(b => settings.BetTypeIds.Contains(b.CompareKey)).OrderBy(o => settings.BetTypeIds.IndexOf(o.CompareKey)).ToList();
                                        x.BetTypes.ForEach(bt => bt.Odds = bt.Odds.OrderBy(o => o.OrderRow ?? 0).ThenBy(o => o.OrderCol ?? 0).ToList());
                                    });

                            }
                        }

                        retVal.ActiveCoupinIds = EventSingleton.Instance.ActiveCouponIds.ToList();
                        retVal.Events = events.ToList();
                        retVal.TotalEventCount = EventSingleton.Instance.EvnetCount;
                    }
                    else
                        retVal.SetErrorResult(eErrorCode.CacheNotReady, "Event cache is not ready!!!");
                }
                else retVal.SetErrorResult(eErrorCode.CacheNotReady, "Event cache is not ready!!!");
            }
             return retVal;
        }
    }
}


