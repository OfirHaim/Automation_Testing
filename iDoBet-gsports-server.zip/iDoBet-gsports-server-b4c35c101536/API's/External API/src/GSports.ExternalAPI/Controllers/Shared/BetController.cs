﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GSports.ExternalAPI.Channels;
using GSports.Contracts;
//using GSports.Model.Requests.Order;
//using GSports.Model.Responses.Order;
using System.Threading;
using GSports.ExternalAPI.Model.Response.Base;
using GSports.GLogger;
using GSports.ExternalAPI.Model.Response.BetService;
using GSports.ExternalAPI.Model.Request.BetService;
using System.Text;
using GSports.ExternalAPI.BL;

namespace GSports.ExternalAPI.Controllers.Shared
{
    [Route("shared/[controller]/[action]")]
    public class BetController : Controller
    {
        /// <summary>
        /// Placing bet in the system
        /// </summary>
        /// <param name="request">Contains a list of selections (bet data) and a list of rows (the connection between the bets and their amount)</param>
        /// <returns>
        /// Returns the new created order if success. Else returns validation errors
        /// </returns>
        [HttpPost]
        [LogFilterAtrribute]
        public async Task<PlaceBetsResponse> PlaceBet([FromBody] PlaceBetsRequest request)
        {
            var task = Task.Run(() =>
            {
                var retVal = new PlaceBetsResponse();
                try
                {   if (request.IsValidRequest(retVal))
                    {
                        var serverResponse = GSportsChannel.Get<GSports.Model.Responses.Order.OrderResponse, GSports.Model.Requests.Order.OrderRequest, IBetService>(x => x.RequestForOrder, request.ConvertToServerRequest() as GSports.Model.Requests.Order.OrderRequest);
                        if (serverResponse.IsSuccessfull())
                        {
                            Thread.Sleep(serverResponse.Timeout);
                            var serverOrderResponse = GSportsChannel.Get<GSports.Model.Responses.Order.ExecuteOrderResponse, GSports.Model.Requests.Order.ExecuteOrderRequest, IBetService>(x => x.ExecuteOrder, new GSports.Model.Requests.Order.ExecuteOrderRequest() { UserToken = request.UserToken, TimeoutGuid = serverResponse.TimeoutGuid });

                            retVal.ConvertResponseFromServer(serverOrderResponse);
                        }
                        else
                        {
                            var str = new StringBuilder();
                            serverResponse.ValidationResult.ForEach(x => x.OrderBetValidationResults.ForEach(f => str.AppendLine(f.Message)));
                            retVal.SetErrorResult(eErrorCode.InternalServerError, str.ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
                    retVal.SetErrorResult(eErrorCode.InternalServerError, "Request for order failed");
                    Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
                }
                return retVal;
            });

            return await task;
        }

        [HttpPost]
        [LogFilterAtrribute]
        public RequestForOrderResponse RequestForOrder([FromBody]RequestForOrderRequest request)
        {
            return GSportsChannel.GetAndConvert<RequestForOrderResponse, GSports.Model.Requests.Order.OrderRequest, IBetService>(x => x.RequestForOrder, request);      
        }

        [HttpPost]
        [LogFilterAtrribute]
        public ExecuteOrderResponse ExecuteOrder([FromBody]ExecuteOrderRequest request)
        {
            return GSportsChannel.GetAndConvert<ExecuteOrderResponse, GSports.Model.Requests.Order.ExecuteOrderRequest, IBetService>(x => x.ExecuteOrder, request);
        }
        /// <summary>
        /// Making a payment for a payable ticket
        /// </summary>
        /// <param name="request">Should provide the barcode of the ticket</param>
        /// <returns></returns>
        [HttpPost]
        [LogFilterAtrribute]
        public PayoutResponse DoPayout([FromBody] PayoutRequest request)
        {
            return GSportsChannel.GetAndConvert<PayoutResponse, GSports.Model.Requests.Order.DoPayoutRequest, IBetService>(x => x.DoPayout, request);
        }

        /// <summary>
        /// Retrives all orders by filter
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpGet]
        [LogFilterAtrribute]
        public GetOrdersResponse GetOrders(GetOrdersRequest request)
        {
            return GSportsChannel.GetAndConvert<GetOrdersResponse, GSports.Model.Requests.Order.GetBetOrderRequest, IBetService>(x => x.GetBetOrders, request);
        }
    }
    
}
