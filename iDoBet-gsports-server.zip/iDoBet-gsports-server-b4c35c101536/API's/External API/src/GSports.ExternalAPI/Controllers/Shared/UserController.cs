﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GSports.ExternalAPI.Model.Request.UserService;
using GSports.ExternalAPI.Model.Response.UserService;
using GSports.Contracts;
using GSports.ExternalAPI.BL;

namespace GSports.ExternalAPI.Controllers.Shared
{
    [Route("shared/[controller]/[action]")]
    public class UserController : Controller
    {
        /// <summary>
        /// Loging in an existing user
        /// </summary>
        /// <param name="request">Should provide Email & password</param>
        /// <returns>Response contains user's temporary token for use in the next session requests</returns>
        [HttpPost]
        [LogFilterAtrribute]
        public LoginResponse LoginUser([FromBody] LoginRequest request)
        {
            return Channels.GSportsChannel.GetAndConvert<LoginResponse, GSports.Model.Requests.Authentication.LoginRequest, IAuthenticationService>(x => x.LoginUser, request);
        }

        /// <summary>
        /// Logs out a logged in user
        /// </summary>
        /// <param name="request">Should provide user's current token</param>
        /// <returns></returns>
        [HttpPost]
        [LogFilterAtrribute]
        public LogoutUserResponse LogoutUser([FromBody] LogoutUserRequest request)
        {
            return Channels.GSportsChannel.GetAndConvert<LogoutUserResponse, GSports.Model.Requests.Authentication.LogoutRequest, IAuthenticationService>(x => x.LogoutUser, request);
        }
    }
}
