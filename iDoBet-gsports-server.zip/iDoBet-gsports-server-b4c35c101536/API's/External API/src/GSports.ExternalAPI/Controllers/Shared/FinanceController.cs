﻿using Microsoft.AspNetCore.Mvc;
using GSports.ExternalAPI.Model.Response.FinanceService;
using GSports.ExternalAPI.Model.Request.FinanceService;
using GSports.ExternalAPI.Context.Channel;
using GSports.Model.Responses.Finance;
using GSports.Contracts;
using GSports.Model.Requests.Finance;
using System;
using GSports.ExternalAPI.Channels;
using GSports.ExternalAPI.BL;
using GSports.ExternalAPI.Model.Response.Base;

namespace GSports.ExternalAPI.Controllers.Shared
{
    [Route("shared/[controller]/[action]")]
    public class FinanceController : Controller
    {
        /// <summary>
        /// Creating a deposit transaction
        /// </summary>
        /// <param name="request">Should provide amount and to which user</param>
        /// <returns>Response contains barcode</returns>
        [HttpPost]
        [LogFilterAtrribute]
        public DepositResponse Deposit([FromBody] DepositRequest request)
        {
            return GSportsChannel.GetAndConvert<DepositResponse, InsertDepositRequest, IFinanceService>(x => x.InsertDeposit, request);
        }

        /// <summary>
        /// creating a withdraw transaction
        /// </summary>
        /// <param name="request">Should provide code</param>
        /// <returns>Response contains the withdrawn amount</returns>
        [HttpPost]
        [LogFilterAtrribute]
        public WithdrawResponse Withdraw([FromBody] WithdrawRequest request)
        {
            WithdrawResponse retVal = new WithdrawResponse();
            if (request.IsValidRequest(retVal))
            {
                var res = TransferInfo(new TransferInfoRequest() { UserToken = request.UserToken, CustomerCode = request.Code, Type = Common.CodeAttribute.TransferRequestType.OnlineWithdrawalRequest });
                if (!res.IsSuccessfull || res.Transfers == null || res.Transfers.Count != 1)
                {
                    retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("transfer not found code {0}", request.Code));
                    return retVal;

                }
                else
                {
                    var transfer = res.Transfers[0];
                    if (transfer.Status != Common.CodeAttribute.TransferResponseType.Pending)
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("transfer status is not pending, status = {0}", transfer.Status));
                        return retVal;
                    }
                    if (transfer.RequestAmount != request.Amount)
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("transfer amount does not match to request amount, transfer amount = {0}, Request anount = {1}", transfer.RequestAmount, request.Amount));
                        return retVal;
                    }
                    if (transfer.FromUser.Id != request.UserId.ToString())
                    {
                        retVal.SetErrorResult(eErrorCode.BadRequest, string.Format("transfer user id does not match to request user id"));
                        return retVal;
                    }
                }

                retVal = GSportsChannel.GetAndConvert<WithdrawResponse, CommitWithdrawRequest, IFinanceService>(x => x.CommitWithdraw, request);
            }
            return retVal;
        }

        /// <summary>
        /// Returns info for this transfer such as customer id, amount, status etc.
        /// </summary>    
        [HttpPost]
        [LogFilterAtrribute]
        public TransferInfoResponse TransferInfo([FromBody] TransferInfoRequest request)
        {
            return GSportsChannel.GetAndConvert<TransferInfoResponse, GetTransfersRequest, IFinanceService>(x => x.GetTransfers, request);
        }
    }
}
