﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using GSports.Clients.EventsManager;
using GSports.ExternalAPI.Context.Channel;
using GSports.Model.Responses.Finance;
using GSports.Contracts;
using GSports.Model.Requests.Finance;
using GSports.ExternalAPI.Channels;
using GSports.ExternalAPI.Model.Response.BetService;
using GSports.Clients.EventsManager.Model.Entities;
using GSports.ExternalAPI.Model.Response.EventService;
using GSports.ExternalAPI.Model.Request.EventService;
using GSports.ExternalAPI.Model.Response.Base;
using GSports.ExternalAPI.Model.Helpers;

namespace GSports.ExternalAPI.Controllers.Shared
{
    [Route("shared/[controller]/[action]")]
    public class EventController : Controller
    {
        /// <summary>
        /// Retrives all available events
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public GetEventsResponse GetEvents(GetEventsRequest reqeust)
        {
            
            GetEventsResponse retVal = new GetEventsResponse();
            if (reqeust.IsValidRequest(retVal))
            {
                if (EventSingleton.Instance != null)
                {
                    DateTime? LastUpdate = null;
                    if (reqeust.LastTimestamp.HasValue)
                        LastUpdate = DateTimeHelper.FromUnixTime(reqeust.LastTimestamp.Value);
                    retVal.LastTimestamp = DateTimeHelper.ToUnixTime(EventSingleton.Instance.LastUpdate);
                    //retVal.ActiveCoupinIds = EventSingleton.Instance.ac
                    var res = EventSingleton.Instance.GetEvents(LastUpdate,
                                                                reqeust.ActiveCoupon,
                                                                reqeust.CoupinIds,
                                                                reqeust.EventIds,
                                                                reqeust.Skip,
                                                                reqeust.Take);
                    if (res != null)
                    {
                        retVal.ActiveCoupinIds = EventSingleton.Instance.ActiveCouponIds.ToList();
                        retVal.Events = res.ToList();
                        retVal.TotalEventCount = EventSingleton.Instance.EvnetCount;
                    }
                    else

                        retVal.SetErrorResult(eErrorCode.CacheNotReady, "Event cache is not ready!!!");
                }
                else retVal.SetErrorResult(eErrorCode.CacheNotReady, "Event cache is not ready!!!");
            }
            return retVal;
        }
    }
}
