﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Requests;
using GSports.ExternalAPI.Model.Response;

namespace GSports.ExternalAPI.Model.Request.FinanceService
{
    public class CancelWithdrawRequest : BaseRequest
    {
        public long TransferId { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            throw new NotImplementedException();
        }
        public override bool IsValidRequest(BaseResponse response)
        {
            bool retVal = true;
            if (this.TransferId <= 0)
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The TransferId field is required."));
                retVal = false;
            }
          
            return retVal;
        }
    }
}
