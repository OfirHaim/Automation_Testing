﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Requests;
using static GSports.Common.CodeAttribute;
using GSports.ExternalAPI.Model.Response;

namespace GSports.ExternalAPI.Model.Request.FinanceService
{
    public class WithdrawRequest : BaseRequest
    {
        public string Code { get; set; }
        public string Comments { get; set; }
        public double Amount { get; set; }
        public int UserId { get; set; }
        public string ExternalID { get; set; }
        public string Password { get; set; }
        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return new GSports.Model.Requests.Finance.CommitWithdrawRequest()
            {
                TransferCode = this.Code,
                ResponseComments = Comments,
                UserToken = UserToken,
                Password = Password,
                ResponseTypeCodeAttr = TransferResponseType.Approved
            };
        }

        public override bool IsValidRequest(BaseResponse response)
        {
            bool retVal = true;
          
            if (this.Amount <= 0)
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest, string.Format("The amount field is required."));
                retVal =  false;
            }
            else if (this.UserId <= 0)
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest, string.Format("The userId field is required."));
                retVal = false;
            }
            else if (string.IsNullOrEmpty(this.Password))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest, string.Format("The password field is required."));
                retVal = false;
            }
            else if (string.IsNullOrEmpty(this.Code))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest, string.Format("The code field is required."));
                retVal = false;
            }
            retVal = retVal && base.IsValidRequest(response); 
            return retVal;
        }
    }
}
