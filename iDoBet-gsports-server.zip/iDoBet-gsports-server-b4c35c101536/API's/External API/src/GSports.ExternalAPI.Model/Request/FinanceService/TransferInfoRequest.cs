﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Model.Requests;
using GSports.ExternalAPI.Model.Response;

namespace GSports.ExternalAPI.Model.Request.FinanceService
{
    public class TransferInfoRequest : BaseRequest
    {
        public string Type { get; set; }
        public string CustomerCode { get; set; }
     
        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return new GSports.Model.Requests.Finance.GetTransfersRequest()
            {
                 UserToken = UserToken,
                Filter = new GSports.Model.Filter.TransferFilter()
                {
                    TransferCode = CustomerCode,                     
                }
            };
        }

        public override bool IsValidRequest(BaseResponse response)
        {
            bool retVal = true;
            if (string.IsNullOrEmpty(this.Type))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The type field is required."));
                retVal = false;
            }
            if (string.IsNullOrEmpty(this.CustomerCode))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The customerCode field is required."));
                retVal = false;
            }
            retVal = retVal && base.IsValidRequest(response);
            return retVal;
        }
    }
}
