﻿using GSports.ExternalAPI.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Requests;
using GSports.Model.Requests.Finance;
using GSports.ExternalAPI.Model.Response;

namespace GSports.ExternalAPI.Model.Request.FinanceService
{
    public class DepositRequest : BaseRequest
    {
        public double Amount { get; set; }
        public int ToUserId { get; set; }
        public string Password { get; set; }
        public string Comments { get; set; }
        public string ExternalID { get; set; }    

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return new InsertDepositRequest()
            {
                UserToken = UserToken,
                Amount = Amount,
                Comments = ((!string.IsNullOrEmpty(ExternalID)  || !string.IsNullOrEmpty(Comments))?string.Format("ExternalId = {0}, Comment = {1}", ExternalID??"", Comments??""):null),
                ToUserId = ToUserId,
                Password = Password,                
                PaymentMethod = GSports.Model.Consts.ePaymentMethod.Shop
            };
        }
        public override bool IsValidRequest(BaseResponse response)
        {
            bool retVal = true;
            if (this.Amount <= 0)
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The amount field is required."));
                retVal = false;
            }
            if (this.ToUserId <= 0)
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The toUserId field is required."));
                retVal = false;
            }
            if (string.IsNullOrEmpty(this.Password))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The password field is required."));
                retVal = false;
            }
            retVal = retVal && base.IsValidRequest(response);
            return retVal;
        }

    }
}
