﻿using GSports.ExternalAPI.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Requests;

namespace GSports.ExternalAPI.Model.Request.FinanceService
{
    public class GetTransactionRequest: BaseRequest
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public TransactionType TransactionType { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            throw new NotImplementedException();
        }
    }
}
