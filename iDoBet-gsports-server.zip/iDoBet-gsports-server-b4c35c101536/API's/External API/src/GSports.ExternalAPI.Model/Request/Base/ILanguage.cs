﻿
namespace GSports.ExternalAPI.Model.Request
{
    public interface ILanguage
    {
        string Language { get; set; }
    }
}
