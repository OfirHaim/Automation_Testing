﻿
using GSports.ExternalAPI.Model.Helpers;
using GSports.ExternalAPI.Model.Response;
using System;

namespace GSports.ExternalAPI.Model.Request
{
    public abstract class BaseRequest
    {
        public string UserToken { get; set; }

        public abstract GSports.Model.Requests.BaseRequest ConvertToServerRequest();

        public virtual bool IsValidRequest(BaseResponse response)
        {
            bool retVal = true;
            if (string.IsNullOrEmpty(UserToken))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The userToken field is required."));
                retVal = false;
            }
            return retVal;
        }
    }
}
