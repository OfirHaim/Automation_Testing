﻿
namespace GSports.ExternalAPI.Model.Request
{


    public interface IAuthenticatedRequest
    {

        string Token { get; set; }

    }

}
