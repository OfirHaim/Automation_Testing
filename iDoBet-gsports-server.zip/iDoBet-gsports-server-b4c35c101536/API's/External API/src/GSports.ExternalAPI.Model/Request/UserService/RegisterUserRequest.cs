﻿using GSports.ExternalAPI.Model.Entities;
using GSports.ExternalAPI.Model.Enums;
using GSports.ExternalAPI.Model.Interfaces.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Requests;

namespace GSports.ExternalAPI.Model.Request.UserService
{
    public class RegisterUserRequest : BaseRequest, IUserInfo, IUserContactData
    {
        #region Props

        #region UserInfo

        public DateTime Birthday { get; set; }

        public Country Country { get; set; }

        public string Email { get; set; }

        public string FirstName { get; set; }

        public eGender Gender { get; set; }

        public string LastName { get; set; }

        public string Password { get; set; }

        public string UserName { get; set; }

        #endregion

        #region UserContactData

        public string Address { get; set; }

        public string Phone { get; set; }

        public bool AcceptNewsletter { get; set; }

        #endregion

        public string PromotionCode { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
