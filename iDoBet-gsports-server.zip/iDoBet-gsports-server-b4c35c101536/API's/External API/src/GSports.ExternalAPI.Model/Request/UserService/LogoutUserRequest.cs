﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.ExternalAPI.Model.Response;
using GSports.Model.Requests;

namespace GSports.ExternalAPI.Model.Request.UserService
{
    public class LogoutUserRequest : BaseRequest
    {
        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return new GSports.Model.Requests.Authentication.LogoutRequest() { UserToken = this.UserToken, logoutType = GSports.Model.Security.eLogoutType.Logout };
        }
      
    }
}
