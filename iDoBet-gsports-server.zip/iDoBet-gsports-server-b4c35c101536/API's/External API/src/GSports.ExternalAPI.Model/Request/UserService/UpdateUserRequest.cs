﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Requests;

namespace GSports.ExternalAPI.Model.Request.UserService
{
    public class UpdateUserRequest : BaseRequest
    {
        public bool AcceptNewsLetter { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            throw new NotImplementedException();
        }
    }
}
