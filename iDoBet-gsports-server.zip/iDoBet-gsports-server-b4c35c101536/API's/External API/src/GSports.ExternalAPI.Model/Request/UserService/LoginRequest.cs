﻿
using System;
using GSports.ExternalAPI.Model.Helpers;
using GSports.Model.Requests;
using GSports.ExternalAPI.Model.Response;

namespace GSports.ExternalAPI.Model.Request.UserService
{
    public class LoginRequest : BaseRequest
    {
        [TsRequired]
        public string Username { get; set; }
        [TsRequired]
        public string Password { get; set; }

        public string IP { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return new GSports.Model.Requests.Authentication.LoginRequest()
            {
                IP = IP,
                UserName = Username,
                Password = Password,
                UserToken = UserToken
            };
        }
        public override bool IsValidRequest(BaseResponse response)
        {
            bool retVal = true;
            if (string.IsNullOrEmpty(this.Username))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The Username field is required."));
                retVal = false;
            }
            if (string.IsNullOrEmpty(this.Password))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The Password field is required."));
                retVal = false;
            }

            return retVal;
        }
    }
}
