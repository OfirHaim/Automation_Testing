﻿using GSports.ExternalAPI.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Requests;
using GSports.ExternalAPI.Model.Enums;

namespace GSports.ExternalAPI.Model.Request.BetService
{
    public class GetOrdersRequest: BaseRequest
    {
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string OrderNumber { get; set; }
        public List<eWinStatus> WinStatusIds { get; set; }
        public eOrderStatus OrderStatus { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return new GSports.Model.Requests.Order.GetBetOrderRequest()
            {
                UserToken = UserToken,
                Filter = new GSports.Model.Filter.OrderFilter()
                {
                    FromDate = FromDate,
                    ToDate = ToDate,
                    OrderNumber = OrderNumber,
                    WinStatusIds = WinStatusIds?.ConvertAll(x => (int)x),
                    OrderStatus = (GSports.Model.Consts.eOrderStatus)OrderStatus
                }
            };
        }
    }
}
