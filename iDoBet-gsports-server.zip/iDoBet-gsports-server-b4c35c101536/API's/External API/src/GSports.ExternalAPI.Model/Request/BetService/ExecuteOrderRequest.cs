﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.ExternalAPI.Model.Response;
using GSports.Model.Requests;

namespace GSports.ExternalAPI.Model.Request.BetService
{
    public class ExecuteOrderRequest : BaseRequest
    {
        public string TimeoutGuid { get; set; }
        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return new GSports.Model.Requests.Order.ExecuteOrderRequest()
            {
                TimeoutGuid = TimeoutGuid  ,
                UserToken = UserToken
            };
        }
        public override bool IsValidRequest(BaseResponse response)
        {
            bool retVal = true;
            if (string.IsNullOrEmpty(this.TimeoutGuid))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The timeoutGuid field is required."));
                retVal = false;
            }
            retVal = retVal && base.IsValidRequest(response);
            return retVal;
        }
    }
}
