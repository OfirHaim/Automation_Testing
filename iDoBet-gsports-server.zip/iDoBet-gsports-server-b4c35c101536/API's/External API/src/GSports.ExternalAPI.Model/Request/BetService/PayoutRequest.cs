﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Model.Requests;
using GSports.Model.Requests.Order;
using GSports.ExternalAPI.Model.Response;

namespace GSports.ExternalAPI.Model.Request.BetService
{
    public class PayoutRequest : BaseRequest
    {
        public string Barcode { get; set; }
        public string TerminalSecurityCode { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return new DoPayoutRequest() {Barcode = Barcode, TerminalSecurityCode = TerminalSecurityCode, UserToken = UserToken };
        }

        public override bool IsValidRequest(BaseResponse response)
        {
            bool retVal = true;
            if (string.IsNullOrEmpty(this.Barcode))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The barcode field is required."));
                retVal = false;
            }
            if (string.IsNullOrEmpty(this.TerminalSecurityCode))
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The terminalSecurityCode field is required."));
                retVal = false;
            }

            retVal = retVal && base.IsValidRequest(response);
            return retVal;
        }
    }
}
