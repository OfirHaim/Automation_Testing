﻿using GSports.ExternalAPI.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Requests;

namespace GSports.ExternalAPI.Model.Request.BetService
{
    public class GetBetHistoryRequest: BaseRequest
    {
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string OrderNumber { get; set; }
        public List<eWinStatus> WinStatusIds { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            throw new NotImplementedException();
        }
    }
}
