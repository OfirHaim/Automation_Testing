﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Model.Requests;

namespace GSports.ExternalAPI.Model.Request.BetService
{
    public class RequestForOrderRequest  : PlaceBetsRequest
    {
        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return base.ConvertToServerRequest(); 
        }
    }
}
