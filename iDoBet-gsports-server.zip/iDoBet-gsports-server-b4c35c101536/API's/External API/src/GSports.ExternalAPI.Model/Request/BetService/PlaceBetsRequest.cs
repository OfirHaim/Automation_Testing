﻿using GSports.ExternalAPI.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Requests;
using GSports.ExternalAPI.Model.Helpers.ModelConvertors;
using GSports.ExternalAPI.Model.Response;

namespace GSports.ExternalAPI.Model.Request.BetService
{
    public class PlaceBetsRequest : BaseRequest
    {
        public List<Selection> Selections { get; set; }

        public List<RequestOrderRow> Rows { get; set; }

        public string ExternalID { get; set; }

        public string TerminalSecurityCode { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            return new GSports.Model.Requests.Order.OrderRequest()
            {
                ExternalID = ExternalID,
                UserToken = UserToken,
                TerminalSecurityCode = TerminalSecurityCode,
                Selections = BetConveror.ToServerSelections(Selections),
                Rows = BetConveror.ToServerRows(Rows),
            };
        }

        public override bool IsValidRequest(BaseResponse response)
        {
            bool retVal = true;
            if (this.Selections==null || this.Selections.Count == 0  )
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The selections field is required."));
                retVal = false;
            }
            if (this.Rows == null || this.Rows.Count == 0)
            {
                response.SetErrorResult(Response.Base.eErrorCode.BadRequest,
                                        string.Format("The rows field is required."));
                retVal = false;
            }
            retVal = retVal && base.IsValidRequest(response);
            return retVal;
        }
    }
}
