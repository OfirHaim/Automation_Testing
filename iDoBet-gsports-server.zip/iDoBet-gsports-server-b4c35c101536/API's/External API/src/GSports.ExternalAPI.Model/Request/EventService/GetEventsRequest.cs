﻿using System;
using System.Collections.Generic;
using GSports.Model.Requests;

namespace GSports.ExternalAPI.Model.Request.EventService
{

    
    
    public class GetEventsRequest : BaseRequest
    {
        #region props

        // public int? Top  { get; set; }
        public bool? ActiveCoupon { get; set; }
        public List<int> CoupinIds { get; set; }
        public List<long> EventIds { get; set; }
        public long? LastTimestamp { get; set; }
        public int? Skip { get; set; }
        public int? Take { get; set; }

        public override GSports.Model.Requests.BaseRequest ConvertToServerRequest()
        {
            throw new NotImplementedException();
        }

        #endregion
    }

    
    

}
