﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Model.ConfigModel
{
    public class ClientConfig
    {
        public GSBConnection GsbConnection { get; set; }
        public List<ClientSettings> Settings { get; set; }
        public EventManager EventManager { get; set; }
    }

    public class ClientSettings
    {
        public string Name { get; set; }
        public List<long> SportTypeIds { get; set; }
        public List<string> BetTypeIds { get; set; } //ck
        public bool Prematch { get; set; }
        public bool Live { get; set; }
        public bool TopEventsOnly { get; set; }
        public bool OnlyActiveCoupon { get; set; }
    }

    public class GSBConnection
    {
        public string DepositUrl { get; set; }
        public string WithdrawUrl { get; set; }
        public string TransferInfoUrl { get; set; }
        public string SecurityToken { get; set; }
    }
    public class EventManager
    {
        public string PushServerURL { get; set; }
        public bool OnlyActiveCoupon { get; set; }
        public bool IsCacheMaster { get; set; }
        public string ChannelName { get; set; }
        public int CheckForChangesEveryMilliseconds { get; set; }
        public int UpdateMessagesLifeTimeMinutes { get; set; }
        public string ProviderIds { get; set; }
        public string SportIds { get; set; }
        public string BetTypeIds { get; set; }

    }
}
