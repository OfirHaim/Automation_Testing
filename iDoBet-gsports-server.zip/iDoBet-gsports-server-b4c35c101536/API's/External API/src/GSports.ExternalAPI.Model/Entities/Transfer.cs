﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Model.Entities
{
    public class Transfer: BaseEntity
    {              
        public DateTime RequestTime { get; set; }
        public DateTime? ResponseTime { get; set; }
        public BaseEntity FromUser { get; set; }
        public BaseEntity ToUser { get; set; }
        public string RequestComments { get; set; }
        public double RequestAmount { get; set; }
        public string CustomerCode { get; set; }
        public string ExternalId { get; set; }
        public string Status { get; set; }
        public string Type { get; set; }
        
    }
}
