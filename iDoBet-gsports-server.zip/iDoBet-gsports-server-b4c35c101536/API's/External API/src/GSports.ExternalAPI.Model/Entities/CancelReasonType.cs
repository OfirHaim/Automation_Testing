﻿
namespace GSports.ExternalAPI.Model.Entities
{
    public class CancelReasonType
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Desc { get; set; }
    }
}
