﻿using GSports.Clients.EventsManager.Model.Entities;
using GSports.ExternalAPI.Model.Enums;
using GSports.ExternalAPI.Model.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace GSports.ExternalAPI.Model.Entities
{

    
    
    public class OrderInfo : BaseEntity
    {                     
        public string OrderNumber { get; set; }
        
        public string ExternalId { get; set; }
        
        public string TransactionId { get; set; }
        
        public string Barcode { get; set; }
        public double Payout { get; set; }
        
        public double MaxPayout { get; set; }
        
        public string RequestGuid { get; set; }

        public DateTime CreationTime { get; set; }
        
        public double Amount { get; set; }
        
        public int  CurrencyId { get; set; }
        
        public string CurrencyName { get; set; }
        
        public eOrderProd OrderProd { get; set; }

        public DateTime? SettledTime { get; set; }

        public DateTime? SoldTime { get; set; }

        public DateTime ExpiryDate { get; set; }        
        
        public int UserId { get; set; }
        
        public string UserName { get; set; }

        public eOrderStatus Status { get; set; }    

        public eWinStatus WinStatus { get; set; }

        public string UrlKey { get; set; }

        public DateTime? CancelTimePossibile { get; set; }

        public bool IsPayoutPossibile { get; set; }

    }

    public class Order : OrderInfo
    {       
        public List<OrderRow> OrderRows { get; set; } //singels    
    }

    public class OrderRow 
    {        
        public long Id { get; set; }
        
        public double Amount { get; set; }
        
        public List<OrderBet> Bets { get; set; }
        
        public long OrderId { get; set; }    
        
        public eWinStatus WinStatus { get; set; }
    }

    
    
    public class OrderBet
    {        
        public long Id { get; set; }
        
        public long OrderRowId { get; set; }
        
        public long OrderId { get; set; }
        
        public Event Event { get; set; }
    }

    
    
    public enum eWinStatus
    {        
        Pending = 0,
        
        Loser = 1,
        
        Winner = 2,
        
        MoneyBack = 3,
        
        HalfWin = 4,
        
        HalfLose = 5,
        
        Unknown = -1,
    }

    
    
    public enum eOrderProd
    {
        
        Unknown = 0,

        
        Prematch = 1,

        
        Live = 2
    }

}
