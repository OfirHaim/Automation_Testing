﻿
namespace GSports.ExternalAPI.Model.Entities
{

    
    
    public class Branch: BaseEntity
    {      
       // public int Id { get; set; }
    
        public string Name { get; set; }

    }

}
