﻿
using GSports.ExternalAPI.Model.Entities;
using GSports.ExternalAPI.Model.Enums;
using System;

namespace GSports.ExternalAPI.Model.Interfaces.User
{    
    public interface IUserInfo
    {
        string FirstName { get; set; }

        string LastName { get; set; }

        string UserName { get; set; }        

        string Email { get; set; }

        Country Country { get; set; }

        eGender Gender { get; set; }

        DateTime Birthday { get; set; }

    }
}
