﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Model.Interfaces.User
{
    interface IUserContactData
    {
        string Address { get; set; }
        
        string Phone { get; set; }

        bool AcceptNewsletter { get; set; }
    }
}
