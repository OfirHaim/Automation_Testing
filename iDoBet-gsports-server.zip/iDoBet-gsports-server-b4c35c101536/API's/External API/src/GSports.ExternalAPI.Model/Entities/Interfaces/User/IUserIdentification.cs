﻿
namespace GSports.ExternalAPI.Model.Interfaces.User
{
    public interface IUserIdentification
    {
        int UserId { get; set; }

        bool IsActivated { get; set; }

        string Token { get; set; }
    }
}
