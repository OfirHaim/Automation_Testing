﻿
namespace GSports.ExternalAPI.Model.Interfaces.User
{
    public interface IUserAccountData
    {
        double? Balance { get; set; }

        double? Holding { get; set; }

        long? AccountId { get; set; }
    }
}
