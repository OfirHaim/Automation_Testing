﻿using System;
using GSports.ExternalAPI.Model.Enums;
using GSports.ExternalAPI.Model.Interfaces.User;

namespace GSports.ExternalAPI.Model.Entities
{
    public class UserEnitity : IUserInfo, IUserIdentification, IUserAccountData, IUserContactData
    {
        #region UserIdentification

        public int UserId { get; set; }

        public bool IsActivated { get; set; }

        public string Token { get; set; }

        #endregion

        #region UserInfo

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string UserName { get; set; }

        public string Email { get; set; }

        public Country Country { get; set; }

        public eGender Gender { get; set; }
        
        public DateTime Birthday { get; set; }

        #endregion

        #region Account Data

        public double? Balance { get; set; }

        public double? Holding { get; set; }

        public long? AccountId { get; set; }

        #endregion

        #region ContactData

        public string Address { get; set; }

        public string Phone { get; set; }

        public bool AcceptNewsletter { get; set; }

        #endregion
    }

}
