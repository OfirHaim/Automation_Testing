﻿
namespace GSports.ExternalAPI.Model.Enums
{
    public enum eGender
    {        
        Male = 0,
        Female = 1        
    }
}
