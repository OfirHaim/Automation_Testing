﻿namespace GSports.ExternalAPI.Model.Enums
{
    public enum eOrderStatus
    {   
        Unknown = 0,        
        Draft = 1,     
        Sold = 3,   
        Paid = 4,       
        Blocked = 5,       
        Cancelled = 6,
        Expired = 7
    }
}
