﻿using GSports.ExternalAPI.Model.Entities;
using System.Collections.Generic;
using System;
using GSports.Clients.EventsManager.Model.Entities;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.EventService
{
    public class GetSportTypesResponse : BaseResponse
    {
        public List<SportType> SportTypes { get; set; }
        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            throw new NotImplementedException();
        }

        public override bool IsResponseDataValid()
        {
            return SportTypes != null;
        }
    }
}
