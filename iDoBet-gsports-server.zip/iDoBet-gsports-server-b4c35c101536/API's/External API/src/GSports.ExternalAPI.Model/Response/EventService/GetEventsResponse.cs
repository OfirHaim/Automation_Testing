﻿using GSports.Clients.EventsManager.Model.Entities;
using GSports.ExternalAPI.Model.Entities;
using GSports.ExternalAPI.Model.Request;
using System;
using System.Collections.Generic;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.EventService
{
    public class GetEventsResponse : BaseResponse
    {
        public List<Event> Events { get; set; }
        public int EventCount
        {
            get { return (this.Events == null) ? 0 : this.Events.Count; }
        }
        public int TotalEventCount { get; set; }

        public long LastTimestamp { get; set; }
        public List<int> ActiveCoupinIds { get; set; }
        public override bool IsResponseDataValid()
        {
            return Events != null;
        }

        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            throw new NotImplementedException();
        }
    }
}
