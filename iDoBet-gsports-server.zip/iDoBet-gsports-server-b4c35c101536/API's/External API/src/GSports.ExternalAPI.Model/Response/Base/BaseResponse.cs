﻿using GSports.ExternalAPI.Model.Response.Base;
using System.Runtime.Serialization;

namespace GSports.ExternalAPI.Model.Response
{
    public abstract class BaseResponse
    {
        public BaseResponse() { }
     

        private Result mResult;

        public Result Result
        {     
            get { return mResult; }
            set { mResult = value; }
        }

        public abstract bool IsResponseDataValid();      
        public void SetErrorResult(eErrorCode errorCode, string errorDescription, object additionalInfo = null)
        {
            if (mResult == null) mResult = new Result();
            mResult.ErrorCode = errorCode;
            mResult.ErrorDescription = errorDescription;
            mResult.ResultCode = eResultCode.Failure;
            mResult.AdditionalInfo = additionalInfo;
        }

        public bool IsSuccessfull
        {
            get
            {
                if (!IsResponseDataValid())
                {
                    if (Result == null)   
                        Result = new Result();
                    Result.ErrorCode = eErrorCode.EmptyResultData;
                    Result.ErrorCodeDescription = eErrorCode.EmptyResultData.ToString();
                    return false;
                }
                return Result == null || Result.ResultCode == eResultCode.Success;
            }
        }

        public object UserInfo { get; set; }

        public BaseResponse ConvertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            Result = response.Result;
            return convertResponseFromServer(response);
        }
        protected abstract BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response);

    }
}
