﻿
namespace GSports.ExternalAPI.Model.Response.Base
{
    public class Result
    {
        public static implicit operator Result(GSports.Model.Responses.Result serverRes)
        {
            return new Result()
            {
                AdditionalInfo = serverRes.AdditionalInfo,
                ErrorCode = (eErrorCode)serverRes.ErrorCode,
                ErrorCodeDescription = serverRes.ErrorDescription,
                ErrorDescription = serverRes.ErrorDescription,
                ResultCode = (eResultCode)serverRes.ResultCode
            };
        }

        public string ErrorDescription { get; set; }
        public object AdditionalInfo { get; set; }
        public eErrorCode ErrorCode { get; set; }
        public eResultCode ResultCode { get; set; }
        public string ErrorCodeDescription { get; set; }
    }

}
