﻿
namespace GSports.ExternalAPI.Model.Response.Base
{

    
    
    public enum eResultCode
    {
        
        Success = 0,
        
        Failure = 1,
    }

}
