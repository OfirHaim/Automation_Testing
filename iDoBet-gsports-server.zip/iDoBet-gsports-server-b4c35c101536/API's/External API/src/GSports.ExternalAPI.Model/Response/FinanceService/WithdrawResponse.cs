﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Responses;
using GSports.Model.Responses.Finance;

namespace GSports.ExternalAPI.Model.Response.FinanceService
{
    public class WithdrawResponse : BaseResponse
    {
        public double Amount { get; set; }

        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            var serverResponse = response as CommitWithdrawResponse;
            if (serverResponse.IsSuccessfull() && serverResponse.WithdrawData != null)
                Amount = serverResponse.WithdrawData.RequestAmount;
            return this;
        }

        public override bool IsResponseDataValid()
        {
            return Amount > 0;
        }
    }
}
