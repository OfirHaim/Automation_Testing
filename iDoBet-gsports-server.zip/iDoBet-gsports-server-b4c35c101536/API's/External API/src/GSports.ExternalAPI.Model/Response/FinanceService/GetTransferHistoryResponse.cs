﻿using GSports.ExternalAPI.Model.Helpers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.FinanceService
{
    public class GetTransferHistoryResponse: BaseResponse
    { 
        public List<TransferHistory> Transfers {get;set;}
        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            throw new NotImplementedException();
        }

        public override bool IsResponseDataValid()
        {
            return Transfers != null;
        }
    }

    public class TransferHistory
    {
        public DateTime Date { get; set; }
        public string TransactionType { get; set; }
        public double Amount { get; set; }
        public string Comments { get; set; }
        public long Id { get; set; }
    }
}
