﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.FinanceService
{
    public class CancelWithdrawResponse : BaseResponse
    {
        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            throw new NotImplementedException();
        }

        public override bool IsResponseDataValid()
        {
            return true;
        }
    }
}
