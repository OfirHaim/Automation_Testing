﻿using GSports.ExternalAPI.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.FinanceService
{
   public class DepositResponse : BaseResponse
    {
        public string Code { get; set; }
        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            
            var serverResponse = response as GSports.Model.Responses.Finance.InsertDepositResponse;
            if(serverResponse.IsSuccessfull() && serverResponse.DepositData !=null)
                 Code = serverResponse.DepositData.Code;

            return this;
        }

        public override bool IsResponseDataValid()
        {
            return !string.IsNullOrEmpty(Code);
        }
    }
}
