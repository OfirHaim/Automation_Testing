﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Model.Responses;
using GSports.ExternalAPI.Model.Entities;

namespace GSports.ExternalAPI.Model.Response.FinanceService
{
    public class TransferInfoResponse : BaseResponse
    {        
       public List<Transfer> Transfers { get; set; }
        public override bool IsResponseDataValid()
        {
            return Transfers != null;
        }

        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            var serverResponse = response as GSports.Model.Responses.Finance.GetTransfersResponse;
            if (serverResponse.IsSuccessfull() &&
                serverResponse.Transfers != null &&
                serverResponse.Transfers.Count > 0)
            {
                Transfers = new List<Transfer>();
                foreach (var transfer in serverResponse.Transfers)
                {
                    Transfers.Add(new Transfer()
                    {
                        Id = transfer.Id.ToString(),
                        CustomerCode = transfer.Code,
                        //ExternalId = transfer.RequestComments
                        FromUser = new BaseEntity()
                        {
                            Id = transfer.FromAccount.UserId.ToString()
                        },
                        RequestAmount = transfer.RequestAmount,
                        RequestComments = transfer.RequestComments,
                        RequestTime = transfer.RequestTime,
                        ResponseTime = transfer.ResponseTime,
                        Status = transfer.ResponseType.CodeAttribute,
                        Type = transfer.RequestType.CodeAttribute,
                        ToUser = new BaseEntity()
                        {
                            Id = transfer.ToAccount.UserId.ToString()
                        }
                    }
                    );
                }
            }
            return this;
            
          
        }
    }
}
