﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.UserService
{
    public class LogoutUserResponse : BaseResponse
    {
        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            var serverRes = response as GSports.Model.Responses.Authentication.LogoutResponse;
            return this;
        }

        public override bool IsResponseDataValid()
        {
            return true;
        }
    }
}
