﻿using GSports.ExternalAPI.Model.Entities;
using System.Runtime.Serialization;
using System;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.UserService
{   
    public class LoginResponse : BaseResponse
    {
        public string Token { get; set; }

        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            var serverRes = response as GSports.Model.Responses.Authentication.LogInResponse;
            Token = serverRes.Token;
            return this;
        }

        public override bool IsResponseDataValid()
        {
            return !string.IsNullOrEmpty(Token);
        }
    }
}
