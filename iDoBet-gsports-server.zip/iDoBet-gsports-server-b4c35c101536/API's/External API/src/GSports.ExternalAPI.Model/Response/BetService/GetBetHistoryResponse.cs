﻿using GSports.ExternalAPI.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.BetService
{
   public class GetBetHistoryResponse : BaseResponse
    {
        public List<Order> Orders { get; set; }

        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            return this;
        }

        public override bool IsResponseDataValid()
        {
            return Orders != null;
        }
    }
}
