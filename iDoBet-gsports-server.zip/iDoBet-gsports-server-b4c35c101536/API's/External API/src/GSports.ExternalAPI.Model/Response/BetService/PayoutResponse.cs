﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Model.Responses;
using GSports.Model.Responses.Order;

namespace GSports.ExternalAPI.Model.Response.BetService
{
    public class PayoutResponse : BaseResponse
    {
        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            var serverRes = response as DoPayoutResponse;
            return this;
        }

        public override bool IsResponseDataValid()
        {
            return true;
        }
    }
}
