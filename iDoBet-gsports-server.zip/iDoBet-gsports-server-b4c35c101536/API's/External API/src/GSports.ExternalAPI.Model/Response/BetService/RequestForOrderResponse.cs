﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.BetService
{
    public class RequestForOrderResponse: BaseResponse
    {   
        public string TimeoutGuid { get; set; }

        public int Timeout { get; set; }

        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            var serverRes = response as GSports.Model.Responses.Order.OrderResponse;
            if (serverRes.IsSuccessfull())
            {
                Timeout = serverRes.Timeout;
                TimeoutGuid = serverRes.TimeoutGuid;
            }
            else
                this.SetErrorResult(Base.eErrorCode.InternalServerError, "Request for order failed", serverRes.ValidationResult);
            return this;
        }

        public override bool IsResponseDataValid()
        {
            return !string.IsNullOrEmpty(TimeoutGuid);
        }
    }
}
