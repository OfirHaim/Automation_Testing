﻿using GSports.ExternalAPI.Model.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Responses;
using GSports.ExternalAPI.Model.Helpers.ModelConvertors;

namespace GSports.ExternalAPI.Model.Response.BetService
{
   public class GetOrdersResponse : BaseResponse
    {
        public List<Order> Orders { get; set; }
        public int TotalCountOrder { get; set; }

        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            var serverRes = response as GSports.Model.Responses.Order.GetBetOrderResponse;
            TotalCountOrder = serverRes.TotalCountOrder;
            Orders = OrderConvertor.ToClientOrders(serverRes.Orders);
            return this;
        }

        public override bool IsResponseDataValid()
        {
            return Orders != null;
        }
    }
}
