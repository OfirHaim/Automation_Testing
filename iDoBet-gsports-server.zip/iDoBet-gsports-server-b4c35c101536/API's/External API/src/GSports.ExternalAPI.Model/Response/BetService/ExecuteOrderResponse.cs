﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GSports.Model.Responses;

namespace GSports.ExternalAPI.Model.Response.BetService
{
    public class ExecuteOrderResponse : PlaceBetsResponse
    {
      
    }
}
