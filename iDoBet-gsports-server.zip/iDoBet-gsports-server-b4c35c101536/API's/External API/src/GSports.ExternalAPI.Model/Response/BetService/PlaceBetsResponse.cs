﻿using GSports.ExternalAPI.Model.Response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GSports.Model.Responses;
using GSports.ExternalAPI.Model.Entities;
using GSports.ExternalAPI.Model.Helpers.ModelConvertors;
using GSports.Model.BetValidation;

namespace GSports.ExternalAPI.Model.Response.BetService
{
    public class PlaceBetsResponse : BaseResponse
    {        
        public Order Order { get; set; }

        public List<OrderValidationResult> ValidationResult { get; set; }

        public override bool IsResponseDataValid()
        {
            return Order != null;
        }

        protected override BaseResponse convertResponseFromServer(GSports.Model.Responses.BaseResponse response)
        {
            var serverRes = response as GSports.Model.Responses.Order.ExecuteOrderResponse;             
            Order = OrderConvertor.ToClientOrders(new List<GSports.Model.Entities.OrderEntity>() { serverRes.NewOrder }).FirstOrDefault();
            ValidationResult = serverRes.ValidationResult;            
            return this;
        }
    }
}
