﻿namespace GSports.ExternalAPI.Model.Consts
{
    public class PropertyNames
    {       
        public const string COMPARE_KEY = "ck";
        public const string NAME = "name";
        public const string SHORT_NAME = "shortname";
        public const string STATUS = "status";
        public const string ORDER = "order";
        public const string DATA = "data";
    }
}
