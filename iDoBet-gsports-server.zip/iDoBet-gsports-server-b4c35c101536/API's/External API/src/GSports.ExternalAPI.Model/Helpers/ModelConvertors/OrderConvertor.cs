﻿using GSports.Common.RecieptHelper;
using GSports.ExternalAPI.Model.Entities;
using GSports.ExternalAPI.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Model.Helpers.ModelConvertors
{
    public class OrderConvertor
    {
        public static List<Order> ToClientOrders(List<GSports.Model.Entities.OrderEntity> orders)
        {
            List<Order> retVal = null;
            try
            {
                retVal = new List<Order>();
                orders.ForEach(x => retVal.Add(new Order()
                {
                    Id = x.Id.ToString(),
                    Amount = x.Amount,
                    Barcode = x.Barcode,
                    CreationTime = x.CreateTime,
                    CurrencyId = x.OrderCurrency.Id,
                    CurrencyName = x.OrderCurrency.Name,
                    ExpiryDate = x.ExpiryDate,
                    ExternalId = x.ExternalId,
                    MaxPayout = x.MaxPayout,
                    OrderNumber = x.OrderNumber,
                    OrderProd = (eOrderProd)x.OrderProd,
                    OrderRows = ToClientOrderRows(x.OrderRows),
                    RequestGuid = x.RequestGuid,
                    SettledTime = x.SettledTime,
                    SoldTime = x.SoldTime,
                    Status = (eOrderStatus)x.Status,
                    TransactionId = x.TransactionId,
                    UserId = (int)x.Id,
                    UserName = x.Name,
                    WinStatus = (eWinStatus)x.WinStatus,
                    Payout = x.ActualPayout,
                    CancelTimePossibile = x.CancelTimePossibile,
                    IsPayoutPossibile = x.IsPayoutPossibile
                }));
            }
            catch { }

            return retVal;
        }


        private static List<OrderRow> ToClientOrderRows(List<GSports.Model.Entities.Order.OrderRowEntity> orderRows)
        {
            var retVal = new List<OrderRow>();

            if (orderRows != null)
            {
                orderRows.ForEach(x => retVal.Add(new OrderRow()
                {
                    Amount = x.Amount,
                    Id = x.Id,
                    OrderId = x.OrderId,
                    WinStatus = (eWinStatus)x.WinStatus,
                    Bets = ToClientOrderBet(x.Bets),
                }));
            }
            return retVal;
        }

        private static List<OrderBet> ToClientOrderBet(List<GSports.Model.Entities.OrderBet> bets)
        {
            var retVal = new List<OrderBet>();
            var listOfSportEvent = new List<GSports.Model.Entities.Event.SportGame>();
            bets.ForEach(x => listOfSportEvent.Add(x.Event));
            var eventList = EventConvertor.ToClientEvents(listOfSportEvent);
            bets.ForEach(x => retVal.Add(new OrderBet()
            {
                Id = x.Id,
                OrderId = x.OrderId,
                OrderRowId = x.OrderRowId,
            }));
            for (int i = 0; i < bets.Count; i++)
            {
                retVal[i].Event = eventList[i];
            }
            return retVal;
        }
    }
}
