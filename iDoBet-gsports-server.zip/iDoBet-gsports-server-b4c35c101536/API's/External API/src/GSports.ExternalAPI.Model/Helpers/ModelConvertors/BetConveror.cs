﻿using GSports.ExternalAPI.Model.Request.BetService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Model.Helpers.ModelConvertors
{
    public class BetConveror
    {
        public static List<GSports.Model.Requests.Order.Selection> ToServerSelections(List<Selection> selections)
        {
            var retVal = new List<GSports.Model.Requests.Order.Selection>();

            selections.ForEach(x => retVal.Add(new GSports.Model.Requests.Order.Selection()
            {
                BetTypeId = x.BetTypeId,
                EventId = x.EventId,
                Key = x.Key,
                OddLine = x.OddLine,
                OddName = x.OddName,
                OddPrice = x.OddPrice
            }));

            return retVal;
        }

        public static List<GSports.Model.Requests.Order.RequestOrderRow> ToServerRows(List<RequestOrderRow> rows)
        {
            var retVal = new List<GSports.Model.Requests.Order.RequestOrderRow>();

            rows.ForEach(x => retVal.Add(new GSports.Model.Requests.Order.RequestOrderRow()
            {
                Amount = x.Amount,
                SelectionKeys = x.SelectionKeys
            }));

            return retVal;
        }
    }
}
