﻿using GSports.Clients.EventsManager.Model.Entities;
using GSports.Clients.EventsManager.Model.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GSports.ExternalAPI.Model.Helpers.ModelConvertors
{
    public class EventConvertor
    {
        public static List<Event> ToClientEvents(List<GSports.Model.Entities.Event.SportGame> sportGames)
        {
            List<Event> retVal = new List<Event>();

            sportGames.ForEach(x =>
            {
                var betTypes = new List<BetType>();
                x.BetTypes.ForEach(bt =>
                {
                    bt.Odds.GroupBy(g => g.Line).ToList().ForEach(gbt =>
                    {
                        var odds = new List<Odd>();
                        gbt.ToList().ForEach(od =>
                        {
                            odds.Add(new Odd()
                            {
                                Name = od.Name,
                                ShortName = od.ShortName,
                                Price = od.CurrentPrice,
                                Status = (eOddStatus)od.status,
                                BettingTypeId = od.BettingTypeId,
                                Shortcut = od.Shortcut,
                                LastUpdate = od.LastUpdate,
                            });
                        });
                        betTypes.Add(new BetType()
                        {
                            BetTypeData = new BetTypeData()
                            {
                                Id = bt.Id,
                                Name = bt.Name,
                                ShortName = bt.ShortName,
                                Status = odds.All(a => a.Status == eOddStatus.Closed) ? eBetStatus.Closed : (eBetStatus)bt.BetStatus,
                                Line = gbt.First().Line,
                                LastUpdate = bt.LastUpdate,
                            },
                            Odds = odds
                        });
                    });
                });
                retVal.Add(new Event()
                {
                    EventData = new EventData()
                    {
                        Id = x.Id,
                        LastUpdate = x.LastUpdate,
                        Country = new EventCountry() { Id = x.Country.Id, Name = x.Country.Name, ShortName = x.Country.ShortName },
                        League = new League() { Id = x.League.Id, Name = x.League.Name, ShortName = x.League.ShortName },
                        HomeTeam = new Team() { Id = x.HomeTeam.Id, Name = x.HomeTeam.Name, ShortName = x.HomeTeam.ShortName },
                        AwayTeam = new Team() { Id = x.AwayTeam.Id, Name = x.AwayTeam.Name, ShortName = x.AwayTeam.ShortName },
                        EventState = (eEventState)x.CurrentState,
                        EventStatus = (eEventStatus)x.EventStatus,
                        GameTime = x.EventDate,
                        GameNumber = x.GameNumber.ToString(),
                        SportType = new SportType() { Id = x.SportType.Id, Name = x.SportType.Name },
                        CouponId  = x.CurrentCouponId,
                        IsBookedForLive = x.IsBooked,
                        Live = x.EventStatus == GSports.Model.Consts.eEventStatus.Live ? new LiveData()
                        {
                            Score = new SimpleTwoSidesScore()
                            {
                                HomeScore = x.LiveProps.CurrentScore.HomeScore,
                                AwayScore = x.LiveProps.CurrentScore.AwayScore
                            },
                            CurrentTime = x.LiveProps is GSports.Model.Entities.Event.Live.ITimeBased ? ((GSports.Model.Entities.Event.Live.ITimeBased)x.LiveProps).CurrentTime.ToString() : x.LiveProps.CurrentState.ToString()
                        } : null
                    },
                    BetTypes = betTypes
                });
            });

            return retVal;
        }
    }
}
