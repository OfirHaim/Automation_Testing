﻿using GSports.Clients.EventsManager.Consts;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Helpers
{
    internal class DiffComparer
    {
        public static Dictionary<string, object> GetDiff(object x, object y)
        {
            Dictionary<string, object> retVal = new Dictionary<string, object>();

            try
            {
                var json1 = JsonConvert.SerializeObject(x);
                var json2 = JsonConvert.SerializeObject(y);

                var exDeserialized1 = JsonConvert.DeserializeObject<ExpandoObject>(json1);
                var exDeserialized2 = JsonConvert.DeserializeObject<ExpandoObject>(json2);

                var dict1 = new Dictionary<string, object>();
                var dict2 = new Dictionary<string, object>();

                GenerateDictionary(exDeserialized1, dict1);
                GenerateDictionary(exDeserialized2, dict2);

                var diffObj = getDiff(dict1, dict2);

                retVal = getRetObj(diffObj);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return retVal;
        }

        private static Dictionary<string, object> getRetObj(Dictionary<string, object> obj)
        {
            var retVal = new Dictionary<string, object>();

            var grouped = obj.GroupBy(x => x.Key.Substring(0, x.Key.IndexOf('.') > -1 ? x.Key.IndexOf('.') : x.Key.Length));

            foreach (var item in grouped)
            {
                if (item.Count() == 1)
                {
                    var prop = item.Single();
                    if (IsCollection(prop.Value))
                    {
                        var dic = new List<object>();
                        foreach (var i in (ICollection<object>)prop.Value)
                        {
                            dic.Add(getRetObj((Dictionary<string, object>)i));
                        }
                        retVal[item.Key] = dic;
                    }
                    else if (prop.Key == item.Key)
                        retVal[item.Key] = prop.Value;
                    else
                        retVal[item.Key] = getRetObj(item.Where(x => x.Key != item.Key).ToDictionary(x => x.Key.Substring(item.Key.Length + 1, x.Key.Length - item.Key.Length - 1), x => x.Value));
                }
                else
                    retVal[item.Key] = getRetObj(item.Where(x => x.Key != item.Key).ToDictionary(x => x.Key.Substring(item.Key.Length + 1, x.Key.Length - item.Key.Length - 1), x => x.Value));
            }

            return retVal;
        }

        private static Dictionary<string, object> getDiff(Dictionary<string, object> updateDic, Dictionary<string, object> sourceDic)
        {
            var retObj = new Dictionary<string, object>();
            foreach (var item in updateDic)
            {
                if (!sourceDic.ContainsKey(item.Key))
                    retObj[item.Key] = item.Value;
                else if (IsCollection(item.Value))
                {
                    var correspondingList = (List<object>)sourceDic[item.Key];
                    var currentList = (List<object>)item.Value;
                    var list = new List<object>();
                    foreach (Dictionary<string, object> i in currentList)
                    {
                        var matchingItem = (Dictionary<string, object>)correspondingList.FirstOrDefault(x => ((Dictionary<string, object>)x).ContainsKey(PropertyNames.COMPARE_KEY) && ((Dictionary<string, object>)x).ContainsValue(i[PropertyNames.COMPARE_KEY]));
                        if (matchingItem != null)
                        {
                            var res = getDiff(i, matchingItem);
                            if (res != null && res.Any())
                                list.Add(res);
                        }
                        else
                            list.Add(i);
                    }
                    if (list != null && list.Any())
                        retObj[item.Key] = list;
                }
                else if (!item.Value.Equals(sourceDic[item.Key]))
                    retObj[item.Key] = item.Value;
            }
            if (retObj.Any() && !retObj.ContainsKey(PropertyNames.COMPARE_KEY) && sourceDic.ContainsKey(PropertyNames.COMPARE_KEY))
                retObj.Add(PropertyNames.COMPARE_KEY, sourceDic[PropertyNames.COMPARE_KEY]);
            return retObj;
        }

        private static void GenerateDictionary(ExpandoObject obj, Dictionary<string, object> outputDic, string parent = "")
        {
            foreach (var v in obj)
            {
                string key = parent + v.Key;

                if (v.Value != null)
                {
                    if (v.Value.GetType() == typeof(ExpandoObject))
                        GenerateDictionary((ExpandoObject)v.Value, outputDic, key + ".");
                    else if (IsCollection(v.Value))
                    {
                        var list = new List<object>();
                        foreach (dynamic item in (ICollection<object>)v.Value)
                        {
                            var dic = new Dictionary<string, object>();
                            GenerateDictionary((ExpandoObject)item, dic);
                            list.Add(dic);
                        }
                        outputDic.Add(key, list);
                    }
                    else if (!outputDic.ContainsKey(key))
                        outputDic.Add(key, v.Value);
                }
            }
        }

        private static bool IsCollection(object obj)
        {
            return obj.GetType().GetInterface("ICollection") != null;
        }
    }
}
