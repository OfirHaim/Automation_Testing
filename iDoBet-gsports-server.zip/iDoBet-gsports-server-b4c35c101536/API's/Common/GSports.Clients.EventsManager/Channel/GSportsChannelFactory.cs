﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Channel
{
    class GSportsChannelFactory<T> : ChannelFactory<T>
    {
        public GSportsChannelFactory(string endpointConfigurationName)
            : base(endpointConfigurationName)
        {
            //TODO: add user details to Transport
            this.Credentials.UserName.UserName = "a";
            this.Credentials.UserName.Password = "b";

#if DEBUG
            //TODO: remove on production! danger! [Trust all SSL certificates]
            System.Net.ServicePointManager.ServerCertificateValidationCallback = ((sender, certificate, chain, sslPolicyErrors) => true);
#endif
        }
    }
}
