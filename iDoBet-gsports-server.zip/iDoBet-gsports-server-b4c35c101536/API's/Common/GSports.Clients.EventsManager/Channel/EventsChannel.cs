﻿using GSports.Common;
using GSports.Contracts;
using GSports.GLogger;
using GSports.Model.Filter;
using GSports.Model.Requests.Event;
using GSports.Model.Responses.Event;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Channel
{
    internal class EventsChannel
    {
        public static GetEventsResponse GetEvents(bool onlyActiveCoupon, string providerIds = null, string sportIds = null, string betTypeIds = null, DateTime? lastUpdate = null)
        {
            GetEventsResponse retVal = null;
            try
            {
                using (var factory = new GSportsChannelFactory<IEventService>(ServiceConsts.EVENT_SERVICE))
                {
                    var request = new GetEventsRequest()
                    {
                        //UserToken ="Online",
                        RequestFlags = eGetEventsFlags.LoadBetTypes | eGetEventsFlags.LoadLimitations,
                        LastUpdate = lastUpdate ?? DateTime.MinValue,
                        filter = new EventFilter()
                        {
                            OnlyActiveCoupon = onlyActiveCoupon,
                            SportTypeIds = string.IsNullOrEmpty(sportIds) ? null : sportIds.Split(',').Select(r => (long)int.Parse(r)).ToList(),
                            ProviderIds = string.IsNullOrEmpty(providerIds) ? null : providerIds.Split(',').Select(r => int.Parse(r)).ToList()
                            // ,Ids = new List<long>() { 39612819 }
                        },
                        BetTypeIds = string.IsNullOrEmpty(betTypeIds) ? null : betTypeIds.Split(',').Select(r => (long)int.Parse(r)).ToList()                                                 
                    };

                    var service = factory.CreateChannel();
                    retVal = service.GetEvents(request);
                }
            }
            catch (Exception ex)
            {

                Logger.WriteLog(eLogLevel.Error, string.Empty, ex);
            }

            return retVal;
        }
    }
}
