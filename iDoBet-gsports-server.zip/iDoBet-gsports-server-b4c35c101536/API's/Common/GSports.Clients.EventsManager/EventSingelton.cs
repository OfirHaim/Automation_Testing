﻿using GSports.Clients.EventsManager.Helpers;
using GSports.Clients.EventsManager.Model.Entities;
using GSports.Clients.EventsManager.BL.ModelConvertor;
using GSports.Common;
using GSports.GLogger;
using GSports.Model.Entities.Event;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using GSports.PushService.Client;
using GSports.Clients.EventsManager.Model.Entities.Enums;
using System.IO;
using GSports.Clients.EventsManager.Config;
using System.Diagnostics;

namespace GSports.Clients.EventsManager
{
    public sealed class EventSingleton
    {
        private readonly string CHANNEL_NAME;
        private readonly bool HOLD_ONLY_ACTIVE_COUPON;
        private readonly int CHECK_FOR_UPDATE_INTERVAL;
        private readonly string PROVIDER_IDS;
        private readonly string SPORT_TYPE_IDS;
        private readonly string BET_TYPE_IDS;
        private readonly bool IS_MASTER;

       // public Dictionary<DateTime, List<Event>> updateLog = new Dictionary<DateTime, List<Event>>();
        private static SortedList<DateTime, List<UpdateMessage>> _updateMessages = new SortedList<DateTime, List<UpdateMessage>>();
        private static long _messageCount;
        private static int _updateMessagesLifeTimeMinutes;
        private List<Event> _data { get; set; }
        Dictionary<long, List<DisplayBetData>> _displayBetData { get; set; }

        private Timer _timer;

        private Timer _removeEventTimer ;


        private object _lockObject = new object();
        

        private static object _syncRoot = new object();

        private static volatile EventSingleton _instance;        
        public DateTime LastUpdate { get; private set; }
      

        public int[] ActiveCouponIds { get; set; }

        public static EventSingleton InitEventSingelton(string pushServerUrl, string token, bool isMaster, string channelName ,bool holdOnlyActiveCoupons, int updateMessagesLifeTimeMinutes = 0 , int checkForChangesEvery = 2000,string providerIds = null, string SportIds = null, string BetTypeIds = null)
        {
            if (_instance == null)
            {
                lock (_syncRoot)
                {
                    if (_instance == null)
                    {
                        _instance = new EventSingleton(pushServerUrl, token, isMaster, channelName, holdOnlyActiveCoupons, updateMessagesLifeTimeMinutes, checkForChangesEvery, providerIds,SportIds,BetTypeIds);
                    }
                }
            }
            return _instance;
        }

        //public static EventSingleton InitEventSingelton(bool holdOnlyActiveCoupons = false)
        //{
        //    if (_instance == null)
        //    {
        //        lock (_syncRoot)
        //        {
        //            if (_instance == null)
        //            {
        //                _instance = new EventSingleton("", "", false, "", holdOnlyActiveCoupons);
        //            }
        //        }
        //    }
        //    return _instance;
        //}

        public static EventSingleton Instance
        {
            get
            {
                if (_instance != null)
                    return _instance;
                else
                    throw new Exception("Instance should be instanced through the InitEventSingelton method");
            }
        }

        private EventSingleton(string pushServerUrl, string token, bool isMaster, string channelName, bool holdOnlyActiveCoupons, int updateMessagesLifeTimeMinutes, int checkForChangesEvery, string providerIds, string SportIds, string BetTypeIds)
        {
            CHANNEL_NAME = channelName;
            HOLD_ONLY_ACTIVE_COUPON = holdOnlyActiveCoupons;
            PROVIDER_IDS = providerIds;
            SPORT_TYPE_IDS = SportIds;
            BET_TYPE_IDS = BetTypeIds;
            CHECK_FOR_UPDATE_INTERVAL = checkForChangesEvery;
            IS_MASTER = isMaster;
            _messageCount = 0;
            LoadJson("betTypes.json");
            _updateMessagesLifeTimeMinutes = updateMessagesLifeTimeMinutes;
            if (isMaster)
            {
                PushClient.Instance.Connect(pushServerUrl, token).ContinueWith(async res =>
                {
                    if (!res.IsFaulted)
                        await PushClient.Instance.ResetCounter(channelName);
                });
            }

            Task.Run(() => LoadEvent(10, 60000)).ContinueWith((res) =>
                 {
                     if (!res.Result)
                     {
                         Logger.WriteLog(eLogLevel.Error, "Failed Loading events!!!");
                     }
                 });
        }


        private bool LoadEvent(int maxRetries, int delayInMilliseconds)
        {
            bool succeeded = false;
            int numTries = 0;
            while (numTries < maxRetries && !succeeded)
            {
                try
                {
                    var res = Channel.EventsChannel.GetEvents(HOLD_ONLY_ACTIVE_COUPON, PROVIDER_IDS, SPORT_TYPE_IDS, BET_TYPE_IDS);
                    if (res.IsSuccessfull())
                    {
                        var events = CompressedBinaryConverter.ToObject<List<SportGame>, SportGame>(res.EventData);
                        LastUpdate = res.ServerLastUpdate;
                        ActiveCouponIds = res.ActiveCouponIds;
                        var clientEvents = EventConverter.convertEvents(events);
                        // update display bet type
                        clientEvents.ForEach(eve =>
                        {
                            updateDisplayBetType(eve);
                            UpdateBetTypeData(eve);
                        });

                        _data = clientEvents;
                        _timer = new Timer(checkForChanges, null, CHECK_FOR_UPDATE_INTERVAL, CHECK_FOR_UPDATE_INTERVAL);
                        _removeEventTimer = new Timer(removeClosedEvents, null, 600000, 600000); // every 10 minets 
                        succeeded = true;
                        Logger.WriteLog(eLogLevel.Info, string.Format("Load events succeeded, active coupon = {0}, provider iDs = {1}, Sports Ids = {2}, Bet Type Ids = {3} totla events = {4} ", HOLD_ONLY_ACTIVE_COUPON, PROVIDER_IDS,SPORT_TYPE_IDS, BET_TYPE_IDS, events.Count));
                    }
                    else
                    {
                        Logger.WriteLog(eLogLevel.Error, string.Format("Failed Loading events on first run! try number : {0}, wating {1} ms and try again", (numTries+1), delayInMilliseconds));
                    }
                }
                catch (Exception)
                {
                    Logger.WriteLog(eLogLevel.Error,string.Format( "Failed Loading events on first run! try number : {0}, wating {1} ms and try again", (numTries+1),delayInMilliseconds));
                    
                }
                finally
                {
                    numTries++;
                }               
               Thread.Sleep(delayInMilliseconds);
            }
            return succeeded;
        }
        

        public int EvnetCount
        {
           get { return ((_data == null)? 0 : _data.Where(x => x.ForClient).Count()); }
        }
        public IEnumerable<Event> GetEvents(DateTime? lastUpdate = null, bool? activeCoupon = null, List<int> coupinIds = null, List<long> eventIds = null, int? skip = null, int? take = null, List<long> betTypeIds = null) =>           
            _data?.Where(x => ((eventIds==null)? x.ForClient : true)
                        && (lastUpdate.HasValue == false || x.EventData.LastUpdate >= lastUpdate)
                        && (activeCoupon.HasValue == false  || x.EventData.CouponId > 0)
                        && (coupinIds == null || coupinIds.Count == 0  || coupinIds.Contains(x.EventData.CouponId))
                        && (eventIds == null || eventIds.Count == 0 || eventIds.Contains(x.EventData.Id))
            ).OrderBy(x => (string.IsNullOrEmpty(x.GameNumber) || x.GameNumber == "0") ? int.MaxValue : int.Parse(x.GameNumber)).Skip(skip ?? 0).Take(take ?? 100000)/* if take = null take all */.
            Select(ev=> new  Event
            {
                 EventData = ev.EventData,                 
                 BetTypes = ev.BetTypes.Where(
                 bt =>  betTypeIds == null ||
                 betTypeIds.Count == 0     ||
                 betTypeIds.Count == 1 && betTypeIds[0] < 0 && (_displayBetData.SelectMany(x => x.Value.Select(y => y.id)).Contains(bt.BetTypeData.Id)) ||
                 betTypeIds.Contains(bt.BetTypeData.Id)                  
                 ).ToList()
            });
     
        // .SelectMany(x=>x.BetTypes).Where(bt=>
        //betTypeIds == null || betTypeIds.Count == 0 || betTypeIds.Contains(bt.BetTypeData.Id))
           


        public IEnumerable<UpdateMessage> GetEventsUpdates(DateTime? lastUpdate) =>
            _updateMessages.Where(r => r.Key > lastUpdate).SelectMany(r=>r.Value.Select(c=>c));


        public Event GetEventByCk(string ck) => _data?.FirstOrDefault(x => x.CompareKey == ck);
        private void removeClosedEvents(object state)
        {

            if (Monitor.TryEnter(_lockObject, 5000))
            {
                try
                {
                    var toDeleteList = _data.Where(r => !r.ForClient && r.EventData.GameTime < DateTime.Now.AddHours(-4)).Select(r => r.CompareKey).ToList();
                    deleteEvents(toDeleteList);
                    _data.RemoveAll(r => toDeleteList.Contains(r.CompareKey));
                }
                finally
                {
                    Monitor.Exit(_lockObject);
                }
            }         
        }
        private void checkForChanges(object state)
        {
            if (Monitor.TryEnter(_lockObject))
            {
                bool toDelete, toAdd;
                var toDeleteList = new List<string>();
                var toAddList = new List<Event>();
                var formattedEvents = new List<Dictionary<string, object>>();

                try
                {
                    var response = Channel.EventsChannel.GetEvents(HOLD_ONLY_ACTIVE_COUPON, PROVIDER_IDS, SPORT_TYPE_IDS, BET_TYPE_IDS, LastUpdate);

                    if (response != null && response.IsSuccessfull())
                    {
                        LastUpdate = response.ServerLastUpdate;
                        ActiveCouponIds = response.ActiveCouponIds;
                        var changedEvents = CompressedBinaryConverter.ToObject<List<SportGame>, SportGame>(response.EventData);
                        var convertedEvents = EventConverter.convertEvents(changedEvents);
                        //updateLog.Add(_lastUpdate, convertedEvents.ToList());

                        convertedEvents.ForEach(eve =>
                        {
                            var currentEvent = _data.FirstOrDefault(x => x.CompareKey == eve.CompareKey);
                            //fill event with missing data  
                            int? currIdx = fillUpdatedEvent(eve);
                            // update bet type count 
                            UpdateBetTypeData(eve);
                            // update display bet type                                                    
                            updateDisplayBetType(eve);                           
                            var diffObj = getDiffObj(eve, out toDelete, out toAdd);
                            //if (x.ForClient && diffObj.IsNotNullAndAny() && !toDelete && !toAdd)
                            // only if current evnet or update for client will send update to clients 
                            if (((currentEvent !=null && currentEvent.ForClient) || eve.ForClient) && diffObj.IsNotNullAndAny() && !toDelete && !toAdd)
                                formattedEvents.Add(diffObj);

                            else if (toDelete)
                                toDeleteList.Add(eve.CompareKey);
                            else if ((toAdd || !currIdx.HasValue) && eve.ForClient)
                                toAddList.Add(eve);
                            
                            mergeNewData(currIdx, eve);
                        });
                        List<UpdateMessage> messages = new List<UpdateMessage>();
                        var updateMessage = updateEvents(formattedEvents);
                        if(updateMessage != null)
                            messages.Add(updateMessage);
                        var deleteMessage = deleteEvents(toDeleteList);
                        if (deleteMessage != null)
                            messages.Add(deleteMessage);
                        var insertMessage =  insertNewEvents(toAddList);
                        if (insertMessage != null)
                            messages.Add(insertMessage);
                        addMsgToCache(messages);

                    }
                    else
                        Logger.WriteLog(eLogLevel.Error, "TODO");
                }
                catch (Exception ex)
                {
                    Logger.WriteLog(ex);
                }
                finally
                {
                    Monitor.Exit(_lockObject);
                }
            }
        }

        private void UpdateBetTypeData(Event eve)
        {
            if (eve != null && eve.BetTypes != null && eve.EventData != null)
            {                
                eve.BetTypes.ForEach(bt =>
                {
                    bt.BetTypeData.Parent = eve;
                    bt.Odds.ForEach(o => o.Parent = bt);
                });


                eve.EventData.BetTypeCount = eve.BetTypes.Count(bt => bt.IsEnable());
            }
        }
        private void updateDisplayBetType(Event eve)
        {
           
            if (_displayBetData!=null &&  _displayBetData.ContainsKey(eve.EventData.SportType.Id))
            {
                List<DisplayBetData> displayBetData = _displayBetData[eve.EventData.SportType.Id];
                eve.BetTypes.FindAll(bt => bt.BetTypeData.IsDisplay).ForEach(bt =>
                {
                    bt.BetTypeData.IsDisplay = false;
                    bt.BetTypeData.IsLineDisplay = false;
                });
                displayBetData.ForEach(item =>
                {
                  
                   
                    if (item.line == "auto")
                    {
                        var minDeltaPrice = eve.BetTypes.Where(bt => bt.BetTypeData.Id == item.id && bt.MaxDeltaPrice!=null).Min(bt => bt.MaxDeltaPrice);
                        if (minDeltaPrice != null)
                        {
                            var betType = eve.BetTypes.Where(bt => bt.BetTypeData.Id == item.id && bt.MaxDeltaPrice == minDeltaPrice).First();
                            if (betType != null)
                            {
                                betType.BetTypeData.IsLineDisplay = item.isLineDisplay;
                                betType.BetTypeData.IsDisplay = true;
                            }
                        }
                    }
                    else
                    {
                        eve.BetTypes.FindAll(bt => bt.BetTypeData.Id == item.id && (bt.BetTypeData.Line??"") == (item.line??"")).ForEach(bt =>
                        {
                            bt.BetTypeData.IsLineDisplay = item.isLineDisplay;
                            bt.BetTypeData.IsDisplay = true;

                        });
                    }
              }
            );
            }
           
        }

        private int? fillUpdatedEvent(Event newUpdateEve)
        {
            int? retVal = null;
            var currentEvent = _data.FirstOrDefault(x => x.CompareKey == newUpdateEve.CompareKey);
            if (currentEvent != null)
            {
                retVal = _data.IndexOf(currentEvent);
                newUpdateEve.BetTypes.ForEach(bt =>
                {
                    var existsBetType = currentEvent.BetTypes.FirstOrDefault(x => x.CompareKey == bt.CompareKey);
                    if (existsBetType != null)
                    {                      
                        if (bt.Odds == null)
                            bt.Odds = new List<Odd>();
                        bt.Odds.AddRange(existsBetType.Odds.Where(x => !bt.Odds.Any(a => a.CompareKey == x.CompareKey)).Select(x=>  (Odd) x.Clone()));
                   
                    }
                });
                newUpdateEve.BetTypes.AddRange(currentEvent.BetTypes.Where(x => !newUpdateEve.BetTypes.Any(a => a.CompareKey == x.CompareKey)).Select(x=> (BetType)x.Clone()  ));
            }
            return retVal;
        }

        private Dictionary<string, object> getDiffObj(Event newUpdateEve, out bool toDelete, out bool toAdd)
        {
            Dictionary<string, object> retVal = null;
            toDelete = toAdd = false;

            var currentEvent = _data.FirstOrDefault(x => x.CompareKey == newUpdateEve.CompareKey);
            var index = _data.IndexOf(currentEvent);
            if (currentEvent != null)
            {
                var diff = DiffComparer.GetDiff(newUpdateEve, currentEvent);
                if (diff.Count > 1)
                    retVal = diff;
               
               // toDelete = _data[index].ForClient && !newUpdateEve.ForClient;
               // toAdd = !_data[index].ForClient && newUpdateEve.ForClient;
               // remove - return only updates 
            }
            else
               toAdd = true;
            return retVal;
        }

        private void mergeNewData(int? index, Event newEvent)
        {
            newEvent.EventData.LastUpdate = DateTime.UtcNow;
            if (index.HasValue)
                _data[index.Value] = newEvent;
            else //if(newEvent.ForClient)
                _data.Add(newEvent);
        }

        private UpdateMessage updateEvents(List<Dictionary<string, object>> updates)
        {
            UpdateMessage retVal = null;
            try
            {
                if (updates.Any())
                {
                    var key = "updateEvents";
                    broadcastMessageToChannel(key, JsonConvert.SerializeObject(updates));
                    //addMsgToCache(key, updates);
                    retVal = new UpdateMessage(_messageCount++, key, updates, DateTime.UtcNow);                    
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
            }
            return retVal;
        }

        private UpdateMessage deleteEvents(List<string> toDeleteList)
        {
            UpdateMessage retVal = null;
            try
            {
                if (toDeleteList.Any())
                {
                    var key = "deleteEvents";
                    broadcastMessageToChannel(key, JsonConvert.SerializeObject(toDeleteList));
                    //addMsgToCache(key, toDeleteList);
                    retVal = new UpdateMessage(_messageCount++, key, toDeleteList, DateTime.UtcNow);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
            }
            return retVal;
        }

        private UpdateMessage insertNewEvents(List<Event> events)
        {
            UpdateMessage retVal = null;
            try
            {
                if (events.Any())
                {
                    var key = "insertNewEvents";
                    broadcastMessageToChannel(key, JsonConvert.SerializeObject(events));
                    //addMsgToCache(key, events);
                    retVal = new UpdateMessage(_messageCount++, key, events, DateTime.UtcNow);
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
            }
            return retVal;
        }

        private async void broadcastMessageToChannel(string key, string value)
        {          
            if (IS_MASTER)
            {
                await PushClient.Instance.PushMessageToChannel(CHANNEL_NAME, new Message(key, value));
            }
            
        }
        private  void addMsgToCache(List<UpdateMessage> messages)
        {          
            try
            {
               
                if (_updateMessagesLifeTimeMinutes > 0)
                {
                    CleanMsgFromCache();
                    if (messages != null && messages.Count > 0)
                    {
                        lock (_updateMessages)
                        {
                            _updateMessages.Add(DateTime.UtcNow, messages);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
            }
          
        }
        private void CleanMsgFromCache()
        {
            try
            {              
                lock (_updateMessages)
                {
                    var keysToRemove = _updateMessages.Where(r => r.Key < DateTime.UtcNow.AddMinutes(_updateMessagesLifeTimeMinutes * -1)).Select(r=>r.Key).ToList();
                    foreach (var key in keysToRemove)
                    {
                        _updateMessages.Remove(key);
                    }
                }                
            }
            catch (Exception ex)
            {
                Logger.WriteLog(ex);
            }

        }
        public void LoadJson(string fileName)
        {
            try
            {
                using (StreamReader r = new StreamReader(fileName))
                {
                    string json = r.ReadToEnd();
                    var root = JsonConvert.DeserializeObject<RootDisplayBetTypes>(json);
                    if (root != null && root.DisplayBetTypes != null && root.DisplayBetTypes.Items != null)
                    {
                        _displayBetData = new Dictionary<long, List<DisplayBetData>>();
                       
                        foreach (var item in root.DisplayBetTypes.Items.GroupBy(i => i.sportId))
                            _displayBetData.Add((long)item.Key, item.SelectMany(s => s.Live).Union(item.SelectMany(s => s.Prematch)).ToList());
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.WriteLog(eLogLevel.Warn, "Failed Loading json bet templat", ex);
            }
        }

  
    }
}