﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Consts
{
    public class PropertyNames
    {
        public const string COMPARE_KEY = "ck";
        public const string NAME = "name";
        public const string SHORT_NAME = "shortname";
        public const string STATUS = "status";
        public const string ORDER = "order";
        public const string PRICE = "price";
        public const string DATA = "data";
        public const string GAME_NUMBER = "gn";
        public const string BETTYPES_COUNT = "btCount";
        public const string META_DATA = "mtd";
        public const string MAIN_DISPLAY = "md";
        
    }
}
