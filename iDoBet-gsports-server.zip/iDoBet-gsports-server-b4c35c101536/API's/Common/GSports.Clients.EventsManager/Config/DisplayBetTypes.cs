﻿namespace GSports.Clients.EventsManager.Config
{
    public class RootDisplayBetTypes
    {
        public Displaybettypes DisplayBetTypes { get; set; }
    }

    public class Displaybettypes
    {
        public Item[] Items { get; set; }
    }

    public class Item
    {
        public int sportId { get; set; }
        public DisplayBetData[] Live { get; set; }
        public DisplayBetData[] Prematch { get; set; }
    }

    public class DisplayBetData
    {
        public long id { get; set; }
        public string line { get; set; }
        public bool isLineDisplay { get; set; }
    }


}