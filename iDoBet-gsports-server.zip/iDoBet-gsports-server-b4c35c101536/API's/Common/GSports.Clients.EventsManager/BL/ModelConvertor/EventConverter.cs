﻿using GSports.Clients.EventsManager.Model.Entities;
using GSports.Clients.EventsManager.Model.Entities.Enums;
using GSports.Model.Entities.Event;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.BL.ModelConvertor
{
    public class EventConverter
    {
        public static List<Event> convertEvents(List<SportGame> sportGames)
        {
            List<Event> retVal = new List<Event>();

            sportGames.ForEach(x =>
            {
                Event eve = new Event()
                {
                    EventData = new EventData()
                    {
                        Id = x.Id,
                        Country = new EventCountry() { Id = x.Country.Id, Name = x.Country.Name, ShortName = x.Country.ShortName, IsActive = x.Country.IsActive, Order = x.Country.Order },
                        League = new League() { Id = x.League.Id, Name = x.League.Name, ShortName = x.League.ShortName, IsActive = x.League.IsActive, Order = x.League.Order },
                        HomeTeam = x.HomeTeam == null ? null : new Team() { Id = x.HomeTeam.Id, Name = x.HomeTeam.Name, ShortName = x.HomeTeam.ShortName },
                        AwayTeam = x.AwayTeam == null ? null : new Team() { Id = x.AwayTeam.Id, Name = x.AwayTeam.Name, ShortName = x.AwayTeam.ShortName },
                        EventState = (eEventState)x.CurrentState,
                        EventStatus = (eEventStatus)x.EventStatus,
                        GameTime = x.EventDate,
                        TopEventOrder = x.TopEventOrder,
                        GameNumber = x.GameNumber.ToString(),
                        SportType = new SportType() { Id = x.SportType.Id, Name = x.SportType.Name, IsActive = x.SportType.IsActive, Order = x.SportType.Order },
                        CouponId = x.CurrentCouponId,
                        IsBookedForLive = x.IsBooked,
                        IsActive  =x.IsActive,
                        Live = x.EventStatus == GSports.Model.Consts.eEventStatus.Live ? new LiveData()
                        {
                            Score = new SimpleTwoSidesScore()
                            {
                                HomeScore = x.LiveProps.CurrentScore == null ? 0 : x.LiveProps.CurrentScore.HomeScore,
                                AwayScore = x.LiveProps.CurrentScore == null ? 0 : x.LiveProps.CurrentScore.AwayScore
                            },
                            HomeRedCards = x.LiveProps is GSports.Model.Entities.Event.Live.ICardsSport ?
                                           ((GSports.Model.Entities.Event.Live.ICardsSport)x.LiveProps).LiveCards?.Count(c => c.ColorType == GSports.Model.Consts.eCard.RED && c.Team == GSports.Model.Entities.eHomeAway.HOME) : 0,
                            AwayRedCards = x.LiveProps is GSports.Model.Entities.Event.Live.ICardsSport ?
                                           ((GSports.Model.Entities.Event.Live.ICardsSport)x.LiveProps).LiveCards?.Count(c => c.ColorType == GSports.Model.Consts.eCard.RED && c.Team == GSports.Model.Entities.eHomeAway.AWAY) : 0,
                            CurrentTime = DisplayTime(x.LiveProps)
                        } : null
                    },
                  
                };
                var betTypes = new List<BetType>();
                x.BetTypes.ForEach(bt =>
                {
                    if (bt.Odds.Count > 0)
                    {
                        bt.Odds.GroupBy(g => g.Line).ToList().ForEach(gbt =>
                        {

                            BetType betType = new BetType()
                            {
                                BetTypeData = new BetTypeData()
                                {
                                    Id = bt.Id,
                                    Name = bt.Name,
                                    ShortName = bt.ShortName,
                                    //  Status = odds.All(a => a.Status == eOddStatus.Closed) ? eBetStatus.Closed : (eBetStatus)bt.BetStatus,
                                    Status = (eBetStatus)bt.BetStatus,
                                    Line = gbt.First().Line,
                                    LastUpdate = bt.LastUpdate,
                                    SortingOrder = bt.Order,
                                    IsActive = bt.IsActive,
                                    IsLive = bt.IsLive
                                },

                            };
                            betType.Odds = new List<Odd>();
                            gbt.ToList().ForEach(od =>
                            {
                                betType.Odds.Add(new Odd()
                                {
                                    Name = od.Name,
                                    ShortName = od.ShortName,
                                    Price = od.CurrentPrice,
                                    Status = (eOddStatus)od.status,
                                    BettingTypeId = od.BettingTypeId,
                                    Shortcut = od.FormatShortcut,
                                    LastUpdate = od.LastUpdate,
                                    OrderCol = od.OrderCol,
                                    OrderRow = od.OrderRow
                                });
                            });
                        betTypes.Add(betType);
                            
                        });
                    }
                    else// only bet type update 
                    {
                        // get bet types from cache and update all 
                        var currentEvent = EventSingleton.Instance.GetEventByCk(x.Id.ToString());
                        if (currentEvent != null)
                        {
                            var existsBetTypes = currentEvent.BetTypes.Where(br => br.BetTypeData.Id == bt.Id);
                            if (existsBetTypes != null && existsBetTypes.Count() > 0)
                                existsBetTypes.ToList().ForEach(cbt =>
                                {
                                    betTypes.Add(new BetType()
                                    {
                                        BetTypeData = new BetTypeData()
                                        {
                                            Id = bt.Id,
                                            Name = bt.Name,
                                            ShortName = bt.ShortName,
                                            Status = (eBetStatus)bt.BetStatus,
                                            Line = cbt.BetTypeData.Line,
                                            LastUpdate = bt.LastUpdate,
                                            SortingOrder = bt.Order,
                                            IsActive = bt.IsActive,
                                            IsLive = bt.IsLive
                                        }
                                    });
                                });
                        }
                    }
                           
                });
                eve.BetTypes = betTypes;
                retVal.Add(eve);
            });

            return retVal;
        }

        private static string DisplayTime(GSports.Model.Entities.Event.Live.LiveData liveProps)
        {
            string retVal = "";
            if (liveProps is GSports.Model.Entities.Event.Live.ITimeBased)
                retVal = ((GSports.Model.Entities.Event.Live.ITimeBased)liveProps).CurrentTime.ToString();
            else
                retVal = liveProps.CurrentState.ToString();
            switch (liveProps.CurrentState)
            {
                case GSports.Model.Consts.eEventState.PAUSED:
                    {
                        retVal = "HT";
                        break;
                    }
                case GSports.Model.Consts.eEventState.OT_HT:
                    {
                        retVal = "HT";
                        break;
                    }
                case GSports.Model.Consts.eEventState.AWAITING_OT:
                    {
                        retVal = "OT";
                        break;
                    }
                case GSports.Model.Consts.eEventState.ITEM1SET:
                    {
                        retVal = "Set 1";
                        break;
                    }
                case GSports.Model.Consts.eEventState.ITEM2SET:
                    {
                        retVal = "Set 2";
                        break;
                    }
                case GSports.Model.Consts.eEventState.ITEM3SET:
                    {
                        retVal = "Set 3";
                        break;
                    }
                case GSports.Model.Consts.eEventState.ITEM4SET:
                    {
                        retVal = "Set 4";
                        break;
                    }
                case GSports.Model.Consts.eEventState.ITEM5SET:
                    {
                        retVal = "Set 5";
                        break;
                    }
                case GSports.Model.Consts.eEventState.NOT_STARTED:
                    {
                        retVal = "Soon";
                        break;
                    }

                default:
                    {
                        break;
                    }
            }
            return retVal;
        }

    }
}
