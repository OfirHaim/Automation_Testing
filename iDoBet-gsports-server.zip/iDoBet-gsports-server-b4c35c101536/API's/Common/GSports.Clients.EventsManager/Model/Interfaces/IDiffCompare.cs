﻿using GSports.Clients.EventsManager.Consts;
using Newtonsoft.Json;

namespace GSports.Clients.EventsManager.Model.Interfaces
{
    public interface IDiffCompare
    {
        [JsonProperty(PropertyName = PropertyNames.COMPARE_KEY)]
        string CompareKey { get; }
    }
}
