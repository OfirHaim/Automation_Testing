﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities
{
    public class UpdateMessage
    {
        [JsonProperty(PropertyName = "key")]
        public string Key { get; set; }
        [JsonProperty(PropertyName = "value")]
        public object Value { get; set; }
        [JsonProperty(PropertyName = "messageId")]
        public long MessageId { get; set; }
        [JsonProperty(PropertyName = "time")]
        public DateTime CreateTime { get; set; }

        public UpdateMessage()
        {

        }

        public UpdateMessage(long messageId, string key, object value, DateTime createTime)
        {
            Key = key;
            Value = value;
            MessageId = messageId;
            CreateTime = createTime;
        }
        public override string ToString()
        {
            return JsonConvert.SerializeObject(this);
        }
    }
}
