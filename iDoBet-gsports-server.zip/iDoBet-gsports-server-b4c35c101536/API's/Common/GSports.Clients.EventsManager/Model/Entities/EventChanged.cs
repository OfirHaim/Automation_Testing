﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities
{
   
    public class EventChanged
    {
 
        public long EventId{ get; set; }    
        public string OddName { get; set; }
        public long BetTypeId { get; set; }
        public string BetTypeLine { get; set; }
    }
}
