﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities.Enums
{
    public enum eBetStatus
    {
        Open = 0,

        Suspended = 1,

        Closed = 2,

        Deleted = 3,

        Unknown = -1,

        Canceled = 4
    }
}
