﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities.Enums
{
    public enum eOddStatus
    {
        Unknown = -1,

        Open = 0,

        Suspended = 1,

        Closed = 2,
    }
}
