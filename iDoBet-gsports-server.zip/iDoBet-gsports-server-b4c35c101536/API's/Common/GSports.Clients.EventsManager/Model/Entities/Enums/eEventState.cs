﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace GSports.Clients.EventsManager.Model.Entities.Enums
{
    public enum eEventState
    {
        // Summary:
        //     Undefined
        UNDEFINED = 0,
        //
        // Summary:
        //     Not started
        NOT_STARTED = 1,
        //
        // Summary:
        //     Started
        STARTED = 2,
        //
        // Summary:
        //     1st period
        ITEM1P = 3,
        //
        // Summary:
        //     2nd period
        ITEM2P = 4,
        //
        // Summary:
        //     3rd period
        ITEM3P = 5,
        //
        // Summary:
        //     4th period
        ITEM4P = 6,
        //
        // Summary:
        //     5th period
        ITEM5P = 7,
        //
        // Summary:
        //     1st set
        ITEM1SET = 8,
        //
        // Summary:
        //     2nd set
        ITEM2SET = 9,
        //
        // Summary:
        //     3rd set
        ITEM3SET = 10,
        //
        // Summary:
        //     4th set
        ITEM4SET = 11,
        //
        // Summary:
        //     5th set
        ITEM5SET = 12,
        //
        // Summary:
        //     1st quarter
        ITEM1Q = 13,
        //
        // Summary:
        //     2nd quarter
        ITEM2Q = 14,
        //
        // Summary:
        //     3rd quarter
        ITEM3Q = 15,
        //
        // Summary:
        //     4th quarter
        ITEM4Q = 16,
        //
        // Summary:
        //     Paused
        PAUSED = 17,
        //
        // Summary:
        //     1st pause
        PAUSE1 = 18,
        //
        // Summary:
        //     2nd pause
        PAUSE2 = 19,
        //
        // Summary:
        //     3rd pause
        PAUSE3 = 20,
        //
        // Summary:
        //     4th pause
        PAUSE4 = 21,
        //
        // Summary:
        //     Overtime
        OT = 22,
        //
        // Summary:
        //     Awaiting overtime
        AWAITING_OT = 23,
        //
        // Summary:
        //     1st period overtime
        ITEM1P_OT = 24,
        //
        // Summary:
        //     Overtime halftime
        OT_HT = 25,
        //
        // Summary:
        //     2nd period overtime
        ITEM2P_OT = 26,
        //
        // Summary:
        //     After overtime
        AFTER_OT = 27,
        //
        // Summary:
        //     Awaiting penalties
        AWAITING_PEN = 28,
        //
        // Summary:
        //     Penalties
        PEN = 29,
        //
        // Summary:
        //     After penalties
        AFTER_PEN = 30,
        //
        // Summary:
        //     Ended
        ENDED = 31,
        //
        // Summary:
        //     Postponed
        POSTPONED = 32,
        //
        // Summary:
        //     Delayed
        DELAYED = 33,
        //
        // Summary:
        //     Cancelled
        CANCELED = 34,
        //
        // Summary:
        //     Interrupted
        INTERRUPTED = 35,
        //
        // Summary:
        //     Abandoned
        ABANDONED = 36,
        //
        // Summary:
        //     Walkover
        WALKOVER = 37,
        //
        // Summary:
        //     1st walkover
        WALKOVER1 = 38,
        //
        // Summary:
        //     2nd walkover
        WALKOVER2 = 39,
        //
        // Summary:
        //     Retired
        RETIRED = 40,
        //
        // Summary:
        //     1st retired
        RETIRED1 = 41,
        //
        // Summary:
        //     2nd retired
        RETIRED2 = 42,
        //
        // Summary:
        //     1st inning (top)
        ITEM1IT = 43,
        //
        // Summary:
        //     1st inning (bottom)
        ITEM1IB = 44,
        //
        // Summary:
        //     2nd inning (top)
        ITEM2IT = 45,
        //
        // Summary:
        //     2nd inning (bottom)
        ITEM2IB = 46,
        //
        // Summary:
        //     3rd inning (top)
        ITEM3IT = 47,
        //
        // Summary:
        //     3rd inning (bottom)
        ITEM3IB = 48,
        //
        // Summary:
        //     4th inning (top)
        ITEM4IT = 49,
        //
        // Summary:
        //     4th inning (bottom)
        ITEM4IB = 50,
        //
        // Summary:
        //     5th inning (top)
        ITEM5IT = 51,
        //
        // Summary:
        //     5th inning (bottom)
        ITEM5IB = 52,
        //
        // Summary:
        //     6th inning (top)
        ITEM6IT = 53,
        //
        // Summary:
        //     6th inning (bottom)
        ITEM6IB = 54,
        //
        // Summary:
        //     7th inning (top)
        ITEM7IT = 55,
        //
        // Summary:
        //     7th inning (bottom)
        ITEM7IB = 56,
        //
        // Summary:
        //     8th inning (top)
        ITEM8IT = 57,
        //
        // Summary:
        //     8th inning (bottom)
        ITEM8IB = 58,
        //
        // Summary:
        //     9th inning (top)
        ITEM9IT = 59,
        //
        // Summary:
        //     9th inning (bottom)
        ITEM9IB = 60,
        //
        // Summary:
        //     Extra inning top
        EIT = 61,
        //
        // Summary:
        //     Extra inning bottom
        EIB = 62,
        //
        // Summary:
        //     Break 1st top 1st bottom
        BT1B1 = 63,
        //
        // Summary:
        //     Break 2nd top 1st bottom
        BT2B1 = 64,
        //
        // Summary:
        //     Break 2nd top 2nd bottom
        BT2B2 = 65,
        //
        // Summary:
        //     Break 3rd top 2nd bottom
        BT3B2 = 66,
        //
        // Summary:
        //     Break 3rd top 3rd bottom
        BT3B3 = 67,
        //
        // Summary:
        //     Break 4th top 3rd bottom
        BT4B3 = 68,
        //
        // Summary:
        //     Break 4th top 4th bottom
        BT4B4 = 69,
        //
        // Summary:
        //     Break 5th top 4th bottom
        BT5B4 = 70,
        //
        // Summary:
        //     Break 5th top 5th bottom
        BT5B5 = 71,
        //
        // Summary:
        //     Break 6th top 5th bottom
        BT6B5 = 72,
        //
        // Summary:
        //     Break 6th top 6th bottom
        BT6B6 = 73,
        //
        // Summary:
        //     Break 7th top 6th bottom
        BT7B6 = 74,
        //
        // Summary:
        //     Break 7th top 7th bottom
        BT7B7 = 75,
        //
        // Summary:
        //     Break 8th top 7th bottom
        BT8B7 = 76,
        //
        // Summary:
        //     Break 8th top 8th bottom
        BT8B8 = 77,
        //
        // Summary:
        //     Break 9th top 8th bottom
        BT9B8 = 78,
        //
        // Summary:
        //     Break 9th top 9th bottom
        BT9B9 = 79,
        //
        // Summary:
        //     Break EI top 9th bottom
        BTEIB9 = 80,
        //
        // Summary:
        //     Break EI top EI bottom
        BTEIBEI = 81,
        //
        // Summary:
        //     Golden set
        GSET = 82,
        //
        // Summary:
        //     Sudden death
        SD = 83,
        //
        // Summary:
        //     In progress
        IN_PROGRESS = 84,
        //
        // Summary:
        //     Session break
        SESSION_BREAK = 85,
        /// <summary>
        /// -A SofixTech Generated Field-
        /// Special Magic value = 5000 to indicate 
        /// that match was removed from live feed (for whatever reason,
        /// for further information on the reason this was done,
        /// see LiveData.ExtraInfo["Message"]
        /// NOTE: this does not have a bet radar match state equivalent 
        /// (Avi G - 2015, June 11th)
        /// </summary>
        REMOVED = 5000
    }
}

