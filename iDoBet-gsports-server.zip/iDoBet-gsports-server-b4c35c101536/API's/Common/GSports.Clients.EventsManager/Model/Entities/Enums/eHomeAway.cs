﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities.Enums
{
    public enum eHomeAway
    {
        // Summary:
        //     Undefined
        UNDEFINED = 0,
        //
        // Summary:
        //     Away team
        AWAY = 1,
        //
        // Summary:
        //     Home team
        HOME = 2,
        //
        // Summary:
        //     None (neither home or away)
        //
        NONE = 3,
    }
}
