﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities.Enums
{
    public enum eEventStatus
    {
        Unknown = -1,
        Prematch = 0,
        Live = 1,
        Closed = 2,
        Canceled = 3,
        Interrupted = 4,
        Void = 5,
        AwaitingLive = 6
    }
}
