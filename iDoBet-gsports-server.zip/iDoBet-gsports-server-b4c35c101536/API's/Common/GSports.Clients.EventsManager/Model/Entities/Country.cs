﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities
{
    public class EventCountry
    {
        public long Id { get; set; }

        public string DisplayName
        {
            get
            {
                return (string.IsNullOrEmpty(this.ShortName) ? this.Name : this.ShortName).Trim();
            }
        }
        [JsonIgnore]
        public string Name { get; set; }
        [JsonIgnore]
        public string ShortName { get; set; }
        [JsonIgnore]
        public bool? IsActive { get; set; }
        [JsonIgnore]
        public int? Order { get; set; }

    }
}
