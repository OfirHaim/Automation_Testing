﻿using GSports.Clients.EventsManager.Consts;
using GSports.Clients.EventsManager.Model.Entities.Enums;
using GSports.Clients.EventsManager.Model.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities
{
    public class Event : IDiffCompare
    {
       
        [JsonProperty(PropertyName = PropertyNames.DATA)]
        public EventData EventData { get; set; }

        [JsonProperty(PropertyName = "bts")]
        public List<BetType> BetTypes { get; set; }       
        
        [JsonProperty(PropertyName = PropertyNames.COMPARE_KEY)]
        public string CompareKey
        {
            get
            {
                return EventData.Id.ToString();
            }
        }

        [JsonProperty(PropertyName = PropertyNames.GAME_NUMBER)]
        public string GameNumber
        {
            get
            {
                return EventData.GameNumber;
            }
        }


        [JsonIgnore]
        public bool ForClient
        {
            get
            {
                return IsEnable() && BetTypes.Any();
            }
        }

        [JsonIgnore]
        public bool IsLive 
        {
            get
            {
                return EventData.EventStatus == eEventStatus.AwaitingLive || EventData.EventStatus == eEventStatus.Live;
            }
        }
        
        public bool IsEnable()
        {
            return this.EventData.EventStatus == eEventStatus.Live ||
                       (this.EventData.EventStatus == eEventStatus.Prematch &&
                        this.EventData.GameTime > DateTime.UtcNow) ||
                        this.EventData.EventStatus == eEventStatus.AwaitingLive;        
        }
    }



    public class EventData
    {
        private eEventStatus status;
        [JsonProperty(PropertyName = "id")]
        public long Id { get; set; }

        [JsonProperty(PropertyName = "couponId")]
        public int CouponId { get; set; }


        [JsonProperty(PropertyName = "sportName")]
        public string SportTypeName
        {
            get
            {
                return SportType.DisplayName;
            }
        }
        [JsonProperty(PropertyName = "sportId")]
        public long SportTypeId
        {
            get
            {
                return SportType.Id;
            }
        }

        [JsonProperty(PropertyName = PropertyNames.BETTYPES_COUNT)]
        public int? BetTypeCount { get; set; }

        [JsonIgnore]
        public string GameNumber { get; set; }

        [JsonIgnore]
        public SportType SportType { get; set; }

        [JsonProperty(PropertyName = "state")]
        public eEventState EventState { get; set; }

        [JsonProperty(PropertyName = PropertyNames.STATUS)]
        public eEventStatus EventStatus{
            get {
                return (!(this.IsActive ?? true )? eEventStatus.Closed : 
                        (this.status == eEventStatus.AwaitingLive)? eEventStatus.Prematch :this.status);
                            }
            set { this.status = value; }
        }

        [JsonProperty(PropertyName = "leagueName")]
        public string LeagueName
        {
            get
            {
                return League.DisplayName;
            }
        }

        [JsonProperty(PropertyName = "leagueId")]
        public long LeagueId
        {
            get
            {
                return League.Id;
            }
        }

        [JsonIgnore]
        public League League { get; set; }

        [JsonProperty(PropertyName = "countryName")]
        public string CountryName
        {
            get
            {
                return Country.DisplayName;
            }
        }

        [JsonProperty(PropertyName = "countryId")]
        public long CountryId
        {
            get
            {
                return Country.Id;
            }
        }
        [JsonIgnore]
        public EventCountry Country { get; set; }

        [JsonProperty(PropertyName = "home")]
        public string HomeTeamName
        {
            get
            {
                return HomeTeam==null ? null : HomeTeam.DisplayName;
            }
        }

        [JsonIgnore]
        public Team HomeTeam { get; set; }

        [JsonProperty(PropertyName = "away")]
        public string AwayTeamName
        {
            get
            {
                return AwayTeam == null ? null : AwayTeam.DisplayName;
            }
        }

        [JsonIgnore]
        public Team AwayTeam { get; set; }

        [JsonProperty(PropertyName = "time")]
        public DateTime GameTime { get; set; }

        [JsonIgnore]
        public bool NeutralGrounds { get; set; }

        [JsonProperty(PropertyName = "book")]
        public bool IsBookedForLive {get;set;}

        [JsonProperty(PropertyName = "topevent")]
        public int? TopEventOrder {get;set;}

        [JsonIgnore]
        public DateTime LastUpdate {get;set;}

        [JsonIgnore]
        public bool? IsActive { get; set; }
        //[JsonProperty(PropertyName = "pbo", NullValueHandling = NullValueHandling.Ignore)]
        //public DateTime PlaceBetOn { get; set; }


        [JsonProperty(PropertyName = PropertyNames.META_DATA)]
        public EventMetaData MetaData
        {
            get
            {                
                return new EventMetaData()
                {
                    SportTypeOrder = SportType.Order ?? -1,
                    CountryCorder = Country.Order ?? -1,
                    LeagueOrder = League.Order ?? -1
                };
            }
        }

        #region bet types

        #endregion

        #region live props

        public LiveData Live { get; set; }

        #endregion
    }



    public class SimpleTwoSidesScore
    {
        [JsonProperty(PropertyName = "home")]
        public int HomeScore { get; set; }

        [JsonProperty(PropertyName = "away")]
        public int AwayScore { get; set; }
    }



    public class LiveData
    {
        [JsonProperty(PropertyName = "time")]
        public string CurrentTime { get; set; }

        public SimpleTwoSidesScore Score { get; set; }

        #region soccer
        public int? HomeRedCards { get; set; }

        public int? AwayRedCards { get; set; }

        #endregion

        #region tennis
        public SimpleTwoSidesScore[] SetScore { get; set; }

        public eHomeAway WhoServes { get; set; }

        #endregion

        #region basketball

        public bool ClockPaused { get; set; }

        public int? RemainingTime { get; set; }

        #endregion
    }
    public class EventMetaData
    {
        [JsonProperty(PropertyName = "so")]
        public int SportTypeOrder { get; set; }
        [JsonProperty(PropertyName = "co")]
        public int CountryCorder { get; set; }
        [JsonProperty(PropertyName = "lo")]
        public int LeagueOrder { get; set; }
    }
}
