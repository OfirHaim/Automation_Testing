﻿using GSports.Clients.EventsManager.Consts;
using GSports.Clients.EventsManager.Model.Entities.Enums;
using GSports.Clients.EventsManager.Model.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities
{
    public class Odd : IDiffCompare, ICloneable
    {
     
        private eOddStatus status;
        [JsonProperty(PropertyName = PropertyNames.COMPARE_KEY)]
        public string CompareKey
        {
            get
            {
                return this.Name;
            }
        }
        [JsonProperty(PropertyName = PropertyNames.NAME)]
        public string DisplayName
        {
            get
            {
                return (string.IsNullOrEmpty(this.ShortName) ? this.Name : this.ShortName).Trim();
            }
        }

        [JsonProperty(PropertyName = PropertyNames.PRICE)]
        public string DisplayPrice
        {
            get
            {
                return string.Format("{0:n2}", Price);
            }
        }

              
        [JsonProperty(PropertyName = PropertyNames.STATUS)]
        public eOddStatus Status {
            get
            {
                return (this.status == eOddStatus.Unknown||
                        (this.Parent !=null && !this.Parent.IsEnable())) ? eOddStatus.Closed : this.status;
            }
            set { this.status = value; }
        }

        [JsonIgnore]
        public string Name { get; set; }
        [JsonIgnore]
        public string ShortName { get; set; }
        //[JsonIgnore]
        public string Shortcut { get; set; }
        [JsonIgnore]
        public decimal? Price { get; set; }
        [JsonIgnore]
        public DateTime? LastUpdate { get; set; }
        [JsonIgnore]
        public long BettingTypeId { get; set; }
        
        [JsonIgnore]
        public BetType Parent { get; set; }

        public int? OrderRow { get; set; }
        
        public int? OrderCol { get; set; }
        public bool IsEnable()
        {
            return this.status == eOddStatus.Open ||
                   this.status == eOddStatus.Suspended;

        }
        public object Clone()
        {
            try
            {            
                Odd cloneObj = (Odd)this.MemberwiseClone();
                return cloneObj;
            }
            catch 
            {
                return null;
            }
        }
    }
}
