﻿using GSports.Clients.EventsManager.Consts;
using GSports.Clients.EventsManager.Model.Entities.Enums;
using GSports.Clients.EventsManager.Model.Interfaces;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GSports.Clients.EventsManager.Model.Entities
{
    public class BetType : IDiffCompare, ICloneable
    {
        [JsonProperty(PropertyName = PropertyNames.DATA)]
        public BetTypeData BetTypeData { get; set; }

        [JsonProperty(PropertyName = PropertyNames.COMPARE_KEY)]
        public string CompareKey
        {
            get
            {
                return BetTypeData.Id.ToString() + this.BetTypeData.Line ?? "";
            }
        }

        public List<Odd> Odds { get; set; }
        [JsonIgnore]
        public decimal?  MaxDeltaPrice {
            get { return (this.Odds != null ?
                        this.Odds.Where(o => o.Status == eOddStatus.Open || o.Status == eOddStatus.Suspended).Max(o => o.Price) -
                        this.Odds.Where(o => o.Status == eOddStatus.Open || o.Status == eOddStatus.Suspended).Min(o => o.Price): null)  ; }
        }
        public object Clone()
        {
            try
            {
                BetType cloneObj = (BetType)this.MemberwiseClone();
                if (this.BetTypeData != null)
                    cloneObj.BetTypeData = (BetTypeData)this.BetTypeData.Clone();
                if (this.Odds != null)
                    cloneObj.Odds = this.Odds.Select(x => (Odd)x.Clone()).ToList();
                return cloneObj;
            }
            catch
            {
                return null;
            }
        }

        public bool IsEnable()
        {
            return (this.BetTypeData.Status == eBetStatus.Open ||
                   this.BetTypeData.Status == eBetStatus.Suspended ) &&
                    this.Odds.Any(o => o.IsEnable());
                        
        }

    }

    public class BetTypeData:ICloneable
    {       
        private eBetStatus status;
        private string mainDisplay;
        [JsonProperty(PropertyName = PropertyNames.NAME)]
        public string DisplayName
        {
            get
            {
                return (string.IsNullOrEmpty(this.ShortName) ? this.Name : this.ShortName).Trim();
                //+ (string.IsNullOrEmpty(this.Line) ? "" : string.Format(" ({0})", this.Line));
            }
        }

        [JsonProperty(PropertyName = PropertyNames.STATUS)]
        public eBetStatus Status {
            get
            {
                return (!this.IsActive || 
                         this.status == eBetStatus.Canceled ||
                         this.status == eBetStatus.Deleted ||
                         this.status == eBetStatus.Unknown ||
                          (this.Parent != null && !this.Parent.IsEnable()) ||
                          (!this.IsLive && this.Parent != null && this.Parent.EventData.GameTime < DateTime.UtcNow)) ? eBetStatus.Closed: this.status;
            }
            set
            {
                this.status = value;
            }
        }

        public string Line { get; set; }

        public long Id { get; set; }

        [JsonIgnore]
        public string Name { get; set; }

        [JsonIgnore]
        public string ShortName { get; set; }

        [JsonProperty(PropertyName = PropertyNames.ORDER)]
        public int? SortingOrder { get; set; }

        [JsonIgnore]
        public bool IsLive { get; set; }

        [JsonIgnore]
        public bool IsActive { get; set; }

        [JsonIgnore]
        public DateTime? LastUpdate { get; set; }
        /// <summary>
        /// lo = main display line + odds, o = only odds (exampe: next goal not show line)
        /// </summary>
        [JsonProperty(PropertyName = PropertyNames.MAIN_DISPLAY)]
        public string MainDisplay {
            get { return this.IsDisplay?this.IsLineDisplay? "lo":"o": this.mainDisplay??""; }
            set { this.mainDisplay = value; }
             }
        [JsonIgnore]
        public bool IsLineDisplay { get; set; }
        [JsonIgnore]
        public bool IsDisplay { get; set; }
        [JsonIgnore]
        public Event Parent { get; set; }
      
        public object Clone()
        {
            try
            {
                BetTypeData cloneObj = (BetTypeData)this.MemberwiseClone();      
                return cloneObj;
            }
            catch
            {
                return null;
            }
        }


    }
}
